/*     */ package AutoplayAddon.Tracker;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2708;
/*     */ import net.minecraft.class_2828;
/*     */ import net.minecraft.class_2885;
/*     */ import net.minecraft.class_2886;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_3944;
/*     */ 
/*     */ public class ServerSideValues {
/*     */   private static final int INITIAL_SIZEp = 8;
/*  22 */   private static long[] timesp = new long[8];
/*  23 */   private static long[] countsp = new long[8]; private static final long intervalp = 7000000000L;
/*     */   private static long lastHandshakeTime;
/*     */   private static long minTimep;
/*     */   private static long sump;
/*     */   private static int headp;
/*     */   public static int ticks;
/*     */   private static int tailp;
/*     */   public static boolean hasMoved;
/*     */   public static boolean clientIsFloating = false;
/*     */   public static int lastScreenSyncId;
/*  33 */   static long lastLimitedPacket = -1L;
/*  34 */   public static class_243 tickpos = null; public static float lastYaw; public static float lastPitch; public static int i; public static int i2; public static int aboveGroundTickCount; public static int limitedPackets; private static int receivedMovePacketCount;
/*  35 */   public static class_243 serversidedposition = new class_243(0.0D, 0.0D, 0.0D); private static int knownMovePacketCount;
/*     */   private static int knownMovePacketCount2;
/*     */   private static int receivedMovePacketCount2;
/*     */   private static int lasttick;
/*     */   private static int allowedPlayerTicks;
/*     */   public static final int threshhold = 305;
/*     */   
/*     */   public static int delta() {
/*  43 */     return predictallowedPlayerTicks() - i2 + i;
/*     */   }
/*     */   public static int predictallowedPlayerTicks() {
/*  46 */     int TempAllowedPlayerTicks = allowedPlayerTicks;
/*  47 */     TempAllowedPlayerTicks = (int)(TempAllowedPlayerTicks + System.currentTimeMillis() / 50L - lasttick);
/*  48 */     return Math.max(TempAllowedPlayerTicks, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler(priority = -200)
/*     */   private static void onTick(TickEvent.Pre event) {
/*  55 */     ticks++;
/*  56 */     if (clientIsFloating) {
/*  57 */       aboveGroundTickCount++;
/*     */     } else {
/*  59 */       clientIsFloating = false;
/*  60 */       aboveGroundTickCount = 0;
/*     */     } 
/*  62 */     hasMoved = false;
/*  63 */     if (MeteorClient.mc.field_1724 == null)
/*  64 */       return;  tickpos = serversidedposition;
/*  65 */     knownMovePacketCount = receivedMovePacketCount;
/*  66 */     knownMovePacketCount2 = receivedMovePacketCount2;
/*  67 */     i = 0;
/*  68 */     i2 = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private static void onJoinServer(GameJoinedEvent event) {
/*  74 */     System.out.println("Joined server");
/*  75 */     lasttick = 0;
/*  76 */     lastScreenSyncId = 0;
/*  77 */     lastLimitedPacket = -1L;
/*  78 */     tickpos = new class_243(0.0D, 0.0D, 0.0D);
/*  79 */     hasMoved = false;
/*  80 */     i = 0;
/*  81 */     i2 = 0;
/*  82 */     allowedPlayerTicks = 1;
/*     */   }
/*     */   
/*     */   @EventHandler(priority = 202)
/*     */   private static void onRecievePacket(PacketEvent.Receive event) {
/*  87 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_3944) { class_3944 packet = (class_3944)class_2596; lastScreenSyncId = packet.method_17592(); }
/*  88 */      class_2596 = event.packet; if (class_2596 instanceof class_2708) { class_2708 packet = (class_2708)class_2596;
/*  89 */       serversidedposition = new class_243(packet.method_11734(), packet.method_11735(), packet.method_11738());
/*  90 */       if (tickpos == null) tickpos = serversidedposition;  }
/*     */   
/*     */   }
/*     */   
/*     */   @EventHandler(priority = -202)
/*     */   private static void onSendPacket(PacketEvent.Send event) {
/*  96 */     if (event.packet instanceof net.minecraft.class_2889) lastHandshakeTime = System.nanoTime(); 
/*  97 */     if (event.packet instanceof net.minecraft.class_2915) {
/*  98 */       sump = 0L;
/*  99 */       headp = 0;
/* 100 */       tailp = 0;
/* 101 */       countsp = new long[8];
/* 102 */       timesp = new long[8];
/* 103 */       updateAndAdd(1L, lastHandshakeTime);
/*     */     } 
/* 105 */     if (!(event.packet instanceof net.minecraft.class_2935) && !(event.packet instanceof net.minecraft.class_2937) && !(event.packet instanceof net.minecraft.class_2889)) updateAndAdd(1L, System.nanoTime());
/*     */     
/* 107 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2828) { class_2828 packet = (class_2828)class_2596;
/* 108 */       HandleMovepacket(packet, Boolean.valueOf(true)); }
/*     */     
/* 110 */     class_2596 = event.packet; if (class_2596 instanceof class_2885) { class_2885 packet = (class_2885)class_2596;
/* 111 */       if (!handleUse().booleanValue()) {
/* 112 */         event.setCancelled(true);
/* 113 */         event.cancel();
/*     */       }  }
/*     */     
/* 116 */     class_2596 = event.packet; if (class_2596 instanceof class_2886) { class_2886 packet = (class_2886)class_2596;
/* 117 */       if (!handleUse().booleanValue()) {
/* 118 */         event.setCancelled(true);
/* 119 */         event.cancel();
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public static void manageCircularBuffer(long currTime) {
/* 126 */     minTimep = currTime - 7000000000L;
/*     */ 
/*     */     
/* 129 */     while (headp != tailp && timesp[headp] < minTimep) {
/* 130 */       sump -= countsp[headp];
/* 131 */       countsp[headp] = 0L;
/* 132 */       headp = (headp + 1) % timesp.length;
/*     */     } 
/*     */     
/* 135 */     if (currTime - minTimep >= 0L) {
/* 136 */       int nextTail = (tailp + 1) % timesp.length;
/*     */       
/* 138 */       if (nextTail == headp) {
/* 139 */         resizeCircularBuffer();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void resizeCircularBuffer() {
/* 145 */     int size, oldLength = timesp.length;
/* 146 */     long[] newTimes = new long[oldLength * 2];
/* 147 */     long[] newCounts = new long[oldLength * 2];
/*     */ 
/*     */     
/* 150 */     if (tailp >= headp) {
/* 151 */       size = tailp - headp;
/* 152 */       System.arraycopy(timesp, headp, newTimes, 0, size);
/* 153 */       System.arraycopy(countsp, headp, newCounts, 0, size);
/*     */     } else {
/* 155 */       int firstPartSize = oldLength - headp;
/* 156 */       size = firstPartSize + tailp;
/*     */       
/* 158 */       System.arraycopy(timesp, headp, newTimes, 0, firstPartSize);
/* 159 */       System.arraycopy(timesp, 0, newTimes, firstPartSize, tailp);
/* 160 */       System.arraycopy(countsp, headp, newCounts, 0, firstPartSize);
/* 161 */       System.arraycopy(countsp, 0, newCounts, firstPartSize, tailp);
/*     */     } 
/*     */     
/* 164 */     timesp = newTimes;
/* 165 */     countsp = newCounts;
/* 166 */     headp = 0;
/* 167 */     tailp = size;
/*     */   }
/*     */   
/*     */   public static void updateAndAdd(long count, long currTime) {
/* 171 */     manageCircularBuffer(currTime);
/*     */     
/* 173 */     if (currTime - minTimep < 0L)
/* 174 */       return;  int nextTail = (tailp + 1) % timesp.length;
/*     */     
/* 176 */     timesp[tailp] = currTime;
/* 177 */     countsp[tailp] = countsp[tailp] + count;
/* 178 */     sump += count;
/* 179 */     tailp = nextTail;
/*     */   }
/*     */   
/*     */   public static Boolean canSendPackets(long count, long currTime) {
/* 183 */     long predictedSum = sump;
/* 184 */     long[] tmpCounts = (long[])countsp.clone();
/* 185 */     int tmpHead = headp;
/* 186 */     int tmpTail = tailp;
/*     */     
/* 188 */     manageCircularBuffer(currTime);
/*     */     
/* 190 */     tmpCounts[tmpTail] = tmpCounts[tmpTail] + count;
/* 191 */     predictedSum += count;
/* 192 */     double rate = predictedSum / 7.0D;
/* 193 */     return Boolean.valueOf((rate < 490.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void HandleMovePacketSafe(class_2828 packet) {
/* 199 */     receivedMovePacketCount2++;
/* 200 */     i2 = receivedMovePacketCount2 - knownMovePacketCount2 - receivedMovePacketCount - knownMovePacketCount;
/* 201 */     HandleMovepacket(packet, Boolean.valueOf(false));
/*     */   }
/*     */   
/*     */   public static void HandleMovepacket(class_2828 packet, Boolean setI) {
/* 205 */     class_243 targetpos = new class_243(packet.method_12269(serversidedposition.field_1352), packet.method_12268(serversidedposition.field_1351), packet.method_12274(serversidedposition.field_1350));
/* 206 */     boolean hasPos = packet.method_36171();
/* 207 */     boolean hasRot = packet.method_36172();
/*     */     
/* 209 */     class_243 currentDelta = new class_243(targetpos.field_1352 - serversidedposition.field_1352, targetpos.field_1351 - serversidedposition.field_1351, targetpos.field_1350 - serversidedposition.field_1350);
/* 210 */     double currentDeltaSquared = currentDelta.field_1352 * currentDelta.field_1352 + currentDelta.field_1351 * currentDelta.field_1351 + currentDelta.field_1350 * currentDelta.field_1350;
/*     */     
/* 212 */     class_243 tickDelta = new class_243(targetpos.field_1352 - tickpos.field_1352, targetpos.field_1351 - tickpos.field_1351, targetpos.field_1350 - tickpos.field_1350);
/* 213 */     double tickDeltaSquared = tickDelta.field_1352 * tickDelta.field_1352 + tickDelta.field_1351 * tickDelta.field_1351 + tickDelta.field_1350 * tickDelta.field_1350;
/*     */     
/* 215 */     double d10 = Math.max(currentDeltaSquared, tickDeltaSquared);
/*     */     
/* 217 */     if (d10 > 0.0D) {
/* 218 */       hasMoved = true;
/*     */     }
/*     */     
/* 221 */     if (setI.booleanValue()) {
/* 222 */       receivedMovePacketCount++;
/* 223 */       i = receivedMovePacketCount - knownMovePacketCount;
/*     */     } 
/* 225 */     allowedPlayerTicks = (int)(allowedPlayerTicks + System.currentTimeMillis() / 50L - lasttick);
/* 226 */     allowedPlayerTicks = Math.max(allowedPlayerTicks, 1);
/* 227 */     lasttick = (int)(System.currentTimeMillis() / 50L);
/* 228 */     if (i2 + i > Math.max(allowedPlayerTicks, 5)) {
/* 229 */       ChatUtils.error("Packet spam detected, server reset i value", new Object[0]);
/* 230 */       i = 0;
/* 231 */       i2 = 1;
/*     */     } 
/*     */     
/* 234 */     if (hasRot) {
/* 235 */       lastYaw = packet.method_12271(MeteorClient.mc.field_1724.method_36454());
/* 236 */       lastPitch = packet.method_12270(MeteorClient.mc.field_1724.method_36455());
/*     */     } 
/*     */     
/* 239 */     if (hasRot || d10 > 0.0D) {
/* 240 */       allowedPlayerTicks--;
/*     */     } else {
/* 242 */       allowedPlayerTicks = 20;
/*     */     } 
/*     */ 
/*     */     
/* 246 */     String packetType = "unknown";
/* 247 */     if (packet instanceof class_2828.class_2830) packetType = "Full"; 
/* 248 */     if (packet instanceof class_2828.class_5911) packetType = "OnGroundOnly"; 
/* 249 */     if (packet instanceof class_2828.class_2829) packetType = "PositionAndOnGround"; 
/* 250 */     if (packet instanceof class_2828.class_2831) packetType = "LookAndOnGround";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (hasPos) {
/* 258 */       serversidedposition = targetpos;
/*     */     }
/* 260 */     clientIsFloating = (currentDelta.field_1351 >= -0.03125D && noBlocksAround());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean handleUse() {
/* 266 */     if (lastLimitedPacket != -1L && System.currentTimeMillis() - lastLimitedPacket < 305L && limitedPackets++ >= 8) {
/* 267 */       return Boolean.valueOf(false);
/*     */     }
/* 269 */     if (lastLimitedPacket == -1L || System.currentTimeMillis() - lastLimitedPacket >= 305L) {
/* 270 */       lastLimitedPacket = System.currentTimeMillis();
/* 271 */       limitedPackets = 0;
/* 272 */       return Boolean.valueOf(true);
/*     */     } 
/* 274 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canPlace() {
/* 279 */     if (lastLimitedPacket != -1L && System.currentTimeMillis() - lastLimitedPacket < 305L && limitedPackets + 1 >= 8) {
/* 280 */       return false;
/*     */     }
/* 282 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean noBlocksAround() {
/* 288 */     class_238 box = MeteorClient.mc.field_1724.method_5829().method_1014(0.0625D).method_1012(0.0D, -0.55D, 0.0D);
/* 289 */     int minX = class_3532.method_15357(box.field_1323);
/* 290 */     int minY = class_3532.method_15357(box.field_1322);
/* 291 */     int minZ = class_3532.method_15357(box.field_1321);
/* 292 */     int maxX = class_3532.method_15357(box.field_1320);
/* 293 */     int maxY = class_3532.method_15357(box.field_1325);
/* 294 */     int maxZ = class_3532.method_15357(box.field_1324);
/* 295 */     class_2338.class_2339 pos = new class_2338.class_2339();
/* 296 */     if (MeteorClient.mc.field_1687 == null) return false; 
/* 297 */     for (int y = minY; y <= maxY; y++) {
/* 298 */       for (int z = minZ; z <= maxZ; z++) {
/* 299 */         for (int x = minX; x <= maxX; x++) {
/* 300 */           pos.method_10103(x, y, z);
/* 301 */           class_2680 type = MeteorClient.mc.field_1687.method_8320((class_2338)pos);
/* 302 */           if (type != null && !type.method_26215()) {
/* 303 */             return false;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 308 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Tracker\ServerSideValues.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */