/*    */ package AutoplayAddon.Tracker;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import meteordevelopment.meteorclient.events.game.GameLeftEvent;
/*    */ import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_2791;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCache
/*    */ {
/* 20 */   public class_2338 lastBlockPos = null;
/* 21 */   public final Map<class_2338, class_2248> blockMap = new ConcurrentHashMap<>();
/* 22 */   public final ExecutorService executorService = Executors.newSingleThreadExecutor();
/*    */   
/*    */   @EventHandler(priority = 201)
/*    */   private void onSendMovePacket(GameLeftEvent event) {
/* 26 */     AutoplayAddon.LOG.info("removing all");
/* 27 */     this.blockMap.clear();
/*    */   }
/*    */   
/*    */   @EventHandler(priority = 201)
/*    */   private void onBlockPosUpdate(BlockUpdateEvent event) {
/* 32 */     class_2338 updatedPos = event.pos;
/* 33 */     class_2680 newState = event.newState;
/* 34 */     class_2680 oldState = event.oldState;
/*    */     
/* 36 */     if (newState.method_51367()) {
/* 37 */       this.blockMap.put(updatedPos, newState.method_26204());
/* 38 */     } else if (oldState.method_51367()) {
/* 39 */       this.blockMap.remove(updatedPos);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void addChunk(class_2791 chunk) {
/* 44 */     this.executorService.submit(() -> {
/*    */           for (int x = 0; x < 16; x++) {
/*    */             for (int y = 0; y < 256; y++) {
/*    */               for (int z = 0; z < 16; z++) {
/*    */                 class_2338 pos = new class_2338(chunk.method_12004().method_8326() + x, y, chunk.method_12004().method_8328() + z);
/*    */                 class_2680 blockState = chunk.method_8320(pos);
/*    */                 if (blockState.method_51367()) {
/*    */                   this.blockMap.put(pos, blockState.method_26204());
/*    */                 }
/*    */               } 
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */   
/*    */   public void removeChunk(class_2791 chunk) {
/* 60 */     this.executorService.submit(() -> {
/*    */           for (int x = 0; x < 16; x++) {
/*    */             for (int y = 0; y < 256; y++) {
/*    */               for (int z = 0; z < 16; z++) {
/*    */                 class_2338 pos = new class_2338(chunk.method_12004().method_8326() + x, y, chunk.method_12004().method_8328() + z);
/*    */                 this.blockMap.remove(pos);
/*    */               } 
/*    */             } 
/*    */           } 
/*    */         });
/*    */   }
/*    */   
/*    */   public synchronized boolean isBlockAt(class_2338 pos) {
/* 73 */     return this.blockMap.containsKey(pos);
/*    */   }
/*    */   
/*    */   public synchronized class_2248 getBlockType(class_2338 pos) {
/* 77 */     return this.blockMap.get(pos);
/*    */   }
/*    */   
/*    */   public synchronized boolean removeBlock(class_2338 pos) {
/* 81 */     return (this.blockMap.remove(pos) != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Tracker\BlockCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */