/*     */ package AutoplayAddon;
/*     */ import AutoplayAddon.AutoPlay.Other.AnchorUtils;
/*     */ import AutoplayAddon.HUD.Presets;
/*     */ import AutoplayAddon.Tracker.BlockCache;
/*     */ import AutoplayAddon.commands.AcceptTp;
/*     */ import AutoplayAddon.commands.Blank;
/*     */ import AutoplayAddon.commands.Craft;
/*     */ import AutoplayAddon.commands.GetClosestVehicleId;
/*     */ import AutoplayAddon.commands.Getid;
/*     */ import AutoplayAddon.commands.SearchFor;
/*     */ import AutoplayAddon.commands.StopSleeping;
/*     */ import AutoplayAddon.commands.TestCommand2;
/*     */ import AutoplayAddon.commands.TpTo;
/*     */ import AutoplayAddon.modules.BlockFarmer;
/*     */ import AutoplayAddon.modules.BlockUpdateDetector;
/*     */ import AutoplayAddon.modules.CobbleNuker;
/*     */ import AutoplayAddon.modules.Done.BackAndForth;
/*     */ import AutoplayAddon.modules.ScardyCat;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import meteordevelopment.meteorclient.addons.GithubRepo;
/*     */ import meteordevelopment.meteorclient.commands.Command;
/*     */ import meteordevelopment.meteorclient.commands.Commands;
/*     */ import meteordevelopment.meteorclient.systems.hud.HudGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Category;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.systems.modules.Modules;
/*     */ import net.minecraft.class_2350;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class AutoplayAddon extends MeteorAddon {
/*  32 */   public static final Logger LOG = LoggerFactory.getLogger("AutoplayAddon starting");
/*  33 */   public static final Category autoplay = new Category("Autoplay", class_1802.field_8626.method_7854());
/*  34 */   public static final HudGroup HUD_GROUP = new HudGroup("AutoplayAddon Hud");
/*  35 */   public static final BlockCache blockCache = new BlockCache();
/*  36 */   public static class_2350 playerlookdirecrion = null;
/*  37 */   public static class_2350 playerfacingdirecrion = null;
/*  38 */   public static class_2350 blockhitdirection = null;
/*  39 */   public static ExecutorService executorService = Executors.newSingleThreadExecutor();
/*     */ 
/*     */   
/*     */   public void onInitialize() {
/*  43 */     MeteorClient.EVENT_BUS.subscribe(ServerSideValues.class);
/*  44 */     MeteorClient.EVENT_BUS.subscribe(blockCache);
/*  45 */     MeteorClient.EVENT_BUS.subscribe(AnchorUtils.class);
/*  46 */     LOG.info("Initializing AutoplayAddon");
/*  47 */     Presets.starscriptAdd();
/*  48 */     Hud.get().register(Charge.INFO);
/*     */     
/*  50 */     Modules.get().add((Module)new BackAndForth());
/*  51 */     Modules.get().add((Module)new JoinLeaveNotify());
/*  52 */     Modules.get().add((Module)new InfAnchorNotify());
/*  53 */     Modules.get().add((Module)new HitboxDesync());
/*  54 */     Modules.get().add((Module)new Trap());
/*  55 */     Modules.get().add((Module)new ServerTeleportNotifier());
/*     */     
/*  57 */     Modules.get().add((Module)new InfiniteMine());
/*  58 */     Modules.get().add((Module)new ScardyCat());
/*  59 */     Modules.get().add((Module)new StashFinder());
/*  60 */     Modules.get().add((Module)new Villager_Aura());
/*  61 */     Modules.get().add((Module)new AntiDeath());
/*  62 */     Modules.get().add((Module)new KitBot());
/*  63 */     Modules.get().add((Module)new DamageLogger());
/*  64 */     Modules.get().add((Module)new SimpcraftNetherTravel());
/*     */     
/*  66 */     Modules.get().add((Module)new Printer());
/*  67 */     Modules.get().add((Module)new BetterAntiHunger());
/*  68 */     Modules.get().add((Module)new FunnyHand());
/*  69 */     Modules.get().add((Module)new AzaleaSpinbot());
/*     */     
/*  71 */     Modules.get().add((Module)new CobbleNuker());
/*  72 */     Modules.get().add((Module)new BlockUpdateDetector());
/*  73 */     Modules.get().add((Module)new Door());
/*     */ 
/*     */     
/*  76 */     Modules.get().add((Module)new Disabler());
/*  77 */     Modules.get().add((Module)new BlockFarmer());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     Modules.get().add((Module)new ClickTp());
/*  83 */     Modules.get().add((Module)new InfiniteAura());
/*  84 */     Modules.get().add((Module)new Follower());
/*     */ 
/*     */     
/*  87 */     Modules.get().add((Module)new FreecamFly());
/*     */ 
/*     */     
/*  90 */     Modules.get().add((Module)new UpFly());
/*     */ 
/*     */     
/*  93 */     Modules.get().add((Module)new BetterMine());
/*  94 */     Modules.get().add((Module)new PacketLogger());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     Commands.add((Command)new Blank());
/*     */     
/* 104 */     Commands.add((Command)new StopSleeping());
/* 105 */     Commands.add((Command)new GetClosestVehicleId());
/* 106 */     Commands.add((Command)new Interact());
/*     */ 
/*     */     
/* 109 */     Commands.add((Command)new AcceptTp());
/* 110 */     Commands.add((Command)new Getid());
/* 111 */     Commands.add((Command)new Smack());
/*     */ 
/*     */ 
/*     */     
/* 115 */     Commands.add((Command)new Stop());
/* 116 */     Commands.add((Command)new TpTo());
/*     */     
/* 118 */     Commands.add((Command)new TestCommand2());
/* 119 */     Commands.add((Command)new Mine());
/* 120 */     Commands.add((Command)new TP2cam());
/* 121 */     Commands.add((Command)new Teleport());
/* 122 */     Commands.add((Command)new Craft());
/* 123 */     Commands.add((Command)new ItemCollect());
/* 124 */     Commands.add((Command)new SearchFor());
/* 125 */     Commands.add((Command)new findcollectableblock());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRegisterCategories() {
/* 132 */     Modules.registerCategory(autoplay);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getWebsite() {
/* 137 */     return "https://github.com/Not-a-Tyler/AutoplayAddon";
/*     */   }
/*     */ 
/*     */   
/*     */   public GithubRepo getRepo() {
/* 142 */     return new GithubRepo("Not-a-Tyler", "AutoplayAddon");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommit() {
/* 152 */     String commit = ((ModContainer)FabricLoader.getInstance().getModContainer("autoplay-addon").get()).getMetadata().getCustomValue("github:sha").getAsString();
/* 153 */     return commit.isEmpty() ? null : commit.trim();
/*     */   }
/*     */   
/*     */   public String getPackage() {
/* 157 */     return "AutoplayAddon";
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoplayAddon.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */