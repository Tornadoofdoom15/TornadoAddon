/*    */ package AutoplayAddon.HUD;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
/*    */ import meteordevelopment.meteorclient.systems.hud.elements.TextHud;
/*    */ import meteordevelopment.meteorclient.utils.misc.MeteorStarscript;
/*    */ import meteordevelopment.starscript.value.Value;
/*    */ 
/*    */ public class Presets {
/* 11 */   public static final HudElementInfo<TextHud> INFO = new HudElementInfo(AutoplayAddon.HUD_GROUP, "AutoplayAddon", "Displays arbitrary text with Starscript.", Presets::create);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 16 */   public static final HudElementInfo<TextHud>.Preset FALL_DISTANCE = addPreset("Allowed Player Ticks", "Allowed Player Ticks: #1{allowed_player_ticks}");
/*    */ 
/*    */   
/*    */   private static TextHud create() {
/* 20 */     return new TextHud(INFO);
/*    */   }
/*    */   
/*    */   private static HudElementInfo<TextHud>.Preset addPreset(String title, String text) {
/* 24 */     return INFO.addPreset(title, textHud -> {
/*    */           if (text != null) {
/*    */             textHud.text.set(text);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public static void starscriptAdd() {
/* 32 */     MeteorStarscript.ss.set("allowed_player_ticks", () -> Value.number(ServerSideValues.predictallowedPlayerTicks()));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\HUD\Presets.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */