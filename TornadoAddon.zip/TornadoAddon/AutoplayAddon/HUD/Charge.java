/*    */ package AutoplayAddon.HUD;
/*    */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*    */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*    */ import meteordevelopment.meteorclient.settings.DoubleSetting;
/*    */ import meteordevelopment.meteorclient.settings.IntSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
/*    */ import meteordevelopment.meteorclient.systems.hud.HudRenderer;
/*    */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*    */ 
/*    */ public class Charge extends HudElement {
/* 13 */   public static final HudElementInfo<Charge> INFO = new HudElementInfo(AutoplayAddon.HUD_GROUP, "allowed-player-ticks", "Displays timer plus charge.", Charge::new);
/*    */   
/* 15 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/* 16 */   private final SettingGroup sgScale = this.settings.createGroup("Scale");
/* 17 */   private final SettingGroup sgBackground = this.settings.createGroup("Background");
/*    */   
/* 19 */   private final Setting<Boolean> shadow = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 20 */       .name("shadow"))
/* 21 */       .description("Text shadow."))
/* 22 */       .defaultValue(Boolean.valueOf(true)))
/* 23 */       .build()); private final Setting<Integer> border; private final Setting<Boolean> customScale; private final Setting<Double> scale; private final Setting<Boolean> background; private final Setting<SettingColor> backgroundColor;
/*    */   private final Setting<SettingColor> textColor;
/*    */   
/*    */   public Charge() {
/* 27 */     super(INFO);
/*    */ 
/*    */     
/* 30 */     this.border = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/* 31 */         .name("border"))
/* 32 */         .description("How much space to add around the element."))
/* 33 */         .defaultValue(Integer.valueOf(0)))
/* 34 */         .build());
/*    */ 
/*    */     
/* 37 */     this.customScale = this.sgScale.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 38 */         .name("custom-scale"))
/* 39 */         .description("Applies custom text scale rather than the global one."))
/* 40 */         .defaultValue(Boolean.valueOf(false)))
/* 41 */         .build());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 47 */     Objects.requireNonNull(this.customScale); this.scale = this.sgScale.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("Custom scale.")).visible(this.customScale::get))
/* 48 */         .defaultValue(1.0D)
/* 49 */         .min(0.5D)
/* 50 */         .sliderRange(0.5D, 3.0D)
/* 51 */         .build());
/*    */ 
/*    */     
/* 54 */     this.background = this.sgBackground.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 55 */         .name("background"))
/* 56 */         .description("Displays background."))
/* 57 */         .defaultValue(Boolean.valueOf(false)))
/* 58 */         .build());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 64 */     Objects.requireNonNull(this.background); this.backgroundColor = this.sgBackground.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("background-color")).description("Color used for the background.")).visible(this.background::get))
/* 65 */         .defaultValue(new SettingColor(25, 25, 25, 50))
/* 66 */         .build());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 75 */     this.textColor = this.sgGeneral.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/* 76 */         .name("text-color"))
/* 77 */         .description("A."))
/* 78 */         .defaultValue(new SettingColor())
/* 79 */         .build());
/*    */   } public void setSize(double width, double height) {
/*    */     super.setSize(width + (((Integer)this.border.get()).intValue() * 2), height + (((Integer)this.border.get()).intValue() * 2));
/*    */   }
/*    */   public void render(HudRenderer renderer) {
/* 84 */     if (((Boolean)this.background.get()).booleanValue()) {
/* 85 */       renderer.quad(this.x, this.y, getWidth(), getHeight(), (Color)this.backgroundColor.get());
/*    */     }
/* 87 */     double x = (this.x + ((Integer)this.border.get()).intValue());
/* 88 */     double y = (this.y + ((Integer)this.border.get()).intValue());
/*    */     
/* 90 */     renderer.text("Allowed Player Ticks: " + ServerSideValues.predictallowedPlayerTicks(), x, y, (Color)this.textColor.get(), ((Boolean)this.shadow.get()).booleanValue(), getScale());
/*    */   }
/*    */ 
/*    */   
/*    */   private double getScale() {
/* 95 */     return ((Boolean)this.customScale.get()).booleanValue() ? ((Double)this.scale.get()).doubleValue() : -1.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\HUD\Charge.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */