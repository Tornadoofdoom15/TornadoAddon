/*     */ package AutoplayAddon.AutoPlay.Inventory;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends HashMap<class_1792, class_1792>
/*     */ {
/*     */   null() {
/* 118 */     put(class_1802.field_37512, class_1802.field_37507);
/* 119 */     put(class_1802.field_37510, class_1802.field_37507);
/* 120 */     put(class_1802.field_37515, class_1802.field_37507);
/* 121 */     put(class_1802.field_37509, class_1802.field_37507);
/* 122 */     put(class_1802.field_8820, class_1802.field_8651);
/* 123 */     put(class_1802.field_8170, class_1802.field_8191);
/* 124 */     put(class_1802.field_21981, class_1802.field_22031);
/* 125 */     put(class_1802.field_8652, class_1802.field_8404);
/* 126 */     put(class_1802.field_8583, class_1802.field_8118);
/* 127 */     put(class_1802.field_8125, class_1802.field_8842);
/* 128 */     put(class_1802.field_8684, class_1802.field_8113);
/* 129 */     put(class_1802.field_21982, class_1802.field_22032);
/* 130 */     put(class_1802.field_8072, class_1802.field_8651);
/* 131 */     put(class_1802.field_8767, class_1802.field_8191);
/* 132 */     put(class_1802.field_21983, class_1802.field_22031);
/* 133 */     put(class_1802.field_8808, class_1802.field_8404);
/* 134 */     put(class_1802.field_8415, class_1802.field_8118);
/* 135 */     put(class_1802.field_8334, class_1802.field_8842);
/* 136 */     put(class_1802.field_8624, class_1802.field_8113);
/* 137 */     put(class_1802.field_21984, class_1802.field_22032);
/* 138 */     put(class_1802.field_8587, class_1802.field_8651);
/* 139 */     put(class_1802.field_8201, class_1802.field_8191);
/* 140 */     put(class_1802.field_22489, class_1802.field_22031);
/* 141 */     put(class_1802.field_8458, class_1802.field_8404);
/* 142 */     put(class_1802.field_8888, class_1802.field_8118);
/* 143 */     put(class_1802.field_8439, class_1802.field_8842);
/* 144 */     put(class_1802.field_8210, class_1802.field_8113);
/* 145 */     put(class_1802.field_22490, class_1802.field_22032);
/* 146 */     put(class_1802.field_8284, class_1802.field_8651);
/* 147 */     put(class_1802.field_8472, class_1802.field_8191);
/* 148 */     put(class_1802.field_22487, class_1802.field_22031);
/* 149 */     put(class_1802.field_8219, class_1802.field_8404);
/* 150 */     put(class_1802.field_8248, class_1802.field_8118);
/* 151 */     put(class_1802.field_8785, class_1802.field_8842);
/* 152 */     put(class_1802.field_8362, class_1802.field_8113);
/* 153 */     put(class_1802.field_22488, class_1802.field_22032);
/* 154 */     put(class_1802.field_42692, class_1802.field_42687);
/* 155 */     put(class_1802.field_42693, class_1802.field_42687);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\Lists$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */