/*    */ package AutoplayAddon.AutoPlay.Inventory;
/*    */ public final class ItemSlotPair extends Record {
/*    */   private final class_1792 item;
/*    */   private final FindItemResult slot;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #14	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #14	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;
/*    */   }
/*    */   
/* 14 */   public ItemSlotPair(class_1792 item, FindItemResult slot) { this.item = item; this.slot = slot; } public class_1792 item() { return this.item; } public final boolean equals(Object o) { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #14	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;
/* 14 */     //   0	8	1	o	Ljava/lang/Object; } public FindItemResult slot() { return this.slot; }
/*    */ 
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\LogToPlankTest$ItemSlotPair.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */