/*    */ package AutoplayAddon.AutoPlay.Inventory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum WoodType
/*    */ {
/* 25 */   ACACIA,
/* 26 */   BIRCH,
/* 27 */   CRIMSON,
/* 28 */   DARK_OAK,
/* 29 */   OAK,
/* 30 */   JUNGLE,
/* 31 */   SPRUCE,
/* 32 */   WARPED,
/* 33 */   MANGROVE;
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\Lists$WoodType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */