/*    */ package AutoplayAddon.AutoPlay.Inventory;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2371;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GUI
/*    */ {
/* 21 */   private List<class_1799> slots = new ArrayList<>();
/*    */   
/*    */   public GUI(int slotcount) {
/* 24 */     int emptySlotsCount = slotcount - 36;
/* 25 */     this.inventoryStartIndex = emptySlotsCount;
/*    */     
/* 27 */     for (int i = 0; i < emptySlotsCount; i++) {
/* 28 */       this.slots.add(class_1799.field_8037);
/*    */     }
/*    */     
/* 31 */     class_2371<class_1799> playerInventory = (MeteorClient.mc.field_1724.method_31548()).field_7547;
/*    */     
/*    */     int j;
/* 34 */     for (j = 9; j < 36; j++) {
/* 35 */       this.slots.add((class_1799)playerInventory.get(j));
/*    */     }
/*    */ 
/*    */     
/* 39 */     for (j = 0; j < 9; j++)
/* 40 */       this.slots.add((class_1799)playerInventory.get(j)); 
/*    */   }
/*    */   private int inventoryStartIndex;
/*    */   
/*    */   public int findEmptyInventorySlot() {
/* 45 */     for (int i = this.inventoryStartIndex; i < this.slots.size(); i++) {
/* 46 */       if (((class_1799)this.slots.get(i)).method_7960()) {
/* 47 */         return i;
/*    */       }
/*    */     } 
/*    */     
/* 51 */     return -1;
/*    */   }
/*    */   public class_1799 getSlot(int slot) {
/* 54 */     return this.slots.get(slot);
/*    */   }
/*    */   
/*    */   public List<class_1799> getSlots() {
/* 58 */     return this.slots;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\InventoryUtils$GUI.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */