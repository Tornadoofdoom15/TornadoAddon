/*     */ package AutoplayAddon.AutoPlay.Inventory;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends HashMap<Lists.WoodType, Lists.WoodItems>
/*     */ {
/*     */   null() {
/* 199 */     p(Lists.WoodType.MANGROVE, "mangrove", class_1802.field_37507, class_1802.field_37512, class_1802.field_37515, class_1802.field_37509, class_1802.field_37510, class_1802.field_37534, class_1802.field_37528, class_1802.field_37530, class_1802.field_37526, class_1802.field_37516, class_1802.field_37520, class_1802.field_37532, class_1802.field_37531, class_1802.field_37508, class_1802.field_37511, class_1802.field_37527, class_1802.field_37529);
/* 200 */     p(Lists.WoodType.ACACIA, "acacia", class_1802.field_8651, class_1802.field_8820, class_1802.field_8072, class_1802.field_8284, class_1802.field_8587, class_1802.field_8203, class_1802.field_8758, class_1802.field_8605, class_1802.field_8445, class_1802.field_8400, class_1802.field_8646, class_1802.field_8114, class_1802.field_8094, class_1802.field_17539, class_1802.field_17507, class_1802.field_8173, class_1802.field_8190);
/* 201 */     p(Lists.WoodType.BIRCH, "birch", class_1802.field_8191, class_1802.field_8170, class_1802.field_8767, class_1802.field_8472, class_1802.field_8201, class_1802.field_8422, class_1802.field_8438, class_1802.field_8174, class_1802.field_8130, class_1802.field_8843, class_1802.field_8457, class_1802.field_8289, class_1802.field_8442, class_1802.field_17537, class_1802.field_17505, class_1802.field_8779, class_1802.field_8774);
/* 202 */     p(Lists.WoodType.CRIMSON, "crimson", class_1802.field_22031, class_1802.field_21981, class_1802.field_21983, class_1802.field_22487, class_1802.field_22489, class_1802.field_22011, class_1802.field_22010, class_1802.field_22004, class_1802.field_22006, class_1802.field_21985, class_1802.field_21995, class_1802.field_21997, null, class_1802.field_21987, null, class_1802.field_21993, class_1802.field_22002);
/* 203 */     p(Lists.WoodType.DARK_OAK, "dark_oak", class_1802.field_8404, class_1802.field_8652, class_1802.field_8808, class_1802.field_8219, class_1802.field_8458, class_1802.field_8496, class_1802.field_8517, class_1802.field_8531, class_1802.field_8658, class_1802.field_8540, class_1802.field_8454, class_1802.field_8293, class_1802.field_8138, class_1802.field_17540, class_1802.field_17508, class_1802.field_8886, class_1802.field_8844);
/* 204 */     p(Lists.WoodType.OAK, "oak", class_1802.field_8118, class_1802.field_8583, class_1802.field_8415, class_1802.field_8248, class_1802.field_8888, class_1802.field_8788, class_1802.field_8691, class_1802.field_8780, class_1802.field_8212, class_1802.field_8320, class_1802.field_8792, class_1802.field_8874, class_1802.field_8533, class_1802.field_17535, class_1802.field_17503, class_1802.field_8391, class_1802.field_8376);
/* 205 */     p(Lists.WoodType.JUNGLE, "jungle", class_1802.field_8842, class_1802.field_8125, class_1802.field_8334, class_1802.field_8785, class_1802.field_8439, class_1802.field_8867, class_1802.field_8199, class_1802.field_8887, class_1802.field_8311, class_1802.field_8224, class_1802.field_8823, class_1802.field_8097, class_1802.field_8730, class_1802.field_17538, class_1802.field_17506, class_1802.field_8047, class_1802.field_8321);
/* 206 */     p(Lists.WoodType.SPRUCE, "spruce", class_1802.field_8113, class_1802.field_8684, class_1802.field_8624, class_1802.field_8362, class_1802.field_8210, class_1802.field_8111, class_1802.field_8165, class_1802.field_8048, class_1802.field_8122, class_1802.field_8189, class_1802.field_8701, class_1802.field_8653, class_1802.field_8486, class_1802.field_17536, class_1802.field_17504, class_1802.field_8707, class_1802.field_8495);
/* 207 */     p(Lists.WoodType.WARPED, "warped", class_1802.field_22032, class_1802.field_21982, class_1802.field_21984, class_1802.field_22488, class_1802.field_22490, class_1802.field_22012, class_1802.field_22009, class_1802.field_22005, class_1802.field_22007, class_1802.field_21986, class_1802.field_21996, class_1802.field_21998, null, class_1802.field_21988, null, class_1802.field_21994, class_1802.field_22003);
/*     */   }
/*     */   
/*     */   void p(Lists.WoodType type, String prefix, class_1792 planks, class_1792 log, class_1792 strippedLog, class_1792 strippedWood, class_1792 wood, class_1792 sign, class_1792 door, class_1792 button, class_1792 stairs, class_1792 slab, class_1792 fence, class_1792 fenceGate, class_1792 boat, class_1792 sapling, class_1792 leaves, class_1792 pressurePlate, class_1792 trapdoor) {
/* 211 */     put(type, new Lists.WoodItems(prefix, planks, log, strippedLog, strippedWood, wood, sign, door, button, stairs, slab, fence, fenceGate, boat, sapling, leaves, pressurePlate, trapdoor));
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\Lists$4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */