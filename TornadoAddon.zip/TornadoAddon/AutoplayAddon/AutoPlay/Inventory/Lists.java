/*     */ package AutoplayAddon.AutoPlay.Inventory;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import net.minecraft.class_1767;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2609;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3481;
/*     */ import net.minecraft.class_3620;
/*     */ import net.minecraft.class_5321;
/*     */ import net.minecraft.class_6862;
/*     */ import net.minecraft.class_7923;
/*     */ 
/*     */ public class Lists {
/*     */   public enum WoodType {
/*  25 */     ACACIA,
/*  26 */     BIRCH,
/*  27 */     CRIMSON,
/*  28 */     DARK_OAK,
/*  29 */     OAK,
/*  30 */     JUNGLE,
/*  31 */     SPRUCE,
/*  32 */     WARPED,
/*  33 */     MANGROVE;
/*     */   }
/*     */   
/*  36 */   public static final class_1792[] SAPLINGS = new class_1792[] { class_1802.field_17535, class_1802.field_17536, class_1802.field_17537, class_1802.field_17538, class_1802.field_17539, class_1802.field_17540, class_1802.field_37508 };
/*     */   
/*  38 */   public static final class_2248[] SAPLING_SOURCES = new class_2248[] { class_2246.field_10503, class_2246.field_9988, class_2246.field_10539, class_2246.field_10335, class_2246.field_10098, class_2246.field_10035, class_2246.field_37544 };
/*     */ 
/*     */   
/*  41 */   public static final class_1792[] HOSTILE_MOB_DROPS = new class_1792[] { class_1802.field_8894, class_1802.field_8153, class_1802.field_8726, class_1802.field_8544, class_1802.field_8511, class_1802.field_8470, class_1802.field_8054, class_1802.field_8681, class_1802.field_8288, class_1802.field_8687, class_1802.field_8389, class_1802.field_8261, class_1802.field_8745, class_1802.field_8135, class_1802.field_8614, class_1802.field_8107, class_1802.field_8175, class_1802.field_8815, class_1802.field_8606, class_1802.field_8398, class_1802.field_8777, class_1802.field_8276, class_1802.field_8680, class_1802.field_37525, class_1802.field_8469, class_1802.field_8601, class_1802.field_8725, class_1802.field_8600, class_1802.field_8479, class_1802.field_8574, class_1802.field_8137, class_1802.field_8713, class_1802.field_8791, class_1802.field_8070, class_1802.field_8620, class_1802.field_8179, class_1802.field_8567, class_1802.field_8512, class_1802.field_27022 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final class_1792[] DIRTS = new class_1792[] { class_1802.field_8831, class_1802.field_8519, class_1802.field_8460, class_1802.field_28655 };
/*  50 */   public static final class_1792[] PLANKS = new class_1792[] { class_1802.field_8651, class_1802.field_8191, class_1802.field_22031, class_1802.field_8404, class_1802.field_8118, class_1802.field_8842, class_1802.field_8113, class_1802.field_22032, class_1802.field_37507 };
/*     */   
/*  52 */   public static final class_1792[] LEAVES = new class_1792[] { class_1802.field_17507, class_1802.field_17505, class_1802.field_17508, class_1802.field_17503, class_1802.field_17506, class_1802.field_17504, class_1802.field_37511 };
/*     */   
/*  54 */   public static final class_1792[] WOOD = new class_1792[] { class_1802.field_8587, class_1802.field_8201, class_1802.field_22489, class_1802.field_8458, class_1802.field_8888, class_1802.field_8439, class_1802.field_8210, class_1802.field_22490, class_1802.field_37510 };
/*     */ 
/*     */   
/*  57 */   public static final class_1792[] WOOD_BUTTON = new class_1792[] { class_1802.field_8605, class_1802.field_8174, class_1802.field_22004, class_1802.field_8531, class_1802.field_8780, class_1802.field_8887, class_1802.field_8048, class_1802.field_22005, class_1802.field_37530 };
/*     */ 
/*     */   
/*  60 */   public static final class_1792[] WOOD_SIGN = new class_1792[] { class_1802.field_8203, class_1802.field_8422, class_1802.field_22011, class_1802.field_8496, class_1802.field_8788, class_1802.field_8867, class_1802.field_8111, class_1802.field_22012, class_1802.field_37534 };
/*     */ 
/*     */   
/*  63 */   public static final class_1792[] WOOD_PRESSURE_PLATE = new class_1792[] { class_1802.field_8173, class_1802.field_8779, class_1802.field_21993, class_1802.field_8886, class_1802.field_8391, class_1802.field_8047, class_1802.field_8707, class_1802.field_21994, class_1802.field_37527 };
/*     */ 
/*     */ 
/*     */   
/*  67 */   public static final class_1792[] WOOD_FENCE = new class_1792[] { class_1802.field_8646, class_1802.field_8457, class_1802.field_8454, class_1802.field_8792, class_1802.field_8823, class_1802.field_8701, class_1802.field_21995, class_1802.field_21996, class_1802.field_37520 };
/*     */ 
/*     */   
/*  70 */   public static final class_1792[] WOOD_FENCE_GATE = new class_1792[] { class_1802.field_8114, class_1802.field_8289, class_1802.field_8293, class_1802.field_8874, class_1802.field_8097, class_1802.field_8653, class_1802.field_21997, class_1802.field_21998, class_1802.field_37532 };
/*     */ 
/*     */   
/*  73 */   public static final class_1792[] WOOD_BOAT = new class_1792[] { class_1802.field_8094, class_1802.field_8442, class_1802.field_8138, class_1802.field_8533, class_1802.field_8730, class_1802.field_8486, class_1802.field_37531 };
/*     */   
/*  75 */   public static final class_1792[] WOOD_DOOR = new class_1792[] { class_1802.field_8758, class_1802.field_8438, class_1802.field_22010, class_1802.field_8517, class_1802.field_8691, class_1802.field_8199, class_1802.field_8165, class_1802.field_22009, class_1802.field_37528 };
/*     */ 
/*     */   
/*  78 */   public static final class_1792[] WOOD_SLAB = new class_1792[] { class_1802.field_8400, class_1802.field_8843, class_1802.field_21985, class_1802.field_8540, class_1802.field_8320, class_1802.field_8224, class_1802.field_8189, class_1802.field_21986, class_1802.field_37516 };
/*     */ 
/*     */   
/*  81 */   public static final class_1792[] WOOD_STAIRS = new class_1792[] { class_1802.field_8445, class_1802.field_8130, class_1802.field_22006, class_1802.field_8658, class_1802.field_8212, class_1802.field_8311, class_1802.field_8122, class_1802.field_22007, class_1802.field_37526 };
/*     */ 
/*     */   
/*  84 */   public static final class_1792[] WOOD_TRAPDOOR = new class_1792[] { class_1802.field_8190, class_1802.field_8774, class_1802.field_22002, class_1802.field_8844, class_1802.field_8376, class_1802.field_8321, class_1802.field_8495, class_1802.field_22003, class_1802.field_37529 };
/*     */ 
/*     */   
/*  87 */   public static final class_1792[] LOG = new class_1792[] { class_1802.field_8820, class_1802.field_8170, class_1802.field_8652, class_1802.field_8583, class_1802.field_8125, class_1802.field_8684, class_1802.field_8587, class_1802.field_8201, class_1802.field_8458, class_1802.field_8888, class_1802.field_8439, class_1802.field_8210, class_1802.field_8072, class_1802.field_8767, class_1802.field_8808, class_1802.field_8415, class_1802.field_8334, class_1802.field_8624, class_1802.field_8284, class_1802.field_8472, class_1802.field_8219, class_1802.field_8248, class_1802.field_8785, class_1802.field_8362, class_1802.field_21981, class_1802.field_21982, class_1802.field_22489, class_1802.field_22490, class_1802.field_21983, class_1802.field_21984, class_1802.field_22487, class_1802.field_22488, class_1802.field_37512, class_1802.field_37510, class_1802.field_37515, class_1802.field_37509, class_1802.field_42692, class_1802.field_42693 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public static final class_1792[] DYE = new class_1792[] { class_1802.field_8446, class_1802.field_8226, class_1802.field_8345, class_1802.field_8099, class_1802.field_8632, class_1802.field_8298, class_1802.field_8408, class_1802.field_8273, class_1802.field_8851, class_1802.field_8131, class_1802.field_8669, class_1802.field_8492, class_1802.field_8330, class_1802.field_8296, class_1802.field_8264, class_1802.field_8192 };
/*  96 */   public static final class_1792[] WOOL = new class_1792[] { class_1802.field_19044, class_1802.field_19059, class_1802.field_19055, class_1802.field_19056, class_1802.field_19053, class_1802.field_19051, class_1802.field_19057, class_1802.field_19047, class_1802.field_19052, class_1802.field_19049, class_1802.field_19046, class_1802.field_19045, class_1802.field_19050, class_1802.field_19054, class_1802.field_19058, class_1802.field_19048 };
/*  97 */   public static final class_1792[] BED = new class_1792[] { class_1802.field_8258, class_1802.field_8112, class_1802.field_8893, class_1802.field_8464, class_1802.field_8390, class_1802.field_8754, class_1802.field_8368, class_1802.field_8286, class_1802.field_8146, class_1802.field_8679, class_1802.field_8349, class_1802.field_8059, class_1802.field_8417, class_1802.field_8262, class_1802.field_8789, class_1802.field_8863 };
/*  98 */   public static final class_1792[] CARPET = new class_1792[] { class_1802.field_8850, class_1802.field_8611, class_1802.field_8115, class_1802.field_8294, class_1802.field_8290, class_1802.field_8875, class_1802.field_8664, class_1802.field_8078, class_1802.field_8654, class_1802.field_8253, class_1802.field_8384, class_1802.field_8683, class_1802.field_8580, class_1802.field_8098, class_1802.field_8482, class_1802.field_8142 };
/*  99 */   public static final class_1792[] SHULKER_BOXES = new class_1792[] { class_1802.field_8722, class_1802.field_8268, class_1802.field_8350, class_1802.field_8584, class_1802.field_8213, class_1802.field_8627, class_1802.field_8461, class_1802.field_8829, class_1802.field_8451, class_1802.field_8548, class_1802.field_8050, class_1802.field_8380, class_1802.field_8520, class_1802.field_8816, class_1802.field_8676, class_1802.field_8271 };
/* 100 */   public static final class_1792[] FLOWER = new class_1792[] { class_1802.field_17500, class_1802.field_17501, class_1802.field_17499, class_1802.field_17513, class_1802.field_8491, class_1802.field_17526, class_1802.field_17514, class_1802.field_17509, class_1802.field_17512, class_1802.field_17511, class_1802.field_8880, class_1802.field_17529, class_1802.field_17502, class_1802.field_17527, class_1802.field_17525, class_1802.field_17510 };
/* 101 */   public static final class_1792[] LEATHER_ARMORS = new class_1792[] { class_1802.field_8577, class_1802.field_8570, class_1802.field_8267, class_1802.field_8370 };
/* 102 */   public static final class_1792[] GOLDEN_ARMORS = new class_1792[] { class_1802.field_8678, class_1802.field_8416, class_1802.field_8862, class_1802.field_8753 };
/* 103 */   public static final class_1792[] IRON_ARMORS = new class_1792[] { class_1802.field_8523, class_1802.field_8396, class_1802.field_8743, class_1802.field_8660 };
/* 104 */   public static final class_1792[] DIAMOND_ARMORS = new class_1792[] { class_1802.field_8058, class_1802.field_8348, class_1802.field_8805, class_1802.field_8285 };
/* 105 */   public static final class_1792[] NETHERITE_ARMORS = new class_1792[] { class_1802.field_22028, class_1802.field_22029, class_1802.field_22027, class_1802.field_22030 };
/* 106 */   public static final class_1792[] WOODEN_TOOLS = new class_1792[] { class_1802.field_8647, class_1802.field_8876, class_1802.field_8091, class_1802.field_8406, class_1802.field_8167 };
/* 107 */   public static final class_1792[] STONE_TOOLS = new class_1792[] { class_1802.field_8387, class_1802.field_8776, class_1802.field_8528, class_1802.field_8062, class_1802.field_8431 };
/* 108 */   public static final class_1792[] IRON_TOOLS = new class_1792[] { class_1802.field_8403, class_1802.field_8699, class_1802.field_8371, class_1802.field_8475, class_1802.field_8609 };
/* 109 */   public static final class_1792[] GOLDEN_TOOLS = new class_1792[] { class_1802.field_8335, class_1802.field_8322, class_1802.field_8845, class_1802.field_8825, class_1802.field_8303 };
/* 110 */   public static final class_1792[] DIAMOND_TOOLS = new class_1792[] { class_1802.field_8377, class_1802.field_8250, class_1802.field_8802, class_1802.field_8556, class_1802.field_8527 };
/* 111 */   public static final class_1792[] NETHERITE_TOOLS = new class_1792[] { class_1802.field_22024, class_1802.field_22023, class_1802.field_22022, class_1802.field_22025, class_1802.field_22026 };
/* 112 */   public static final class_2248[] WOOD_SIGNS_ALL = new class_2248[] { class_2246.field_10284, class_2246.field_10231, class_2246.field_10330, class_2246.field_10121, class_2246.field_10544, class_2246.field_10411, class_2246.field_10401, class_2246.field_10391, class_2246.field_10265, class_2246.field_10187, class_2246.field_10587, class_2246.field_10088, class_2246.field_37552 };
/*     */ 
/*     */ 
/*     */   
/* 116 */   private static final Map<class_1792, class_1792> _logToPlanks = new HashMap<class_1792, class_1792>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private static final Map<class_1792, class_1792> _planksToLogs = new HashMap<class_1792, class_1792>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   private static final Map<class_3620, ColorfulItems> _colorMap = new HashMap<class_3620, ColorfulItems>()
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       void p(class_1767 color, String colorName, class_1792 dye, class_1792 wool, class_1792 bed, class_1792 carpet, class_1792 stainedGlass, class_1792 stainedGlassPane, class_1792 terracotta, class_1792 glazedTerracotta, class_1792 concrete, class_1792 concretePowder, class_1792 banner, class_1792 shulker, class_2248 wallBanner)
/*     */       {
/* 194 */         put(color.method_7794(), new Lists.ColorfulItems(color, colorName, dye, wool, bed, carpet, stainedGlass, stainedGlassPane, terracotta, glazedTerracotta, concrete, concretePowder, banner, shulker, wallBanner));
/*     */       }
/*     */     };
/* 197 */   private static final Map<WoodType, WoodItems> _woodMap = new HashMap<WoodType, WoodItems>()
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       void p(Lists.WoodType type, String prefix, class_1792 planks, class_1792 log, class_1792 strippedLog, class_1792 strippedWood, class_1792 wood, class_1792 sign, class_1792 door, class_1792 button, class_1792 stairs, class_1792 slab, class_1792 fence, class_1792 fenceGate, class_1792 boat, class_1792 sapling, class_1792 leaves, class_1792 pressurePlate, class_1792 trapdoor)
/*     */       {
/* 211 */         put(type, new Lists.WoodItems(prefix, planks, log, strippedLog, strippedWood, wood, sign, door, button, stairs, slab, fence, fenceGate, boat, sapling, leaves, pressurePlate, trapdoor));
/*     */       }
/*     */     };
/* 214 */   private static final HashMap<class_1792, class_1792> _cookableFoodMap = new HashMap<class_1792, class_1792>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class_1792[] RAW_FOODS;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 226 */     RAW_FOODS = (class_1792[])_cookableFoodMap.keySet().toArray(x$0 -> new class_1792[x$0]);
/* 227 */   } private static Map<class_1792, Integer> _fuelTimeMap = null;
/*     */   
/*     */   public static String stripItemName(class_1792 item) {
/* 230 */     String[] possibilities = { "item.minecraft.", "block.minecraft." };
/* 231 */     for (String possible : possibilities) {
/* 232 */       if (item.method_7876().startsWith(possible)) {
/* 233 */         return item.method_7876().substring(possible.length());
/*     */       }
/*     */     } 
/* 236 */     return item.method_7876();
/*     */   }
/*     */   
/*     */   public static class_1792[] blocksToItems(class_2248[] blocks) {
/* 240 */     class_1792[] result = new class_1792[blocks.length];
/* 241 */     for (int i = 0; i < blocks.length; i++) {
/* 242 */       result[i] = blocks[i].method_8389();
/*     */     }
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_2248[] itemsToBlocks(class_1792[] items) {
/* 249 */     ArrayList<class_2248> result = new ArrayList<>();
/* 250 */     for (class_1792 item : items) {
/* 251 */       if (item instanceof net.minecraft.class_1747) {
/* 252 */         class_2248 b = class_2248.method_9503(item);
/* 253 */         if (b != null && b != class_2246.field_10124) {
/* 254 */           result.add(b);
/*     */         }
/*     */       } 
/*     */     } 
/* 258 */     return (class_2248[])result.toArray(x$0 -> new class_2248[x$0]);
/*     */   }
/*     */   
/*     */   public static class_1792 logToPlanks(class_1792 logItem) {
/* 262 */     return _logToPlanks.getOrDefault(logItem, null);
/*     */   }
/*     */   
/*     */   public static class_1792 planksToLog(class_1792 plankItem) {
/* 266 */     return _planksToLogs.getOrDefault(plankItem, null);
/*     */   }
/*     */   
/*     */   public static ColorfulItems getColorfulItems(class_3620 color) {
/* 270 */     return _colorMap.get(color);
/*     */   }
/*     */   
/*     */   public static ColorfulItems getColorfulItems(class_1767 color) {
/* 274 */     return getColorfulItems(color.method_7794());
/*     */   }
/*     */   
/*     */   public static Collection<ColorfulItems> getColorfulItems() {
/* 278 */     return _colorMap.values();
/*     */   }
/*     */   
/*     */   public static WoodItems getWoodItems(WoodType type) {
/* 282 */     return _woodMap.get(type);
/*     */   }
/*     */   
/*     */   public static Collection<WoodItems> getWoodItems() {
/* 286 */     return _woodMap.values();
/*     */   }
/*     */   
/*     */   public static Optional<class_1792> getCookedFood(class_1792 rawFood) {
/* 290 */     return Optional.ofNullable(_cookableFoodMap.getOrDefault(rawFood, null));
/*     */   }
/*     */   
/*     */   public static String trimItemName(String name) {
/* 294 */     if (name.startsWith("block.minecraft.")) {
/* 295 */       name = name.substring("block.minecraft.".length());
/* 296 */     } else if (name.startsWith("item.minecraft.")) {
/* 297 */       name = name.substring("item.minecraft.".length());
/*     */     } 
/* 299 */     return name;
/*     */   }
/*     */   
/*     */   public static boolean areShearsEffective(class_2248 b) {
/* 303 */     return (b instanceof net.minecraft.class_2397 || b == class_2246.field_10343 || b == class_2246.field_10214 || b == class_2246.field_10588 || b == class_2246.field_10112 || b == class_2246.field_10428 || b == class_2246.field_10597 || b == class_2246.field_10589 || 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 315 */       isOfBlockType(b, class_3481.field_15481) || b == class_2246.field_22117);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isOfBlockType(class_2248 b, class_6862<class_2248> tag) {
/* 320 */     return ((Boolean)class_7923.field_41175.method_29113(b).map(e -> Boolean.valueOf(class_7923.field_41175.method_40290(e).method_40228().anyMatch(()))).orElse(Boolean.valueOf(false))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canStackTogether(class_1799 from, class_1799 to) {
/* 325 */     if (to.method_7960() && from.method_7947() <= from.method_7914())
/* 326 */       return true; 
/* 327 */     return (to.method_7909().equals(from.method_7909()) && from.method_7947() + to.method_7947() < to.method_7914());
/*     */   }
/*     */   
/*     */   private static Map<class_1792, Integer> getFuelTimeMap() {
/* 331 */     if (_fuelTimeMap == null) {
/* 332 */       _fuelTimeMap = class_2609.method_11196();
/*     */     }
/* 334 */     return _fuelTimeMap;
/*     */   }
/*     */   
/*     */   public static double getFuelAmount(class_1792... items) {
/* 338 */     double total = 0.0D;
/* 339 */     for (class_1792 item : items) {
/* 340 */       if (getFuelTimeMap().containsKey(item)) {
/* 341 */         int timeTicks = ((Integer)getFuelTimeMap().get(item)).intValue();
/*     */ 
/*     */         
/* 344 */         total += timeTicks / 200.0D;
/*     */       } 
/*     */     } 
/* 347 */     return total;
/*     */   }
/*     */   
/*     */   public static double getFuelAmount(class_1799 stack) {
/* 351 */     return getFuelAmount(new class_1792[] { stack.method_7909() }) * stack.method_7947();
/*     */   }
/*     */   
/*     */   public static boolean isFuel(class_1792 item) {
/* 355 */     return getFuelTimeMap().containsKey(item);
/*     */   }
/*     */   
/*     */   public static boolean isRawFood(class_1792 item) {
/* 359 */     return _cookableFoodMap.containsKey(item);
/*     */   }
/*     */   
/*     */   public static boolean isCreativeOnly(class_1792 item) {
/* 363 */     ArrayList<class_1792> creativeItems = new ArrayList<>(List.of(new class_1792[] { class_1802.field_8077, class_1802.field_8866, class_1802.field_8220, class_1802.field_8799, class_1802.field_8468, class_1802.field_8849, class_1802.field_8238, class_1802.field_8615, class_1802.field_8575 }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 374 */     for (class_2960 id : class_7923.field_41178.method_10235()) {
/* 375 */       if (id.method_12832().replace("_", " ").contains("spawn egg")) {
/* 376 */         creativeItems.add((class_1792)class_7923.field_41178.method_10223(id));
/*     */       }
/*     */     } 
/* 379 */     return creativeItems.contains(item);
/*     */   }
/*     */   
/*     */   public static class ColorfulItems {
/*     */     public final class_1767 color;
/*     */     public final String colorName;
/*     */     public final class_1792 dye;
/*     */     public final class_1792 wool;
/*     */     public final class_1792 bed;
/*     */     public final class_1792 carpet;
/*     */     public final class_1792 stainedGlass;
/*     */     public final class_1792 stainedGlassPane;
/*     */     public final class_1792 terracotta;
/*     */     public final class_1792 glazedTerracotta;
/*     */     public final class_1792 concrete;
/*     */     public final class_1792 concretePowder;
/*     */     public final class_1792 banner;
/*     */     public final class_1792 shulker;
/*     */     public final class_2248 wallBanner;
/*     */     
/*     */     public ColorfulItems(class_1767 color, String colorName, class_1792 dye, class_1792 wool, class_1792 bed, class_1792 carpet, class_1792 stainedGlass, class_1792 stainedGlassPane, class_1792 terracotta, class_1792 glazedTerracotta, class_1792 concrete, class_1792 concretePowder, class_1792 banner, class_1792 shulker, class_2248 wallBanner) {
/* 400 */       this.color = color;
/* 401 */       this.colorName = colorName;
/* 402 */       this.dye = dye;
/* 403 */       this.wool = wool;
/* 404 */       this.bed = bed;
/* 405 */       this.carpet = carpet;
/* 406 */       this.stainedGlass = stainedGlass;
/* 407 */       this.stainedGlassPane = stainedGlassPane;
/* 408 */       this.terracotta = terracotta;
/* 409 */       this.glazedTerracotta = glazedTerracotta;
/* 410 */       this.concrete = concrete;
/* 411 */       this.concretePowder = concretePowder;
/* 412 */       this.banner = banner;
/* 413 */       this.shulker = shulker;
/* 414 */       this.wallBanner = wallBanner;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class WoodItems {
/*     */     public final String prefix;
/*     */     public final class_1792 planks;
/*     */     public final class_1792 log;
/*     */     public final class_1792 strippedLog;
/*     */     public final class_1792 strippedWood;
/*     */     public final class_1792 wood;
/*     */     public final class_1792 sign;
/*     */     public final class_1792 door;
/*     */     public final class_1792 button;
/*     */     public final class_1792 stairs;
/*     */     public final class_1792 slab;
/*     */     public final class_1792 fence;
/*     */     public final class_1792 fenceGate;
/*     */     public final class_1792 boat;
/*     */     public final class_1792 sapling;
/*     */     public final class_1792 leaves;
/*     */     public final class_1792 pressurePlate;
/*     */     public final class_1792 trapdoor;
/*     */     
/*     */     public WoodItems(String prefix, class_1792 planks, class_1792 log, class_1792 strippedLog, class_1792 strippedWood, class_1792 wood, class_1792 sign, class_1792 door, class_1792 button, class_1792 stairs, class_1792 slab, class_1792 fence, class_1792 fenceGate, class_1792 boat, class_1792 sapling, class_1792 leaves, class_1792 pressurePlate, class_1792 trapdoor) {
/* 439 */       this.prefix = prefix;
/* 440 */       this.planks = planks;
/* 441 */       this.log = log;
/* 442 */       this.strippedLog = strippedLog;
/* 443 */       this.strippedWood = strippedWood;
/* 444 */       this.wood = wood;
/* 445 */       this.sign = sign;
/* 446 */       this.door = door;
/* 447 */       this.button = button;
/* 448 */       this.stairs = stairs;
/* 449 */       this.slab = slab;
/* 450 */       this.fence = fence;
/* 451 */       this.fenceGate = fenceGate;
/* 452 */       this.boat = boat;
/* 453 */       this.sapling = sapling;
/* 454 */       this.leaves = leaves;
/* 455 */       this.pressurePlate = pressurePlate;
/* 456 */       this.trapdoor = trapdoor;
/*     */     }
/*     */     
/*     */     public boolean isNetherWood() {
/* 460 */       return (this.planks == class_1802.field_22031 || this.planks == class_1802.field_22032);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\Lists.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */