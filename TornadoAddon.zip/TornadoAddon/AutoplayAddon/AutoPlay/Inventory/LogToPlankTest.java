/*    */ package AutoplayAddon.AutoPlay.Inventory;
/*    */ public class LogToPlankTest { public static final class ItemSlotPair extends Record {
/*    */     private final class_1792 item;
/*    */     private final FindItemResult slot;
/*    */     
/*    */     public final String toString() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #14	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;
/*    */     }
/*    */     
/*    */     public final int hashCode() {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #14	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;
/*    */     }
/*    */     
/* 14 */     public ItemSlotPair(class_1792 item, FindItemResult slot) { this.item = item; this.slot = slot; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #14	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	LAutoplayAddon/AutoPlay/Inventory/LogToPlankTest$ItemSlotPair;
/* 14 */       //   0	8	1	o	Ljava/lang/Object; } public class_1792 item() { return this.item; } public FindItemResult slot() { return this.slot; }
/*    */      }
/*    */   public static void Log2Plank() {
/* 17 */     List<ItemSlotPair> itemSlotPairs = new ArrayList<>();
/*    */     
/* 19 */     for (class_1792 currentItem : Lists.LOG) {
/* 20 */       FindItemResult slot = InvUtils.find(new class_1792[] { currentItem });
/* 21 */       if (slot.slot() != -1) {
/* 22 */         itemSlotPairs.add(new ItemSlotPair(currentItem, slot));
/*    */       }
/*    */     } 
/*    */     
/* 26 */     for (ItemSlotPair itemSlotPair : itemSlotPairs) {
/* 27 */       class_1792 currentItem = itemSlotPair.item();
/* 28 */       class_1792 plank = Lists.logToPlanks(currentItem);
/* 29 */       FindItemResult slot = itemSlotPair.slot();
/* 30 */       CraftUtil.craftItem(plank, slot.count());
/* 31 */       ChatUtils.info("Item: " + plank.method_7848().getString() + ", Slot: " + slot.slot(), new Object[0]);
/*    */     } 
/*    */   } }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\LogToPlankTest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */