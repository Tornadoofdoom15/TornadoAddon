/*     */ package AutoplayAddon.AutoPlay.Inventory;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.class_1767;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_3620;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends HashMap<class_3620, Lists.ColorfulItems>
/*     */ {
/*     */   null() {
/* 174 */     p(class_1767.field_7964, "red", class_1802.field_8264, class_1802.field_19058, class_1802.field_8789, class_1802.field_8482, class_1802.field_8636, class_1802.field_8879, class_1802.field_8353, class_1802.field_8870, class_1802.field_8197, class_1802.field_8757, class_1802.field_8586, class_1802.field_8676, class_2246.field_10279);
/* 175 */     p(class_1767.field_7952, "white", class_1802.field_8446, class_1802.field_19044, class_1802.field_8258, class_1802.field_8850, class_1802.field_8483, class_1802.field_8736, class_1802.field_8156, class_1802.field_8177, class_1802.field_8341, class_1802.field_8582, class_1802.field_8539, class_1802.field_8722, class_2246.field_10202);
/* 176 */     p(class_1767.field_7963, "black", class_1802.field_8226, class_1802.field_19059, class_1802.field_8112, class_1802.field_8611, class_1802.field_8410, class_1802.field_8157, class_1802.field_8181, class_1802.field_8096, class_1802.field_8704, class_1802.field_8516, class_1802.field_8572, class_1802.field_8268, class_2246.field_10537);
/* 177 */     p(class_1767.field_7966, "blue", class_1802.field_8345, class_1802.field_19055, class_1802.field_8893, class_1802.field_8115, class_1802.field_8126, class_1802.field_8747, class_1802.field_8455, class_1802.field_8484, class_1802.field_8737, class_1802.field_8164, class_1802.field_8128, class_1802.field_8350, class_2246.field_10067);
/* 178 */     p(class_1767.field_7957, "brown", class_1802.field_8099, class_1802.field_19056, class_1802.field_8464, class_1802.field_8294, class_1802.field_8332, class_1802.field_8501, class_1802.field_8467, class_1802.field_8394, class_1802.field_8762, class_1802.field_8437, class_1802.field_8124, class_1802.field_8584, class_2246.field_10370);
/* 179 */     p(class_1767.field_7955, "cyan", class_1802.field_8632, class_1802.field_19053, class_1802.field_8390, class_1802.field_8290, class_1802.field_8685, class_1802.field_8085, class_1802.field_8821, class_1802.field_8257, class_1802.field_8637, class_1802.field_8593, class_1802.field_8629, class_1802.field_8213, class_2246.field_10372);
/* 180 */     p(class_1767.field_7944, "gray", class_1802.field_8298, class_1802.field_19051, class_1802.field_8754, class_1802.field_8875, class_1802.field_8507, class_1802.field_8871, class_1802.field_8304, class_1802.field_8885, class_1802.field_8333, class_1802.field_8818, class_1802.field_8617, class_1802.field_8627, class_2246.field_10267);
/* 181 */     p(class_1767.field_7942, "green", class_1802.field_8408, class_1802.field_19057, class_1802.field_8368, class_1802.field_8664, class_1802.field_8734, class_1802.field_8656, class_1802.field_8798, class_1802.field_8244, class_1802.field_8120, class_1802.field_8198, class_1802.field_8295, class_1802.field_8461, class_2246.field_10594);
/* 182 */     p(class_1767.field_7951, "light_blue", class_1802.field_8273, class_1802.field_19047, class_1802.field_8286, class_1802.field_8078, class_1802.field_8869, class_1802.field_8196, class_1802.field_8717, class_1802.field_8640, class_1802.field_8364, class_1802.field_8764, class_1802.field_8379, class_1802.field_8829, class_2246.field_10050);
/* 183 */     p(class_1767.field_7967, "light_gray", class_1802.field_8851, class_1802.field_19052, class_1802.field_8146, class_1802.field_8654, class_1802.field_8363, class_1802.field_8240, class_1802.field_8133, class_1802.field_8172, class_1802.field_8735, class_1802.field_8558, class_1802.field_8855, class_1802.field_8451, class_2246.field_10604);
/* 184 */     p(class_1767.field_7961, "lime", class_1802.field_8131, class_1802.field_19049, class_1802.field_8679, class_1802.field_8253, class_1802.field_8340, class_1802.field_8581, class_1802.field_8672, class_1802.field_8649, class_1802.field_8839, class_1802.field_8418, class_1802.field_8778, class_1802.field_8548, class_2246.field_10318);
/* 185 */     p(class_1767.field_7958, "magenta", class_1802.field_8669, class_1802.field_19046, class_1802.field_8349, class_1802.field_8384, class_1802.field_8243, class_1802.field_8119, class_1802.field_8783, class_1802.field_8318, class_1802.field_8508, class_1802.field_8336, class_1802.field_8671, class_1802.field_8050, class_2246.field_10274);
/* 186 */     p(class_1767.field_7946, "orange", class_1802.field_8492, class_1802.field_19045, class_1802.field_8059, class_1802.field_8683, class_1802.field_8393, class_1802.field_8761, class_1802.field_8043, class_1802.field_8139, class_1802.field_8771, class_1802.field_8487, class_1802.field_8824, class_1802.field_8380, class_2246.field_10599);
/* 187 */     p(class_1767.field_7954, "pink", class_1802.field_8330, class_1802.field_19050, class_1802.field_8417, class_1802.field_8580, class_1802.field_8770, class_1802.field_8500, class_1802.field_8853, class_1802.field_8277, class_1802.field_8127, class_1802.field_8222, class_1802.field_8329, class_1802.field_8520, class_2246.field_10531);
/* 188 */     p(class_1767.field_7945, "purple", class_1802.field_8296, class_1802.field_19054, class_1802.field_8262, class_1802.field_8098, class_1802.field_8838, class_1802.field_8739, class_1802.field_8715, class_1802.field_8562, class_1802.field_8411, class_1802.field_8690, class_1802.field_8405, class_1802.field_8816, class_2246.field_10054);
/* 189 */     p(class_1767.field_7964, "red", class_1802.field_8264, class_1802.field_19058, class_1802.field_8789, class_1802.field_8482, class_1802.field_8636, class_1802.field_8879, class_1802.field_8353, class_1802.field_8870, class_1802.field_8197, class_1802.field_8757, class_1802.field_8586, class_1802.field_8676, class_2246.field_10279);
/* 190 */     p(class_1767.field_7947, "yellow", class_1802.field_8192, class_1802.field_19048, class_1802.field_8863, class_1802.field_8142, class_1802.field_8095, class_1802.field_8703, class_1802.field_8385, class_1802.field_8889, class_1802.field_8686, class_1802.field_8205, class_1802.field_8049, class_1802.field_8271, class_2246.field_10139);
/*     */   }
/*     */   
/*     */   void p(class_1767 color, String colorName, class_1792 dye, class_1792 wool, class_1792 bed, class_1792 carpet, class_1792 stainedGlass, class_1792 stainedGlassPane, class_1792 terracotta, class_1792 glazedTerracotta, class_1792 concrete, class_1792 concretePowder, class_1792 banner, class_1792 shulker, class_2248 wallBanner) {
/* 194 */     put(color.method_7794(), new Lists.ColorfulItems(color, colorName, dye, wool, bed, carpet, stainedGlass, stainedGlassPane, terracotta, glazedTerracotta, concrete, concretePowder, banner, shulker, wallBanner));
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Inventory\Lists$3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */