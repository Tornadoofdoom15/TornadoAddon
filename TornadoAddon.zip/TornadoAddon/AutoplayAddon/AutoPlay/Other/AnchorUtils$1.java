/*     */ package AutoplayAddon.AutoPlay.Other;
/*     */ 
/*     */ import net.minecraft.class_1267;
/*     */ 


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\AnchorUtils$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */