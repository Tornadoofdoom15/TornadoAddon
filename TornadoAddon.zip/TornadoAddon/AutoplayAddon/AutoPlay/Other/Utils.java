/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_3959;
/*    */ import net.minecraft.class_4184;
/*    */ 
/*    */ public class Utils
/*    */ {
/*    */   public static class_2338 getStaredBlock() {
/* 13 */     class_4184 camera = MeteorClient.mc.field_1773.method_19418();
/* 14 */     class_243 cameraPos = camera.method_19326();
/* 15 */     class_2338 pos = MeteorClient.mc.field_1687.method_17742(new class_3959(cameraPos, cameraPos.method_1019(class_243.method_1030(camera.method_19329(), camera.method_19330()).method_1021(197.0D)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)MeteorClient.mc.field_1724)).method_17777();
/* 16 */     int maxSearchHeight = 256;
/* 17 */     if (!MeteorClient.mc.field_1687.method_8393(pos.method_10263() >> 4, pos.method_10260() >> 4)) return null; 
/* 18 */     for (int y = pos.method_10264(); y < pos.method_10264() + maxSearchHeight; y++) {
/* 19 */       class_2338 temppos = new class_2338(pos.method_10263(), y, pos.method_10260());
/* 20 */       if (MeteorClient.mc.field_1724.method_17682() < 0.9D) {
/* 21 */         return temppos.method_10084();
/*    */       }
/* 23 */       if (!MeteorClient.mc.field_1687.method_8320(temppos).method_51367() && !MeteorClient.mc.field_1687.method_8320(temppos.method_10084()).method_51367()) {
/* 24 */         return temppos;
/*    */       }
/*    */     } 
/* 27 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\Utils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */