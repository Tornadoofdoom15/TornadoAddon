/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1914;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TradeSearchResult
/*    */ {
/*    */   private final class_1297 villager;
/*    */   private final class_1914 offer;
/*    */   private final int tradeId;
/*    */   
/*    */   public TradeSearchResult(class_1297 villager, class_1914 offer, int tradeId) {
/* 30 */     this.villager = villager;
/* 31 */     this.offer = offer;
/* 32 */     this.tradeId = tradeId;
/*    */   }
/*    */   
/*    */   public class_1297 getVillager() {
/* 36 */     return this.villager;
/* 37 */   } public class_1914 getOffer() { return this.offer; } public int getTradeId() {
/* 38 */     return this.tradeId;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\Villagerutils$TradeSearchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */