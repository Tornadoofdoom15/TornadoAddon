/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_745;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerCopyEntity
/*    */   extends class_745
/*    */ {
/*    */   private boolean ghost;
/*    */   
/*    */   public PlayerCopyEntity() {
/* 22 */     this((class_1657)(class_310.method_1551()).field_1724);
/*    */   }
/*    */   
/*    */   public PlayerCopyEntity(class_1657 player) {
/* 26 */     this(player, player.method_23317(), player.method_23318(), player.method_23321());
/*    */   }
/*    */   
/*    */   public PlayerCopyEntity(class_1657 player, double x, double y, double z) {
/* 30 */     super((class_310.method_1551()).field_1687, player.method_7334());
/*    */     
/* 32 */     method_5878((class_1297)player);
/*    */ 
/*    */ 
/*    */     
/* 36 */     method_3123();
/* 37 */     this.field_6011.method_12778(field_7518, player.method_5841().method_12789(field_7518));
/* 38 */     method_5826(UUID.randomUUID());
/*    */   }
/*    */   
/*    */   public void spawn() {
/* 42 */     method_31482();
/* 43 */     (class_310.method_1551()).field_1687.method_53875((class_1297)this);
/*    */   }
/*    */   
/*    */   public void despawn() {
/* 47 */     (class_310.method_1551()).field_1687.method_2945(method_5628(), class_1297.class_5529.field_26999);
/*    */   }
/*    */   
/*    */   public void setGhost(boolean ghost) {
/* 51 */     this.ghost = ghost;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_5767() {
/* 56 */     return (this.ghost || super.method_5767());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_5756(class_1657 player) {
/* 61 */     return (!this.ghost && super.method_5756(player));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\PlayerCopyEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */