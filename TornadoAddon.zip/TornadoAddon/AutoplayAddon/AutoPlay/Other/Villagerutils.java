/*     */ package AutoplayAddon.AutoPlay.Other;
/*     */ 
/*     */ import AutoplayAddon.AutoPlay.Inventory.InventoryUtils;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import java.util.Map;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1772;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1887;
/*     */ import net.minecraft.class_1889;
/*     */ import net.minecraft.class_1890;
/*     */ import net.minecraft.class_1914;
/*     */ import net.minecraft.class_1916;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2815;
/*     */ import net.minecraft.class_2824;
/*     */ import net.minecraft.class_2863;
/*     */ 
/*     */ public class Villagerutils
/*     */ {
/*     */   public static class TradeSearchResult {
/*     */     private final class_1297 villager;
/*     */     private final class_1914 offer;
/*     */     private final int tradeId;
/*     */     
/*     */     public TradeSearchResult(class_1297 villager, class_1914 offer, int tradeId) {
/*  30 */       this.villager = villager;
/*  31 */       this.offer = offer;
/*  32 */       this.tradeId = tradeId;
/*     */     }
/*     */     
/*     */     public class_1297 getVillager() {
/*  36 */       return this.villager;
/*  37 */     } public class_1914 getOffer() { return this.offer; } public int getTradeId() {
/*  38 */       return this.tradeId;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static TradeSearchResult findOfferForItem(class_1799 desiredItem, Map<class_1297, class_1916> villagerTrades) {
/*  44 */     for (Map.Entry<class_1297, class_1916> entry : villagerTrades.entrySet()) {
/*  45 */       class_1297 villager = entry.getKey();
/*  46 */       class_1916 offers = entry.getValue();
/*  47 */       int tradeId = 0;
/*  48 */       for (class_1914 offer : offers) {
/*  49 */         class_1799 sellItem = offer.method_8250();
/*  50 */         if (class_1799.method_31577(sellItem, desiredItem)) {
/*  51 */           return new TradeSearchResult(villager, offer, tradeId);
/*     */         }
/*  53 */         tradeId++;
/*     */       } 
/*     */     } 
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_1799 createBookItemStack(class_1887 enchantment, int level) {
/*  61 */     class_1799 enchantedBook = new class_1799((class_1935)class_1802.field_8598);
/*  62 */     class_1772.method_7807(enchantedBook, new class_1889(enchantment, level));
/*  63 */     return enchantedBook;
/*     */   }
/*     */   
/*     */   public static void buyItem(class_1799 desiredItem, Map<class_1297, class_1916> villagerTrades) {
/*  67 */     TradeSearchResult result = findOfferForItem(desiredItem, villagerTrades);
/*  68 */     if (result != null) {
/*  69 */       class_1297 villager = result.getVillager();
/*  70 */       ChatUtils.info("interacting with villager " + villager.method_5628() + " at " + villager.method_19538(), new Object[0]);
/*  71 */       BotUtils.setPos(villager.method_19538());
/*  72 */       PacketUtils.packetQueue.add(class_2824.method_34207(villager, false, class_1268.field_5808));
/*  73 */       ServerSideValues.lastScreenSyncId++;
/*  74 */       PacketUtils.packetQueue.add(new class_2863(result.getTradeId()));
/*  75 */       InventoryUtils.moveItemToEmptySpot(2, 39);
/*  76 */       ChatUtils.info("closing screen with id " + ServerSideValues.lastScreenSyncId, new Object[0]);
/*  77 */       PacketUtils.packetQueue.add(new class_2815(ServerSideValues.lastScreenSyncId));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getDetailedItemDescription(class_1799 itemStack) {
/*  82 */     if (itemStack.method_7909() instanceof class_1772) {
/*  83 */       Map<class_1887, Integer> enchantments = class_1890.method_8222(itemStack);
/*  84 */       StringBuilder enchantmentDetails = new StringBuilder();
/*     */       
/*  86 */       for (Map.Entry<class_1887, Integer> entry : enchantments.entrySet()) {
/*  87 */         class_1887 enchantment = entry.getKey();
/*  88 */         Integer level = entry.getValue();
/*  89 */         String enchantmentName = enchantment.method_8179(0).getString();
/*  90 */         enchantmentDetails.append("Enchanted Book (").append(enchantmentName)
/*  91 */           .append(" lvl ").append(level).append("), ");
/*     */       } 
/*     */       
/*  94 */       if (enchantmentDetails.length() > 0) {
/*  95 */         enchantmentDetails.setLength(enchantmentDetails.length() - 2);
/*     */       }
/*  97 */       return enchantmentDetails.toString();
/*     */     } 
/*     */     
/* 100 */     return itemStack.method_7909().method_7848().getString();
/*     */   }
/*     */   
/*     */   public static String getPriceDescription(class_1914 offer) {
/* 104 */     class_1799 adjustedPrice1 = offer.method_19272();
/* 105 */     class_1799 price2 = offer.method_8247();
/*     */     
/* 107 */     String price1Details = "" + adjustedPrice1.method_7947() + "x " + adjustedPrice1.method_7947();
/* 108 */     if (!price2.method_7960()) {
/* 109 */       String price2Details = "" + price2.method_7947() + "x " + price2.method_7947();
/* 110 */       return price1Details + " and " + price1Details;
/*     */     } 
/* 112 */     return price1Details;
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\Villagerutils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */