/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ 
/*    */ public class RandomTp
/*    */ {
/*    */   private static class_243 gettppos(class_243 playerpos, int distance) {
/* 10 */     Random random = new Random();
/*    */ 
/*    */     
/* 13 */     double halfLength = (distance / 2);
/*    */ 
/*    */     
/* 16 */     double dx = playerpos.field_1352 + halfLength - random.nextDouble() * distance;
/* 17 */     double dz = playerpos.field_1350 + halfLength - random.nextDouble() * distance;
/*    */ 
/*    */     
/* 20 */     double dy = Math.max(playerpos.field_1351 + halfLength - random.nextDouble() * distance, -115.0D);
/*    */     
/* 22 */     class_243 pos = new class_243(dx, dy, dz);
/* 23 */     FastBox fastBox = new FastBox(pos);
/* 24 */     if (fastBox.isCollidingWithBlocks()) {
/* 25 */       return null;
/*    */     }
/* 27 */     return pos;
/*    */   }
/*    */   
/*    */   public static class_243 findValidTpPos(class_243 playerpos, int distance) {
/* 31 */     for (int i = 0; i < 200; i++) {
/* 32 */       class_243 potentialPos = gettppos(playerpos, distance);
/* 33 */       if (potentialPos != null) {
/* 34 */         return potentialPos;
/*    */       }
/*    */     } 
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\RandomTp.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */