/*   */ package AutoplayAddon.AutoPlay.Other;
/*   */ 
/*   */ public class WaitUtil {
/*   */   public static void wait1sec() {
/*   */     try {
/* 6 */       Thread.sleep(1000L);
/* 7 */     } catch (InterruptedException ee) {
/* 8 */       ee.printStackTrace();
/*   */     } 
/*   */   }
/*   */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\WaitUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */