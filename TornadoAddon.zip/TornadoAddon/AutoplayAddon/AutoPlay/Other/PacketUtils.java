/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import AutoplayAddon.Mixins.ClientConnectionMixin;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import io.netty.channel.Channel;
/*    */ import java.util.LinkedList;
/*    */ import java.util.Queue;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2828;
/*    */ 
/*    */ public class PacketUtils
/*    */ {
/* 15 */   public static final Queue<class_2596<?>> packetQueue = new LinkedList<>();
/*    */   public static void sendAllPacketsInQueue() {
/* 17 */     StringBuilder packetNames = new StringBuilder();
/* 18 */     int amount = packetQueue.size();
/* 19 */     if (amount == 0)
/*    */       return; 
/* 21 */     for (class_2596<?> packet : packetQueue) {
/* 22 */       String packetName = packet.getClass().getSimpleName();
/* 23 */       packetName = packetName.replace("C2SPacket", "");
/* 24 */       if (packetNames.length() > 0) {
/* 25 */         packetNames.append(", ");
/*    */       }
/* 27 */       packetNames.append(packetName);
/*    */     } 
/*    */ 
/*    */     
/* 31 */     System.out.println("" + System.currentTimeMillis() + " " + System.currentTimeMillis() + " " + amount);
/*    */     
/* 33 */     ClientConnectionMixin accessor = (ClientConnectionMixin)MeteorClient.mc.method_1562().method_48296();
/* 34 */     Channel channel = accessor.getChannel();
/* 35 */     for (class_2596<?> packet : packetQueue) channel.write(packet); 
/* 36 */     channel.flush();
/* 37 */     packetQueue.clear();
/* 38 */     ServerSideValues.updateAndAdd(amount, System.nanoTime());
/*    */   }
/*    */ 
/*    */   
/*    */   public static void addMovePacketToQueue(boolean onGround, class_243 pos, Float pitch, Float yaw) {
/*    */     class_2828.class_2829 class_2829;
/* 44 */     if (pitch != null && yaw != null) {
/* 45 */       if (pos != null) {
/* 46 */         class_2828.class_2830 class_2830 = new class_2828.class_2830(pos.field_1352, pos.field_1351, pos.field_1350, yaw.floatValue(), pitch.floatValue(), onGround);
/*    */       } else {
/* 48 */         class_2828.class_2831 class_2831 = new class_2828.class_2831(yaw.floatValue(), pitch.floatValue(), onGround);
/*    */       }
/*    */     
/* 51 */     } else if (pos == null) {
/* 52 */       if (ServerSideValues.predictallowedPlayerTicks() > 20) {
/* 53 */         class_2828.class_2831 class_2831 = new class_2828.class_2831(MeteorClient.mc.field_1724.method_36454(), MeteorClient.mc.field_1724.method_36455(), onGround);
/*    */       } else {
/* 55 */         class_2828.class_5911 class_5911 = new class_2828.class_5911(onGround);
/*    */       }
/*    */     
/* 58 */     } else if (ServerSideValues.predictallowedPlayerTicks() > 20) {
/* 59 */       class_2828.class_2830 class_2830 = new class_2828.class_2830(pos.field_1352, pos.field_1351, pos.field_1350, MeteorClient.mc.field_1724.method_36454(), MeteorClient.mc.field_1724.method_36455(), onGround);
/*    */     } else {
/* 61 */       class_2829 = new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, onGround);
/*    */     } 
/*    */ 
/*    */     
/* 65 */     ServerSideValues.HandleMovePacketSafe((class_2828)class_2829);
/* 66 */     packetQueue.add(class_2829);
/*    */   }
/*    */   
/*    */   public static void sendPacket(class_2596<?> packet) {
/* 70 */     ServerSideValues.updateAndAdd(1L, System.nanoTime());
/* 71 */     if (packet instanceof net.minecraft.class_2886 || packet instanceof net.minecraft.class_2885) ServerSideValues.handleUse(); 
/* 72 */     ClientConnectionMixin accessor = (ClientConnectionMixin)MeteorClient.mc.method_1562().method_48296();
/* 73 */     Channel channel = accessor.getChannel();
/* 74 */     channel.writeAndFlush(packet);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\PacketUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */