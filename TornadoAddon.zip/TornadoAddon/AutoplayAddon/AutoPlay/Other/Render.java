/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*    */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*    */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*    */ import net.minecraft.class_1922;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_238;
/*    */ import net.minecraft.class_265;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ public class Render {
/*    */   public static void renderBlock(Render3DEvent event, class_2338 pos, double progress) {
/* 14 */     class_2680 state = MeteorClient.mc.field_1687.method_8320(pos);
/* 15 */     class_265 shape = state.method_26218((class_1922)MeteorClient.mc.field_1687, pos);
/* 16 */     if (shape == null || shape.method_1110())
/* 17 */       return;  class_238 orig = shape.method_1107();
/* 18 */     double shrinkFactor = 1.0D - progress;
/* 19 */     Color cSides = new Color();
/* 20 */     Color cLines = new Color();
/* 21 */     class_238 box = orig.method_1002(orig
/* 22 */         .method_17939() * shrinkFactor, orig
/* 23 */         .method_17940() * shrinkFactor, orig
/* 24 */         .method_17941() * shrinkFactor);
/*    */ 
/*    */     
/* 27 */     double xShrink = orig.method_17939() * shrinkFactor / 2.0D;
/* 28 */     double yShrink = orig.method_17940() * shrinkFactor / 2.0D;
/* 29 */     double zShrink = orig.method_17941() * shrinkFactor / 2.0D;
/*    */     
/* 31 */     double x1 = pos.method_10263() + box.field_1323 + xShrink;
/* 32 */     double y1 = pos.method_10264() + box.field_1322 + yShrink;
/* 33 */     double z1 = pos.method_10260() + box.field_1321 + zShrink;
/* 34 */     double x2 = pos.method_10263() + box.field_1320 + xShrink;
/* 35 */     double y2 = pos.method_10264() + box.field_1325 + yShrink;
/* 36 */     double z2 = pos.method_10260() + box.field_1324 + zShrink;
/*    */     
/* 38 */     Color c1Sides = (new Color(25, 252, 25, 150)).copy().a((new Color(25, 252, 25, 150)).a / 2);
/* 39 */     Color c2Sides = (new Color(255, 25, 25, 150)).copy().a((new Color(255, 25, 25, 150)).a / 2);
/*    */     
/* 41 */     cSides.set(
/* 42 */         (int)Math.round(c1Sides.r + (c2Sides.r - c1Sides.r) * progress), 
/* 43 */         (int)Math.round(c1Sides.g + (c2Sides.g - c1Sides.g) * progress), 
/* 44 */         (int)Math.round(c1Sides.b + (c2Sides.b - c1Sides.b) * progress), 
/* 45 */         (int)Math.round(c1Sides.a + (c2Sides.a - c1Sides.a) * progress));
/*    */ 
/*    */     
/* 48 */     Color c1Lines = new Color(25, 252, 25, 150);
/* 49 */     Color c2Lines = new Color(255, 25, 25, 150);
/*    */     
/* 51 */     cLines.set(
/* 52 */         (int)Math.round(c1Lines.r + (c2Lines.r - c1Lines.r) * progress), 
/* 53 */         (int)Math.round(c1Lines.g + (c2Lines.g - c1Lines.g) * progress), 
/* 54 */         (int)Math.round(c1Lines.b + (c2Lines.b - c1Lines.b) * progress), 
/* 55 */         (int)Math.round(c1Lines.a + (c2Lines.a - c1Lines.a) * progress));
/*    */ 
/*    */     
/* 58 */     event.renderer.box(x1, y1, z1, x2, y2, z2, cSides, cLines, ShapeMode.Both, 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\Render.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */