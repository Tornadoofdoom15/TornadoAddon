/*     */ package AutoplayAddon.AutoPlay.Other;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ 
/*     */ public class FastBox {
/*     */   public List<class_243> corners;
/*     */   
/*     */   public FastBox(FastBox other) {
/*  16 */     this.corners = new ArrayList<>(other.corners);
/*  17 */     this.position = other.position;
/*     */   }
/*     */   public class_243 position;
/*     */   public FastBox(class_238 box, class_243 to) {
/*  21 */     this.position = to;
/*  22 */     calculateCorners(box);
/*     */   }
/*     */   public FastBox(class_243 to) {
/*  25 */     this.position = to;
/*  26 */     class_238 box = new class_238(to.field_1352 - 0.3D, to.field_1351, to.field_1350 - 0.3D, to.field_1352 + 0.3D, to.field_1351 + MeteorClient.mc.field_1724.method_17682(), to.field_1350 + 0.3D);
/*  27 */     box.method_1014(-0.0625D);
/*  28 */     calculateCorners(box);
/*     */   }
/*     */   public FastBox(class_1297 entity) {
/*  31 */     this.position = entity.method_19538();
/*  32 */     class_238 box = entity.method_5829();
/*  33 */     class_238 newbox = box.method_1014(-0.06D);
/*  34 */     calculateCorners(newbox);
/*     */   }
/*     */ 
/*     */   
/*     */   private void calculateCorners(class_238 box) {
/*  39 */     double minX = box.field_1323;
/*  40 */     double minY = box.field_1322;
/*  41 */     double minZ = box.field_1321;
/*  42 */     double maxX = box.field_1320;
/*  43 */     double maxY = box.field_1325;
/*  44 */     double maxZ = box.field_1324;
/*     */     
/*  46 */     List<Double> xPoints = generatePoints(minX, maxX);
/*  47 */     List<Double> yPoints = generatePoints(minY, maxY);
/*  48 */     List<Double> zPoints = generatePoints(minZ, maxZ);
/*     */     
/*  50 */     List<class_243> allPoints = new ArrayList<>();
/*     */     
/*  52 */     for (Iterator<Double> iterator = xPoints.iterator(); iterator.hasNext(); ) { double x = ((Double)iterator.next()).doubleValue();
/*  53 */       for (Iterator<Double> iterator1 = yPoints.iterator(); iterator1.hasNext(); ) { double y = ((Double)iterator1.next()).doubleValue();
/*  54 */         for (Iterator<Double> iterator2 = zPoints.iterator(); iterator2.hasNext(); ) { double z = ((Double)iterator2.next()).doubleValue();
/*  55 */           allPoints.add(new class_243(x, y, z)); }
/*     */          }
/*     */        }
/*     */     
/*  59 */     this.corners = allPoints;
/*     */   }
/*     */   
/*     */   private List<Double> generatePoints(double min, double max) {
/*  63 */     List<Double> points = new ArrayList<>();
/*     */     
/*  65 */     double diff = max - min;
/*  66 */     int numPoints = (int)Math.ceil(diff);
/*     */ 
/*     */     
/*  69 */     if (numPoints <= 1) {
/*  70 */       points.add(Double.valueOf(min));
/*  71 */       points.add(Double.valueOf(max));
/*  72 */       return points;
/*     */     } 
/*     */     
/*  75 */     double interval = diff / numPoints;
/*     */     
/*  77 */     for (int i = 0; i <= numPoints; i++) {
/*  78 */       points.add(Double.valueOf(min + interval * i));
/*     */     }
/*     */     
/*  81 */     return points;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class_2338 vecToBlockPos(class_243 vec) {
/*  87 */     return new class_2338((int)Math.floor(vec.field_1352), (int)Math.floor(vec.field_1351), (int)Math.floor(vec.field_1350));
/*     */   }
/*     */   
/*     */   public void offset(class_243 velocity) {
/*  91 */     this.position = this.position.method_1019(velocity);
/*  92 */     for (int i = 0; i < this.corners.size(); i++) {
/*  93 */       class_243 corner = this.corners.get(i);
/*  94 */       this.corners.set(i, corner.method_1019(velocity));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class_243 getDirectionFromYawAndPitch(float yaw, float pitch) {
/*  99 */     double y = -Math.sin(Math.toRadians(pitch));
/* 100 */     double xzFactor = Math.cos(Math.toRadians(pitch));
/* 101 */     double x = -xzFactor * Math.sin(Math.toRadians(yaw));
/* 102 */     double z = xzFactor * Math.cos(Math.toRadians(yaw));
/* 103 */     return (new class_243(x, y, z)).method_1029();
/*     */   }
/*     */   
/*     */   public void offsetInLookDirection(double blocks) {
/* 107 */     class_243 lookDirection = getDirectionFromYawAndPitch(MeteorClient.mc.field_1724.method_5705(1.0F), MeteorClient.mc.field_1724.method_5695(1.0F));
/* 108 */     class_243 offset = lookDirection.method_1021(blocks);
/* 109 */     offset(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<class_2338> getOccupiedBlockPos() {
/* 114 */     List<class_2338> occupiedBlocks = new ArrayList<>();
/* 115 */     for (class_243 corner : this.corners) {
/* 116 */       class_2338 blockPos = vecToBlockPos(corner);
/* 117 */       if (!occupiedBlocks.contains(blockPos)) {
/* 118 */         occupiedBlocks.add(blockPos);
/*     */       }
/*     */     } 
/* 121 */     return occupiedBlocks;
/*     */   }
/*     */   
/*     */   public boolean isCollidingWithBlocks() {
/* 125 */     List<class_2338> cache = new ArrayList<>();
/*     */     
/* 127 */     for (class_243 corner : this.corners) {
/* 128 */       class_2338 blockPos = vecToBlockPos(corner);
/* 129 */       if (cache.contains(blockPos)) {
/*     */         continue;
/*     */       }
/* 132 */       cache.add(blockPos);
/* 133 */       if (MeteorClient.mc.field_1687.method_8320(blockPos).method_51367())
/*     */       {
/* 135 */         return true;
/*     */       }
/*     */     } 
/* 138 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\FastBox.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */