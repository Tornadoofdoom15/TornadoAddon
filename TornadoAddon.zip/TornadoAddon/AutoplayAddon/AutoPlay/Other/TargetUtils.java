/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.systems.friends.Friends;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_3532;
/*    */ import net.minecraft.class_4184;
/*    */ 
/*    */ public class TargetUtils
/*    */ {
/*    */   public enum Mode {
/* 18 */     PlayerName,
/* 19 */     ClosestPlayer,
/* 20 */     ClosestToCrosshair;
/*    */   }
/*    */   
/*    */   public static class_1297 getTarget(boolean ignoreFriends, Mode mode, List<String> players, Set<class_1299<?>> entityTypes) {
/* 24 */     class_1297 closestEntity = null;
/* 25 */     double closestMetric = Double.MAX_VALUE;
/*    */     
/* 27 */     class_4184 camera = MeteorClient.mc.field_1773.method_19418();
/* 28 */     class_243 viewVec = getViewVector(camera);
/*    */     
/* 30 */     for (class_1297 entity : MeteorClient.mc.field_1687.method_18112()) {
/*    */       double metric; class_1657 player; class_243 toEntityVec; double angle;
/* 32 */       if (!entityTypes.contains(entity.method_5864()) || (
/* 33 */         entity.equals(MeteorClient.mc.field_1724) && mode != Mode.PlayerName))
/*    */         continue; 
/* 35 */       if (entity.method_19538().method_1022(ServerSideValues.serversidedposition) > 40000.0D)
/*    */         continue; 
/* 37 */       if (entity instanceof class_1657 && ignoreFriends && mode != Mode.PlayerName && Friends.get().isFriend((class_1657)entity)) {
/*    */         continue;
/*    */       }
/* 40 */       switch (mode) {
/*    */         
/*    */         case ClosestPlayer:
/* 43 */           metric = MeteorClient.mc.field_1724.method_5858(entity);
/*    */           break;
/*    */         
/*    */         case PlayerName:
/* 47 */           if (!(entity instanceof class_1657))
/* 48 */             continue;  player = (class_1657)entity;
/* 49 */           if (!players.contains(player.method_5477().getString()))
/* 50 */             continue;  metric = MeteorClient.mc.field_1724.method_5858((class_1297)player);
/*    */           break;
/*    */         case ClosestToCrosshair:
/* 53 */           toEntityVec = entity.method_19538().method_1020(camera.method_19326()).method_1029();
/* 54 */           angle = Math.acos(viewVec.method_1026(toEntityVec) / viewVec.method_1033() * toEntityVec.method_1033());
/* 55 */           metric = angle;
/*    */           break;
/*    */         default:
/* 58 */           throw new IllegalStateException("Unexpected value: " + mode);
/*    */       } 
/*    */       
/* 61 */       if (metric < closestMetric) {
/* 62 */         closestEntity = entity;
/* 63 */         closestMetric = metric;
/*    */       } 
/*    */     } 
/*    */     
/* 67 */     return closestEntity;
/*    */   }
/*    */ 
/*    */   
/*    */   private static class_243 getViewVector(class_4184 camera) {
/* 72 */     float pitch = camera.method_19329() * 0.017453292F;
/* 73 */     float yaw = -camera.method_19330() * 0.017453292F;
/* 74 */     float h = class_3532.method_15362(yaw);
/* 75 */     float i = class_3532.method_15374(yaw);
/* 76 */     float j = class_3532.method_15362(pitch);
/* 77 */     float k = class_3532.method_15374(pitch);
/* 78 */     return new class_243((i * j), -k, (h * j));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\TargetUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */