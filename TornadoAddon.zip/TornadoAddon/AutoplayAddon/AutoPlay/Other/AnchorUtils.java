/*     */ package AutoplayAddon.AutoPlay.Other;
/*     */ import AutoplayAddon.AutoPlay.Movement.Paths.MulitPath;
/*     */ import AutoplayAddon.modules.Disabler;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
/*     */ import meteordevelopment.meteorclient.mixininterface.IExplosion;
/*     */ import meteordevelopment.meteorclient.systems.modules.Modules;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1267;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1294;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1927;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2868;
/*     */ import net.minecraft.class_2885;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_3959;
/*     */ import net.minecraft.class_3965;
/*     */ 
/*     */ public class AnchorUtils {
/*     */   private static class_1927 explosion;
/*     */   
/*     */   @EventHandler
/*     */   private static void onGameJoined(GameJoinedEvent event) {
/*  40 */     explosion = new class_1927((class_1937)MeteorClient.mc.field_1687, null, 0.0D, 0.0D, 0.0D, 6.0F, false, class_1927.class_4179.field_18687);
/*     */   }
/*     */   public static class_243 getLeastDamageTeleport(class_2338 anchorPos) {
/*  43 */     if (anchorPos == null) return null; 
/*  44 */     int numPoints = 400;
/*  45 */     double radius = 5.9D;
/*  46 */     class_243 center = anchorPos.method_46558();
/*     */     
/*  48 */     class_243 bestPoint = null;
/*  49 */     double lowestDamage = Double.MAX_VALUE;
/*  50 */     class_243 origin = MeteorClient.mc.field_1724.method_19538();
/*  51 */     for (int i = 0; i < 400; i++) {
/*  52 */       double phi = Math.acos(1.0D - 2.0D * (i + 0.5D) / 400.0D);
/*  53 */       double theta = Math.PI * (1.0D + Math.sqrt(5.0D)) * i;
/*     */       
/*  55 */       double x = center.field_1352 + 5.9D * Math.sin(phi) * Math.cos(theta);
/*  56 */       double y = center.field_1351 + 5.9D * Math.cos(phi);
/*  57 */       double z = center.field_1350 + 5.9D * Math.sin(phi) * Math.sin(theta);
/*     */       
/*  59 */       class_243 spherePoint = new class_243(x, y, z);
/*  60 */       class_243 belowPoint = spherePoint.method_1023(0.0D, MeteorClient.mc.field_1724.method_18381(MeteorClient.mc.field_1724.method_18376()), 0.0D);
/*     */       
/*  62 */       FastBox fastBox = new FastBox(belowPoint);
/*  63 */       if (!fastBox.isCollidingWithBlocks()) {
/*  64 */         double damage = bedDamage(belowPoint, (class_1657)MeteorClient.mc.field_1724, center);
/*  65 */         if (damage < lowestDamage) {
/*  66 */           lowestDamage = damage;
/*  67 */           bestPoint = belowPoint;
/*     */         } 
/*     */       } 
/*     */     } 
/*  71 */     MeteorClient.mc.field_1724.method_23327(origin.field_1352, origin.field_1351, origin.field_1350);
/*  72 */     return bestPoint;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double bedDamage(class_243 playerpos, class_1657 player, class_243 bedpos) {
/*  77 */     if ((MeteorClient.mc.field_1724.method_31549()).field_7477) return 0.0D;
/*     */     
/*  79 */     double modDistance = Math.sqrt(playerpos.method_1025(bedpos));
/*  80 */     if (modDistance > 10.0D) return 0.0D;
/*     */     
/*  82 */     double exposure = getExposure(playerpos, bedpos, player);
/*  83 */     double impact = (1.0D - modDistance / 10.0D) * exposure;
/*  84 */     double damage = (impact * impact + impact) / 2.0D * 7.0D * 10.0D + 1.0D;
/*     */ 
/*     */     
/*  87 */     damage = getDamageForDifficulty(damage);
/*     */ 
/*     */     
/*  90 */     damage = resistanceReduction((class_1309)player, damage);
/*     */ 
/*     */     
/*  93 */     damage = getDamageLeft((float)damage, player.method_6096(), (float)player.method_5996(class_5134.field_23725).method_6194());
/*     */ 
/*     */     
/*  96 */     ((IExplosion)explosion).set(bedpos, 5.0F, true);
/*  97 */     damage = blastProtReduction((class_1297)player, damage, explosion);
/*     */     
/*  99 */     if (damage < 0.0D) damage = 0.0D; 
/* 100 */     return damage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getExposure(class_243 playerpos, class_243 source, class_1657 player) {
/* 108 */     double playerWidth = 0.6D;
/* 109 */     double playerDepth = 0.6D;
/* 110 */     double playerHeight = player.method_17682();
/*     */ 
/*     */     
/* 113 */     class_238 box = new class_238(playerpos.field_1352 - 0.3D, playerpos.field_1351, playerpos.field_1350 - 0.3D, playerpos.field_1352 + 0.3D, playerpos.field_1351 + playerHeight, playerpos.field_1350 + 0.3D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     double d = 1.0D / ((box.field_1320 - box.field_1323) * 2.0D + 1.0D);
/* 123 */     double e = 1.0D / ((box.field_1325 - box.field_1322) * 2.0D + 1.0D);
/* 124 */     double f = 1.0D / ((box.field_1324 - box.field_1321) * 2.0D + 1.0D);
/* 125 */     double g = (1.0D - Math.floor(1.0D / d) * d) / 2.0D;
/* 126 */     double h = (1.0D - Math.floor(1.0D / f) * f) / 2.0D;
/* 127 */     if (d >= 0.0D && e >= 0.0D && f >= 0.0D) {
/* 128 */       int i = 0;
/* 129 */       int j = 0;
/*     */       double k;
/* 131 */       for (k = 0.0D; k <= 1.0D; k += d) {
/* 132 */         double l; for (l = 0.0D; l <= 1.0D; l += e) {
/* 133 */           double m; for (m = 0.0D; m <= 1.0D; m += f) {
/* 134 */             double n = class_3532.method_16436(k, box.field_1323, box.field_1320);
/* 135 */             double o = class_3532.method_16436(l, box.field_1322, box.field_1325);
/* 136 */             double p = class_3532.method_16436(m, box.field_1321, box.field_1324);
/* 137 */             class_243 vec3d = new class_243(n + g, o, p + h);
/* 138 */             if (MeteorClient.mc.field_1687.method_17742(new class_3959(vec3d, source, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, class_3726.method_16195((class_1297)player))).method_17783() == class_239.class_240.field_1333) {
/* 139 */               i++;
/*     */             }
/*     */             
/* 142 */             j++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 147 */       return i / j;
/*     */     } 
/* 149 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   private static double blastProtReduction(class_1297 player, double damage, class_1927 explosion) {
/* 154 */     int protLevel = class_1890.method_8219(player.method_5661(), MeteorClient.mc.field_1687.method_48963().method_48807(explosion));
/* 155 */     if (protLevel > 20) protLevel = 20;
/*     */     
/* 157 */     damage *= 1.0D - protLevel / 25.0D;
/* 158 */     return (damage < 0.0D) ? 0.0D : damage;
/*     */   }
/*     */   
/*     */   private static double getDamageForDifficulty(double damage) {
/* 162 */     switch (MeteorClient.mc.field_1687.method_8407()) { case field_5801: case field_5805: case field_5807:  }  return 
/*     */ 
/*     */ 
/*     */       
/* 166 */       damage;
/*     */   }
/*     */ 
/*     */   
/*     */   private static double resistanceReduction(class_1309 player, double damage) {
/* 171 */     if (player.method_6059(class_1294.field_5907)) {
/* 172 */       int lvl = player.method_6112(class_1294.field_5907).method_5578() + 1;
/* 173 */       damage *= 1.0D - lvl * 0.2D;
/*     */     } 
/*     */     
/* 176 */     return (damage < 0.0D) ? 0.0D : damage;
/*     */   }
/*     */   
/*     */   public static float getDamageLeft(float damage, float armor, float armorToughness) {
/* 180 */     float f = 2.0F + armorToughness / 4.0F;
/* 181 */     float g = class_3532.method_15363(armor - damage / f, armor * 0.2F, 20.0F);
/* 182 */     return damage * (1.0F - g / 25.0F);
/*     */   }
/*     */   
/*     */   public static void switchToHotbar(class_1792 targetItem) {
/* 186 */     for (int i = 0; i < 9; i++) {
/* 187 */       if (MeteorClient.mc.field_1724.method_31548().method_5438(i).method_7909() == targetItem) {
/* 188 */         PacketUtils.packetQueue.add(new class_2868(i));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class_2338 getAnchorPos(class_1297 entity) {
/* 194 */     class_238 box = entity.method_5829();
/* 195 */     class_243 predictedpos = entity.method_19538();
/*     */     
/* 197 */     FastBox fastBox = new FastBox(box, predictedpos);
/* 198 */     List<class_2338> collidedBlocks = fastBox.getOccupiedBlockPos();
/* 199 */     List<class_2338> trapBlocks = new ArrayList<>();
/*     */     
/* 201 */     int minX = Integer.MAX_VALUE;
/* 202 */     int maxX = Integer.MIN_VALUE;
/* 203 */     int minY = Integer.MAX_VALUE;
/* 204 */     int maxY = Integer.MIN_VALUE;
/* 205 */     int minZ = Integer.MAX_VALUE;
/* 206 */     int maxZ = Integer.MIN_VALUE;
/*     */     
/* 208 */     for (class_2338 pos : collidedBlocks) {
/* 209 */       minX = Math.min(minX, pos.method_10263());
/* 210 */       maxX = Math.max(maxX, pos.method_10263());
/* 211 */       minY = Math.min(minY, pos.method_10264());
/* 212 */       maxY = Math.max(maxY, pos.method_10264());
/* 213 */       minZ = Math.min(minZ, pos.method_10260());
/* 214 */       maxZ = Math.max(maxZ, pos.method_10260());
/*     */     } 
/*     */     
/* 217 */     for (class_2338 blockPos : collidedBlocks) {
/* 218 */       for (class_2350 dir : class_2350.values()) {
/* 219 */         class_2338 offsetPos = blockPos.method_10093(dir);
/* 220 */         if (!collidedBlocks.contains(offsetPos)) {
/* 221 */           trapBlocks.add(offsetPos);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 227 */     for (int x = minX; x <= maxX; x++) {
/* 228 */       for (int z = minZ; z <= maxZ; z++) {
/* 229 */         class_2338 bottomBlock = new class_2338(x, minY - 1, z);
/* 230 */         class_2338 topBlock = new class_2338(x, maxY + 1, z);
/* 231 */         if (bottomBlock.method_10264() >= 64 && bottomBlock.method_10264() <= 320) {
/* 232 */           trapBlocks.add(bottomBlock);
/*     */         }
/* 234 */         if (topBlock.method_10264() >= 64 && topBlock.method_10264() <= 320) {
/* 235 */           trapBlocks.add(topBlock);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 240 */     class_2338 bestBlock = null;
/* 241 */     double highestDamage = Double.MIN_VALUE;
/* 242 */     double closestDistance = Double.MAX_VALUE;
/* 243 */     for (class_2338 blockPos : trapBlocks) {
/* 244 */       if (blockPos.method_10264() < -64 || blockPos.method_10264() > 320)
/* 245 */         continue;  class_2248 block = MeteorClient.mc.field_1687.method_8320(blockPos).method_26204();
/* 246 */       if (block != class_2246.field_9987 && 
/* 247 */         !MeteorClient.mc.field_1687.method_8320(blockPos).method_51367()) {
/* 248 */         class_243 blockPosCenter = blockPos.method_46558();
/* 249 */         if (entity instanceof class_1657) {
/* 250 */           double damage = bedDamage(predictedpos, (class_1657)entity, blockPosCenter);
/* 251 */           if (damage > highestDamage) {
/* 252 */             highestDamage = damage;
/* 253 */             bestBlock = blockPos;
/*     */           }  continue;
/*     */         } 
/* 256 */         double distance = distanceToClosestPointOnHitbox(box, blockPosCenter);
/* 257 */         if (distance < closestDistance) {
/* 258 */           closestDistance = distance;
/* 259 */           bestBlock = blockPos;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 265 */     return bestBlock;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void blow(class_2338 pos, class_243 tpAftwerards) {
/* 270 */     if (pos == null) {
/* 271 */       ChatUtils.error("Failed to find a position to place the anchor.", new Object[0]);
/*     */       return;
/*     */     } 
/* 274 */     List<class_243> list = new ArrayList<>();
/* 275 */     class_243 teleportpos = getLeastDamageTeleport(pos);
/* 276 */     if (teleportpos == null) {
/* 277 */       ChatUtils.error("Failed to find a valid teleport position.", new Object[0]);
/*     */       return;
/*     */     } 
/* 280 */     list.add(teleportpos);
/* 281 */     list.add(tpAftwerards);
/* 282 */     MulitPath path = new MulitPath(list);
/* 283 */     if (!path.canExecute().booleanValue()) {
/* 284 */       Disabler disabler = (Disabler)Modules.get().get(Disabler.class);
/* 285 */       if (!disabler.isActive()) {
/* 286 */         ChatUtils.error("Not enough charge. Enable Disabler to build up more.", new Object[0]);
/*     */         return;
/*     */       } 
/* 289 */       ChatUtils.error("Not enough charge.", new Object[0]);
/*     */       
/*     */       return;
/*     */     } 
/* 293 */     path.sendPackets(true);
/* 294 */     path.execute(0);
/* 295 */     int OriginalSlot = (MeteorClient.mc.field_1724.method_31548()).field_7545;
/* 296 */     switchToHotbar(class_1802.field_23141);
/* 297 */     PacketUtils.packetQueue.add(new class_2885(class_1268.field_5808, new class_3965(pos.method_46558(), class_2350.field_11034, pos, false), 0));
/* 298 */     switchToHotbar(class_1802.field_8801);
/* 299 */     PacketUtils.packetQueue.add(new class_2885(class_1268.field_5808, new class_3965(pos.method_46558(), class_2350.field_11034, pos, false), 0));
/* 300 */     PacketUtils.packetQueue.add(new class_2868(OriginalSlot));
/* 301 */     PacketUtils.packetQueue.add(new class_2885(class_1268.field_5808, new class_3965(pos.method_46558(), class_2350.field_11034, pos, false), 0));
/* 302 */     path.execute(1);
/* 303 */     PacketUtils.sendAllPacketsInQueue();
/*     */   }
/*     */   
/*     */   private static double distanceToClosestPointOnHitbox(class_238 box, class_243 point) {
/* 307 */     double x = Math.max(box.field_1323, Math.min(box.field_1320, point.field_1352));
/* 308 */     double y = Math.max(box.field_1322, Math.min(box.field_1325, point.field_1351));
/* 309 */     double z = Math.max(box.field_1321, Math.min(box.field_1324, point.field_1350));
/* 310 */     return (new class_243(x, y, z)).method_1022(point);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\AnchorUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */