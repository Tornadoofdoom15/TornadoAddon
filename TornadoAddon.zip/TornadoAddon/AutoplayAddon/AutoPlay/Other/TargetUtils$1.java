/*    */ package AutoplayAddon.AutoPlay.Other;


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\TargetUtils$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */