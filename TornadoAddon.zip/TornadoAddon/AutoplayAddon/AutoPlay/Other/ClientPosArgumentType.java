/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import com.mojang.brigadier.StringReader;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.brigadier.suggestion.Suggestions;
/*    */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*    */ import java.util.Collection;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_2170;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2277;
/*    */ import net.minecraft.class_2278;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientPosArgumentType
/*    */   implements ArgumentType<class_243>
/*    */ {
/*    */   public static ClientPosArgumentType pos() {
/* 25 */     return new ClientPosArgumentType();
/*    */   }
/*    */   
/*    */   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
/* 29 */     if (!(context.getSource() instanceof class_2172)) {
/* 30 */       return Suggestions.empty();
/*    */     }
/* 32 */     String string = builder.getRemaining();
/* 33 */     Object collection2 = ((class_2172)context.getSource()).method_17771();
/*    */     
/* 35 */     return class_2172.method_9260(string, (Collection)collection2, builder, class_2170.method_9238(this::parse));
/*    */   }
/*    */ 
/*    */   
/*    */   public static class_243 getPos(CommandContext<?> context, String name) {
/* 40 */     return (class_243)context.getArgument(name, class_243.class);
/*    */   }
/*    */   
/*    */   public class_243 parse(StringReader reader) throws CommandSyntaxException {
/*    */     class_2278 coordinateArgument2, coordinateArgument3;
/* 45 */     int i = reader.getCursor();
/*    */     
/* 47 */     class_2278 coordinateArgument = class_2278.method_9739(reader);
/*    */ 
/*    */     
/* 50 */     if (reader.canRead() && reader.peek() == ' ') {
/* 51 */       reader.skip();
/* 52 */       coordinateArgument2 = class_2278.method_9739(reader);
/* 53 */       if (reader.canRead() && reader.peek() == ' ') {
/* 54 */         reader.skip();
/* 55 */         coordinateArgument3 = class_2278.method_9739(reader);
/*    */       } else {
/* 57 */         reader.setCursor(i);
/* 58 */         throw class_2277.field_10755.createWithContext(reader);
/*    */       } 
/*    */     } else {
/* 61 */       reader.setCursor(i);
/* 62 */       throw class_2277.field_10755.createWithContext(reader);
/*    */     } 
/*    */     
/* 65 */     double x = coordinateArgument.method_9740(MeteorClient.mc.field_1724.method_23317());
/* 66 */     double y = coordinateArgument2.method_9740(MeteorClient.mc.field_1724.method_23318());
/* 67 */     double z = coordinateArgument3.method_9740(MeteorClient.mc.field_1724.method_23321());
/*    */     
/* 69 */     return new class_243(x, y, z);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\ClientPosArgumentType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */