/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.Paths.MulitPath;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BotUtils
/*    */ {
/*    */   public static void setPos(class_243 pos) {
/* 27 */     List<class_243> list = new ArrayList<>();
/* 28 */     list.add(pos);
/* 29 */     MulitPath path = new MulitPath(list);
/* 30 */     if (!path.canExecute().booleanValue())
/* 31 */       return;  path.sendPackets(false);
/* 32 */     path.execute(0);
/* 33 */     MeteorClient.mc.field_1724.method_33574(pos);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\BotUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */