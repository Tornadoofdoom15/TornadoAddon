/*    */ package AutoplayAddon.AutoPlay.Other;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Mode
/*    */ {
/* 18 */   PlayerName,
/* 19 */   ClosestPlayer,
/* 20 */   ClosestToCrosshair;
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Other\TargetUtils$Mode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */