/*    */ package AutoplayAddon.AutoPlay.Movement.Paths;
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class TeleportTask extends Movement {
/*    */   private final class_243 destination;
/*    */   
/*    */   public TeleportTask(class_243 destination, class_243 currentPos, int currentPackets) {
/* 12 */     this.currentPackets = currentPackets;
/* 13 */     this.currentPos = currentPos;
/* 14 */     this.destination = destination;
/*    */   } private final class_243 currentPos; private final int currentPackets;
/*    */   public int getPacketsRequired() {
/* 17 */     double base = maxDist(this.destination, Arrays.asList(new class_243[] { ServerSideValues.tickpos, this.currentPos }));
/* 18 */     return (int)Math.ceil(base / 10.0D) - 1 - this.currentPackets;
/*    */   } public void execute(boolean onGround, Float pitch, Float yaw) {
/* 20 */     PacketUtils.addMovePacketToQueue(onGround, this.destination, pitch, yaw);
/*    */   } public void execute() {
/* 22 */     PacketUtils.addMovePacketToQueue(true, this.destination, null, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Movement\Paths\TeleportTask.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */