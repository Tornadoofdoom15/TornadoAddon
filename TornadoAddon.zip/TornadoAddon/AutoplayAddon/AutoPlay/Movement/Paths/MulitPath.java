/*    */ package AutoplayAddon.AutoPlay.Movement.Paths;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class MulitPath extends Movement {
/* 11 */   private final List<SingularPath> paths = new ArrayList<>();
/*    */   public MulitPath(List<class_243> positions) {
/* 13 */     class_243 currentTempPos = ServerSideValues.serversidedposition;
/* 14 */     for (class_243 pos : positions) {
/* 15 */       this.paths.add(new SingularPath(pos, currentTempPos));
/* 16 */       currentTempPos = pos;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sendPackets(boolean force) {
/* 29 */     int packets = getTeleportPackets();
/* 30 */     if (force) {
/* 31 */       for (int i = 0; i < packets; i++) {
/* 32 */         PacketUtils.addMovePacketToQueue(true, null, null, null);
/*    */       }
/*    */     } else {
/* 35 */       while (packets > ServerSideValues.i2)
/* 36 */         PacketUtils.addMovePacketToQueue(true, null, null, null); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void execute(int Stage, boolean onGround, Float pitch, Float yaw) {
/* 41 */     ((SingularPath)this.paths.get(Stage)).execute(onGround, pitch, yaw);
/*    */   }
/*    */   public void execute(int Stage) {
/* 44 */     ((SingularPath)this.paths.get(Stage)).execute();
/*    */   }
/*    */   
/*    */   private List<TeleportTask> getTeleports() {
/* 48 */     List<TeleportTask> teleports = new ArrayList<>();
/* 49 */     for (SingularPath path : this.paths) {
/* 50 */       teleports.addAll(path.teleports);
/*    */     }
/* 52 */     return teleports;
/*    */   }
/*    */   private int getTeleportPackets() {
/* 55 */     int packetsRequired = 0;
/* 56 */     for (TeleportTask task : getTeleports()) {
/* 57 */       int packets = task.getPacketsRequired();
/* 58 */       if (packets > packetsRequired) packetsRequired = packets; 
/*    */     } 
/* 60 */     return packetsRequired;
/*    */   }
/*    */   
/*    */   public Boolean canExecute() {
/* 64 */     int packetsRequired = getTeleportPackets();
/* 65 */     int tempAllowed = ServerSideValues.predictallowedPlayerTicks();
/* 66 */     int tempI = ServerSideValues.i2;
/* 67 */     int sentTemp = 0;
/* 68 */     int tempPackets = getTeleports().size() + packetsRequired;
/*    */ 
/*    */     
/* 71 */     while (tempI < packetsRequired) {
/* 72 */       tempI++;
/* 73 */       sentTemp++;
/* 74 */       if (tempI > Math.max(tempAllowed, 5)) {
/* 75 */         return Boolean.valueOf(false);
/*    */       }
/* 77 */       if (tempAllowed > 20 || ServerSideValues.hasMoved) {
/* 78 */         tempAllowed--; continue;
/*    */       } 
/* 80 */       tempAllowed = 20;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 85 */     while (tempI < tempPackets) {
/* 86 */       tempI++;
/* 87 */       sentTemp++;
/* 88 */       if (tempI > Math.max(tempAllowed, 5)) {
/* 89 */         return Boolean.valueOf(false);
/*    */       }
/*    */       
/* 92 */       tempAllowed--;
/*    */     } 
/*    */     
/* 95 */     if (!ServerSideValues.canSendPackets(sentTemp, System.nanoTime()).booleanValue()) return Boolean.valueOf(false); 
/* 96 */     return Boolean.valueOf(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Movement\Paths\MulitPath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */