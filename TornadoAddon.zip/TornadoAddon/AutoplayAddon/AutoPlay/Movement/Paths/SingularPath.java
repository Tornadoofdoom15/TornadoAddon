/*    */ package AutoplayAddon.AutoPlay.Movement.Paths;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.CanTeleport;
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class SingularPath
/*    */   extends Movement {
/* 12 */   public final List<TeleportTask> teleports = new ArrayList<>();
/*    */   
/*    */   public SingularPath(class_243 destination, class_243 currentPos) {
/* 15 */     int stage = 0;
/* 16 */     double y = -13377.0D;
/* 17 */     class_243 currentTempPos = currentPos;
/*    */     while (true) {
/* 19 */       if (stage == 4) {
/* 20 */         ChatUtils.error("stage is 4", new Object[0]);
/*    */         break;
/*    */       } 
/* 23 */       if (CanTeleport.lazyCheck(currentTempPos, destination).booleanValue()) {
/* 24 */         this.teleports.add(new TeleportTask(destination, currentTempPos, this.teleports.size())); break;
/*    */       } 
/* 26 */       if (y == -13377.0D) {
/*    */         
/* 28 */         y = CanTeleport.searchY(currentPos, destination);
/* 29 */         if (y == -1337.0D) {
/* 30 */           y = currentPos.field_1351;
/* 31 */           stage = 2;
/*    */         } else {
/* 33 */           stage = 1;
/*    */         } 
/*    */       } 
/* 36 */       class_243 newPos = getStage(currentTempPos, destination, stage, y);
/* 37 */       this.teleports.add(new TeleportTask(newPos, currentTempPos, this.teleports.size()));
/* 38 */       currentTempPos = newPos;
/* 39 */       stage++;
/*    */     } 
/*    */   }
/*    */   
/*    */   private static class_243 getStage(class_243 from, class_243 to, int stage, double y) {
/* 44 */     if (stage == 1) return new class_243(from.method_10216(), y, from.method_10215()); 
/* 45 */     if (stage == 2) return new class_243(to.method_10216(), y, to.method_10215()); 
/* 46 */     if (stage == 3) return new class_243(to.method_10216(), to.method_10214(), to.method_10215()); 
/* 47 */     return new class_243(from.method_10216(), from.method_10214(), from.method_10215());
/*    */   }
/*    */   public void execute(boolean onGround, Float pitch, Float yaw) {
/* 50 */     int size = this.teleports.size();
/* 51 */     for (int i = 0; i < size; i++) {
/* 52 */       TeleportTask task = this.teleports.get(i);
/* 53 */       if (i == size - 1) {
/* 54 */         task.execute(onGround, pitch, yaw);
/*    */       } else {
/* 56 */         task.execute();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   public void execute() {
/* 61 */     for (TeleportTask task : this.teleports) task.execute(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Movement\Paths\SingularPath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */