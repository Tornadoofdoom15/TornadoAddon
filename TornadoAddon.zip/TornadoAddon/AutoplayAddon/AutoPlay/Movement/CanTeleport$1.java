/*    */ package AutoplayAddon.AutoPlay.Movement;
/*    */ 
/*    */ import net.minecraft.class_2350;
/*    */ 


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Movement\CanTeleport$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */