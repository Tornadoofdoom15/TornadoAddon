/*     */ package AutoplayAddon.AutoPlay.Movement;
/*     */ import AutoplayAddon.AutoPlay.Other.FastBox;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_265;
/*     */ 
/*     */ public class CanTeleport {
/*     */   public static int searchY(class_243 from, class_243 to) {
/*  12 */     double fromy = from.field_1351;
/*  13 */     if (tryY(from, to, fromy))
/*     */     {
/*  15 */       return -1337;
/*     */     }
/*  17 */     int ytotest = 0;
/*  18 */     boolean validTeleportFound = false;
/*  19 */     int searchOffset = 0;
/*  20 */     while (!validTeleportFound) {
/*  21 */       ytotest = (int)(fromy + searchOffset);
/*  22 */       if (tryY(from, to, ytotest)) {
/*  23 */         validTeleportFound = true; continue;
/*     */       } 
/*  25 */       searchOffset = (searchOffset <= 0) ? (1 - searchOffset) : -searchOffset;
/*     */     } 
/*     */     
/*  28 */     return ytotest;
/*     */   }
/*     */   
/*     */   public static boolean tryY(class_243 from, class_243 to, double ytotest) {
/*  32 */     class_243 fromWithOffset = new class_243(from.field_1352, ytotest, from.field_1350);
/*  33 */     class_243 toWithOffset = new class_243(to.field_1352, ytotest, to.field_1350);
/*  34 */     FastBox fromBox = new FastBox(fromWithOffset);
/*  35 */     if (fromBox.isCollidingWithBlocks()) return false; 
/*  36 */     return lazyCheck(fromWithOffset, toWithOffset).booleanValue();
/*     */   }
/*     */   
/*     */   public static Boolean lazyCheck(class_243 from, class_243 to) {
/*  40 */     FastBox fastBox = new FastBox(from);
/*  41 */     class_243 movement = new class_243(to.field_1352 - from.field_1352, to.field_1351 - from.field_1351, to.field_1350 - from.field_1350);
/*  42 */     double d = movement.field_1352;
/*  43 */     double e = movement.field_1351;
/*  44 */     double f = movement.field_1350;
/*  45 */     if (e != 0.0D) {
/*  46 */       e = OffsetCalcDouble(fastBox, class_2350.class_2351.field_11052, e);
/*  47 */       if (e != 0.0D) {
/*  48 */         fastBox.offset(new class_243(0.0D, e, 0.0D));
/*     */       }
/*     */     } 
/*  51 */     boolean bl = (Math.abs(d) < Math.abs(f));
/*  52 */     if (bl && f != 0.0D) {
/*  53 */       if (OffsetCalcBool(fastBox, class_2350.class_2351.field_11051, f).booleanValue()) return Boolean.valueOf(false); 
/*  54 */       fastBox.offset(new class_243(0.0D, 0.0D, f));
/*     */     } 
/*  56 */     if (d != 0.0D) {
/*  57 */       if (OffsetCalcBool(fastBox, class_2350.class_2351.field_11048, d).booleanValue()) return Boolean.valueOf(false); 
/*  58 */       if (!bl) {
/*  59 */         fastBox.offset(new class_243(d, 0.0D, 0.0D));
/*     */       }
/*     */     } 
/*  62 */     if (!bl && f != 0.0D && 
/*  63 */       OffsetCalcBool(fastBox, class_2350.class_2351.field_11051, f).booleanValue()) return Boolean.valueOf(false);
/*     */     
/*  65 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double OffsetCalcDouble(FastBox fastBox, class_2350.class_2351 axis, double maxDist) {
/*  70 */     double step = 0.3D;
/*  71 */     double currentOffset = 0.0D;
/*  72 */     double lastOffset = 0.0D;
/*  73 */     class_243 direction = class_243.field_1353;
/*     */     
/*  75 */     switch (axis) {
/*     */       case field_11048:
/*  77 */         direction = new class_243(1.0D, 0.0D, 0.0D);
/*     */         break;
/*     */       case field_11052:
/*  80 */         direction = new class_243(0.0D, 1.0D, 0.0D);
/*     */         break;
/*     */       case field_11051:
/*  83 */         direction = new class_243(0.0D, 0.0D, 1.0D);
/*     */         break;
/*     */     } 
/*     */     
/*  87 */     direction = direction.method_1021(Math.signum(maxDist));
/*  88 */     FastBox bottom4Box = new FastBox(fastBox);
/*     */     
/*     */     while (true) {
/*  91 */       double offsetThisStep = step;
/*     */ 
/*     */       
/*  94 */       if (currentOffset + offsetThisStep > Math.abs(maxDist)) {
/*  95 */         offsetThisStep = Math.abs(maxDist) - currentOffset;
/*     */       }
/*     */       
/*  98 */       bottom4Box.offset(direction.method_1021(offsetThisStep));
/*  99 */       currentOffset += offsetThisStep;
/*     */ 
/*     */ 
/*     */       
/* 103 */       if (bottom4Box.isCollidingWithBlocks()) {
/* 104 */         return lastOffset * Math.signum(maxDist);
/*     */       }
/* 106 */       lastOffset = currentOffset;
/*     */       
/* 108 */       if (Math.abs(currentOffset) >= Math.abs(maxDist)) return maxDist;
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Boolean OffsetCalcBool(FastBox fastBox, class_2350.class_2351 axis, double maxDist) {
/* 114 */     double step = 1.5D;
/* 115 */     double currentOffset = 0.0D;
/* 116 */     class_243 direction = class_243.field_1353;
/* 117 */     switch (axis) {
/*     */       case field_11048:
/* 119 */         direction = new class_243(1.0D, 0.0D, 0.0D);
/*     */         break;
/*     */       case field_11052:
/* 122 */         direction = new class_243(0.0D, 1.0D, 0.0D);
/*     */         break;
/*     */       case field_11051:
/* 125 */         direction = new class_243(0.0D, 0.0D, 1.0D);
/*     */         break;
/*     */     } 
/* 128 */     direction = direction.method_1021(Math.signum(maxDist));
/* 129 */     FastBox fullBox = new FastBox(fastBox);
/* 130 */     if (fullBox.isCollidingWithBlocks()) return Boolean.valueOf(true); 
/*     */     while (true) {
/* 132 */       double offsetThisStep = step;
/*     */       
/* 134 */       if (currentOffset + offsetThisStep > Math.abs(maxDist)) {
/* 135 */         offsetThisStep = Math.abs(maxDist) - currentOffset;
/*     */       }
/* 137 */       fullBox.offset(direction.method_1021(offsetThisStep));
/* 138 */       currentOffset += offsetThisStep;
/* 139 */       if (fullBox.isCollidingWithBlocks()) return Boolean.valueOf(true); 
/* 140 */       if (Math.abs(currentOffset) >= Math.abs(maxDist)) return Boolean.valueOf(false);
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class_243 adjustMovementForCollisionsold(class_238 box, class_243 movement) {
/* 146 */     if (movement.method_1027() == 0.0D) return movement; 
/* 147 */     List<class_265> entityCollisions = MeteorClient.mc.field_1724.method_37908().method_20743((class_1297)MeteorClient.mc.field_1724, box.method_18804(movement));
/* 148 */     ImmutableList.Builder<class_265> builder = ImmutableList.builderWithExpectedSize(entityCollisions.size() + 1);
/* 149 */     if (!entityCollisions.isEmpty()) {
/* 150 */       builder.addAll(entityCollisions);
/*     */     }
/* 152 */     builder.addAll(MeteorClient.mc.field_1724.method_37908().method_20812((class_1297)MeteorClient.mc.field_1724, box.method_18804(movement)));
/* 153 */     ImmutableList immutableList = builder.build();
/* 154 */     if (immutableList.isEmpty()) return movement; 
/* 155 */     double d = movement.field_1352;
/* 156 */     double e = movement.field_1351;
/* 157 */     double f = movement.field_1350;
/* 158 */     if (e != 0.0D) {
/* 159 */       e = class_259.method_1085(class_2350.class_2351.field_11052, box, (Iterable)immutableList, e);
/* 160 */       if (e != 0.0D) {
/* 161 */         box = box.method_989(0.0D, e, 0.0D);
/*     */       }
/*     */     } 
/*     */     
/* 165 */     boolean bl = (Math.abs(d) < Math.abs(f));
/* 166 */     if (bl && f != 0.0D) {
/* 167 */       f = class_259.method_1085(class_2350.class_2351.field_11051, box, (Iterable)immutableList, f);
/* 168 */       if (f != 0.0D) {
/* 169 */         box = box.method_989(0.0D, 0.0D, f);
/*     */       }
/*     */     } 
/*     */     
/* 173 */     if (d != 0.0D) {
/* 174 */       d = class_259.method_1085(class_2350.class_2351.field_11048, box, (Iterable)immutableList, d);
/* 175 */       if (!bl && d != 0.0D) {
/* 176 */         box = box.method_989(d, 0.0D, 0.0D);
/*     */       }
/*     */     } 
/*     */     
/* 180 */     if (!bl && f != 0.0D) {
/* 181 */       f = class_259.method_1085(class_2350.class_2351.field_11051, box, (Iterable)immutableList, f);
/*     */     }
/* 183 */     return new class_243(d, e, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean oldCheck(class_243 from, class_243 to) {
/* 189 */     if (to == null) {
/* 190 */       return false;
/*     */     }
/* 192 */     class_238 oldBox = new class_238(from.field_1352 - (MeteorClient.mc.field_1724.method_17681() / 2.0F), from.field_1351, from.field_1350 - (MeteorClient.mc.field_1724.method_17681() / 2.0F), from.field_1352 + (MeteorClient.mc.field_1724.method_17681() / 2.0F), from.field_1351 + MeteorClient.mc.field_1724.method_17682(), from.field_1350 + (MeteorClient.mc.field_1724.method_17681() / 2.0F));
/* 193 */     class_238 newBox = new class_238(to.field_1352 - (MeteorClient.mc.field_1724.method_17681() / 2.0F), to.field_1351, to.field_1350 - (MeteorClient.mc.field_1724.method_17681() / 2.0F), to.field_1352 + (MeteorClient.mc.field_1724.method_17681() / 2.0F), to.field_1351 + MeteorClient.mc.field_1724.method_17682(), to.field_1350 + (MeteorClient.mc.field_1724.method_17681() / 2.0F));
/* 194 */     if (!MeteorClient.mc.field_1687.method_18026(newBox)) {
/* 195 */       return false;
/*     */     }
/*     */     
/* 198 */     double d6 = to.field_1352 - from.field_1352;
/* 199 */     double d7 = to.field_1351 - from.field_1351;
/* 200 */     double d8 = to.field_1350 - from.field_1350;
/* 201 */     class_243 test = adjustMovementForCollisionsold(oldBox, new class_243(d6, d7, d8));
/* 202 */     class_243 wentto = new class_243(from.field_1352 + test.field_1352, from.field_1351 + test.field_1351, from.field_1350 + test.field_1350);
/* 203 */     d6 = to.field_1352 - wentto.field_1352;
/* 204 */     d7 = to.field_1351 - wentto.field_1351;
/*     */     
/* 206 */     if (d7 > -0.5D || d7 < 0.5D) {
/* 207 */       d7 = 0.0D;
/*     */     }
/*     */     
/* 210 */     d8 = to.field_1350 - wentto.field_1350;
/* 211 */     double d10 = d6 * d6 + d7 * d7 + d8 * d8;
/*     */     
/* 213 */     if (d10 > 0.0625D) {
/* 214 */       return false;
/*     */     }
/*     */     
/* 217 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Movement\CanTeleport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */