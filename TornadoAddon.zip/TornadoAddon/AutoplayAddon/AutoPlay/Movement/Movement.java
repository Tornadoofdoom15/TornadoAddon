/*    */ package AutoplayAddon.AutoPlay.Movement;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.Paths.MulitPath;
/*    */ import AutoplayAddon.AutoPlay.Other.FastBox;
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import AutoplayAddon.modules.Disabler;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.systems.modules.Modules;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Movement
/*    */ {
/* 21 */   public static final ArrayList<FastBox> fastBoxList = new ArrayList<>();
/* 22 */   public static final ArrayList<FastBox> fastBoxBadList = new ArrayList<>();
/*    */   
/*    */   public static double maxDist(class_243 newPos, List<class_243> positions) {
/* 25 */     double maxDistance = Double.MIN_VALUE;
/* 26 */     for (class_243 vec3d : positions) {
/* 27 */       double distance = calculateDistance(newPos, vec3d);
/* 28 */       if (distance > maxDistance) {
/* 29 */         maxDistance = distance;
/*    */       }
/*    */     } 
/* 32 */     return maxDistance;
/*    */   }
/*    */   
/*    */   private static double calculateDistance(class_243 pos1, class_243 pos2) {
/* 36 */     double dx = pos2.field_1352 - pos1.field_1352;
/* 37 */     double dy = pos2.field_1351 - pos1.field_1351;
/* 38 */     double dz = pos2.field_1350 - pos1.field_1350;
/* 39 */     return Math.sqrt(dx * dx + dy * dy + dz * dz);
/*    */   }
/*    */   
/*    */   public static boolean closeBy(class_243 from, class_243 to) {
/* 43 */     double dx = from.field_1352 - to.field_1352;
/* 44 */     double dy = from.field_1351 - to.field_1351;
/* 45 */     double dz = from.field_1350 - to.field_1350;
/* 46 */     double squaredDistance = dx * dx + dy * dy + dz * dz;
/* 47 */     return (squaredDistance < 0.005D);
/*    */   }
/*    */   
/*    */   public static void setPos(class_243 pos, boolean setClientSided, Float pitch, Float yaw) {
/* 51 */     class_243 serverpos = ServerSideValues.serversidedposition;
/* 52 */     if ((((serverpos.field_1352 == pos.field_1352) ? 1 : 0) & ((serverpos.field_1351 == pos.field_1351) ? 1 : 0)) != 0 && serverpos.field_1350 == pos.field_1350)
/* 53 */       return;  List<class_243> list = new ArrayList<>();
/* 54 */     list.add(pos);
/* 55 */     MulitPath path = new MulitPath(list);
/* 56 */     if (!path.canExecute().booleanValue()) {
/* 57 */       Disabler disabler = (Disabler)Modules.get().get(Disabler.class);
/* 58 */       if (!disabler.isActive()) {
/* 59 */         ChatUtils.error("Not enough charge. Enable Disabler to build up more.", new Object[0]);
/*    */         return;
/*    */       } 
/* 62 */       ChatUtils.error("Not enough charge.", new Object[0]);
/*    */       
/*    */       return;
/*    */     } 
/* 66 */     PacketUtils.packetQueue.clear();
/* 67 */     path.sendPackets(false);
/* 68 */     if (pitch == null && yaw == null) { path.execute(0); }
/* 69 */     else { path.execute(0, true, pitch, yaw); }
/* 70 */      PacketUtils.sendAllPacketsInQueue();
/* 71 */     if (setClientSided) MeteorClient.mc.field_1724.method_33574(pos); 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Movement\Movement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */