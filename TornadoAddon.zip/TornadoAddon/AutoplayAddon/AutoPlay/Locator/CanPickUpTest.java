/*    */ package AutoplayAddon.AutoPlay.Locator;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.BlockCache;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_2246;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class CanPickUpTest
/*    */ {
/* 16 */   static final BlockCache blockCache = AutoplayAddon.blockCache;
/*    */   
/*    */   public static List<class_243> findCollectableItem(List<class_1792> targetItems) {
/* 19 */     List<class_2248> targetBlocks = new ArrayList<>();
/*    */     
/* 21 */     for (class_1792 item : targetItems) {
/* 22 */       if (class_2248.method_9503(item) != class_2246.field_10124) {
/* 23 */         targetBlocks.add(class_2248.method_9503(item));
/*    */       }
/*    */     } 
/*    */     
/* 27 */     if (targetBlocks.isEmpty()) {
/* 28 */       return null;
/*    */     }
/*    */     
/* 31 */     return findCollectableBlock(targetBlocks);
/*    */   }
/*    */ 
/*    */   
/*    */   public static List<class_243> findCollectableBlock(List<class_2248> targetBlocks) {
/* 36 */     class_2338 playerPos = MeteorClient.mc.field_1724.method_24515();
/* 37 */     int maxDistance = 100;
/* 38 */     for (int distance = 1; distance <= maxDistance; distance++) {
/* 39 */       for (int dx = -distance; dx <= distance; dx++) {
/* 40 */         for (int dy = -distance; dy <= distance; dy++) {
/* 41 */           for (int dz = -distance; dz <= distance; dz++) {
/* 42 */             if (Math.abs(dx) == distance || Math.abs(dy) == distance || Math.abs(dz) == distance) {
/*    */ 
/*    */               
/* 45 */               class_2338 checkPos = playerPos.method_10069(dx, dy, dz);
/* 46 */               class_2248 checkBlock = MeteorClient.mc.field_1687.method_8320(checkPos).method_26204();
/* 47 */               if (targetBlocks.contains(checkBlock) && (
/* 48 */                 !blockCache.isBlockAt(checkPos.method_10069(0, 1, 0)) || !blockCache.isBlockAt(checkPos.method_10069(0, -1, 0)) || hasAirAdjacent(checkPos))) {
/* 49 */                 class_243 airGapPos = AirGapFinder.findAirGapNearBlock(checkPos, 5.0D);
/* 50 */                 if (airGapPos != null) {
/* 51 */                   return List.of(new class_243(checkPos.method_10263(), checkPos.method_10264(), checkPos.method_10260()), airGapPos);
/*    */                 }
/*    */               } 
/*    */             } 
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean hasAirAdjacent(class_2338 pos) {
/* 65 */     for (class_2338 blockPos : ValidPickupPoint.getSurroundingBlocks(pos)) {
/* 66 */       if ((!blockCache.isBlockAt(blockPos.method_10069(0, 1, 0)) && !blockCache.isBlockAt(blockPos)) || (
/* 67 */         !blockCache.isBlockAt(blockPos.method_10069(0, -1, 0)) && !blockCache.isBlockAt(blockPos.method_10069(0, -2, 0)))) {
/* 68 */         return true;
/*    */       }
/*    */     } 
/* 71 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Locator\CanPickUpTest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */