/*     */ package AutoplayAddon.AutoPlay.Locator;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import meteordevelopment.meteorclient.utils.player.PlayerUtils;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1542;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_638;
/*     */ 
/*     */ public class GetLocUtil {
/*     */   public static Optional<UUID> findEntitys(List<class_1299<?>> entityTypes, class_1309 searchingEntity, double searchRadius) {
/*  22 */     class_638 clientWorld = (class_310.method_1551()).field_1687;
/*  23 */     class_243 searchingEntityPos = searchingEntity.method_19538();
/*  24 */     class_2338 searchingEntityBlockPos = searchingEntity.method_24515();
/*  25 */     class_238 searchBox = createSearchBox(searchingEntityBlockPos, searchRadius);
/*     */     
/*  27 */     List<class_1297> entities = clientWorld.method_8333((class_1297)searchingEntity, searchBox, entity -> entityTypes.contains(entity.method_5864()));
/*     */     
/*  29 */     return entities.stream()
/*  30 */       .min(Comparator.comparingDouble(e -> searchingEntityPos.method_1025(e.method_19538())))
/*  31 */       .map(class_1297::method_5667);
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<class_2338> findItemEntities(List<class_1792> targetItems, double searchRadius) {
/*  36 */     if (MeteorClient.mc.field_1724 == null || MeteorClient.mc.field_1687 == null) {
/*  37 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  40 */     class_2338 playerBlockPos = MeteorClient.mc.field_1724.method_24515();
/*  41 */     class_238 searchBox = createSearchBox(playerBlockPos, searchRadius);
/*     */     
/*  43 */     return (List<class_2338>)MeteorClient.mc.field_1687.method_8390(class_1542.class, searchBox, itemEntity -> isInTargetItems(itemEntity, targetItems))
/*  44 */       .stream()
/*  45 */       .map(class_1297::method_24515)
/*  46 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isInTargetItems(class_1542 itemEntity, List<class_1792> targetItems) {
/*  51 */     return targetItems.stream().anyMatch(targetItem -> targetItem.equals(itemEntity.method_6983().method_7909()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_2338 findBlocks(List<class_2248> targetBlocks, int searchRadius) {
/*  58 */     class_1937 world = MeteorClient.mc.field_1724.method_5770();
/*  59 */     class_2338 playerPos = MeteorClient.mc.field_1724.method_24515();
/*     */     
/*  61 */     for (int i = -searchRadius; i <= searchRadius; i++) {
/*  62 */       class_2338 currentPos = playerPos.method_10069(0, i, 0);
/*  63 */       class_2248 currentBlock = world.method_8320(currentPos).method_26204();
/*  64 */       if (targetBlocks.contains(currentBlock) && !isPositionOccupied(world, currentPos) && PlayerUtils.distanceTo(currentPos) < searchRadius) {
/*  65 */         return currentPos;
/*     */       }
/*     */     } 
/*     */     
/*  69 */     for (int r = 0; r <= searchRadius + 4; r++) {
/*  70 */       for (int dx = -r; dx <= r; dx++) {
/*  71 */         for (int dz = -r; dz <= r; dz++) {
/*  72 */           if (Math.abs(dx) == r || Math.abs(dz) == r) {
/*  73 */             for (int j = -r + 1; j < r; j++) {
/*  74 */               class_2338 currentPos = playerPos.method_10069(dx, j, dz);
/*  75 */               class_2248 currentBlock = world.method_8320(currentPos).method_26204();
/*  76 */               if (targetBlocks.contains(currentBlock) && !isPositionOccupied(world, currentPos) && PlayerUtils.distanceTo(currentPos) < searchRadius) {
/*  77 */                 return currentPos;
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*  84 */     for (int dy = -searchRadius; dy <= searchRadius; dy++) {
/*  85 */       class_2338 currentPos = playerPos.method_10069(0, dy, 0);
/*  86 */       class_2248 currentBlock = world.method_8320(currentPos).method_26204();
/*  87 */       if (targetBlocks.contains(currentBlock) && !isPositionOccupied(world, currentPos) && PlayerUtils.distanceTo(currentPos) < searchRadius) {
/*  88 */         return currentPos;
/*     */       }
/*     */     } 
/*     */     
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPositionOccupied(class_1937 world, class_2338 pos) {
/* 102 */     List<class_1297> entities = world.method_8390(class_1297.class, new class_238(pos), entity -> !(entity instanceof net.minecraft.class_1657));
/* 103 */     if (!entities.isEmpty()) {
/* 104 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 108 */     class_238 playerBoundingBox = MeteorClient.mc.field_1724.method_5829();
/*     */ 
/*     */     
/* 111 */     return playerBoundingBox.method_994(new class_238(pos.method_46558(), pos.method_10069(1, 1, 1).method_46558()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class_238 createSearchBox(class_2338 pos, double searchRadius) {
/* 119 */     return new class_238(pos
/* 120 */         .method_10263() - searchRadius, pos.method_10264() - searchRadius, pos.method_10260() - searchRadius, pos
/* 121 */         .method_10263() + searchRadius, pos.method_10264() + searchRadius, pos.method_10260() + searchRadius);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Locator\GetLocUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */