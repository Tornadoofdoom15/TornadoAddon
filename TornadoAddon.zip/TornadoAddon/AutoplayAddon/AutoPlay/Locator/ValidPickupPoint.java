/*    */ package AutoplayAddon.AutoPlay.Locator;
/*    */ 
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class ValidPickupPoint
/*    */ {
/*    */   public static class_243 findFitSpot(class_1937 world, class_2338 originalPos) {
/* 10 */     class_243 fitSpot = checkFit(world, originalPos, originalPos, 0.5D);
/* 11 */     if (fitSpot != null) {
/* 12 */       return fitSpot;
/*    */     }
/*    */     
/* 15 */     class_2338[] surroundingPos = getSurroundingBlocks(originalPos);
/*    */     
/* 17 */     for (class_2338 pos : surroundingPos) {
/* 18 */       fitSpot = checkFit(world, pos, originalPos, 0.3D);
/* 19 */       if (fitSpot != null) {
/* 20 */         return fitSpot;
/*    */       }
/*    */     } 
/*    */     
/* 24 */     for (class_2338 pos : surroundingPos) {
/* 25 */       fitSpot = checkFit(world, pos.method_10074(), originalPos, 0.3D);
/* 26 */       if (fitSpot != null) {
/* 27 */         return fitSpot;
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 32 */     for (class_2338 pos : surroundingPos) {
/* 33 */       fitSpot = checkFit(world, pos.method_10087(2), originalPos, 0.3D);
/* 34 */       if (fitSpot != null) {
/* 35 */         return fitSpot;
/*    */       }
/*    */     } 
/*    */     
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public static class_2338[] getSurroundingBlocks(class_2338 originalPos) {
/* 43 */     int x = originalPos.method_10263();
/* 44 */     int y = originalPos.method_10264();
/* 45 */     int z = originalPos.method_10260();
/*    */     
/* 47 */     return new class_2338[] { new class_2338(x, y, z + 1), new class_2338(x, y, z - 1), new class_2338(x + 1, y, z), new class_2338(x - 1, y, z), new class_2338(x + 1, y, z + 1), new class_2338(x - 1, y, z + 1), new class_2338(x + 1, y, z - 1), new class_2338(x - 1, y, z - 1) };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static class_243 checkFit(class_1937 world, class_2338 pos, class_2338 originalPos, double offset) {
/* 61 */     if (isAir(world, pos) && isAir(world, pos.method_10084())) {
/* 62 */       double offsetX = (pos.method_10263() < originalPos.method_10263()) ? 0.7D : ((pos.method_10263() > originalPos.method_10263()) ? 0.3D : 0.5D);
/* 63 */       double offsetZ = (pos.method_10260() < originalPos.method_10260()) ? 0.7D : ((pos.method_10260() > originalPos.method_10260()) ? 0.3D : 0.5D);
/* 64 */       return new class_243(pos.method_10263() + offsetX, pos.method_10264(), pos.method_10260() + offsetZ);
/*    */     } 
/* 66 */     return null;
/*    */   }
/*    */   private static boolean isAir(class_1937 world, class_2338 pos) {
/* 69 */     return world.method_22347(pos);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Locator\ValidPickupPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */