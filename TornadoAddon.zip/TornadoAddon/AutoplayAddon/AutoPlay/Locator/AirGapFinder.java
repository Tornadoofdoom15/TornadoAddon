/*    */ package AutoplayAddon.AutoPlay.Locator;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.BlockCache;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1922;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2382;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class AirGapFinder {
/* 17 */   static BlockCache blockCache = AutoplayAddon.blockCache;
/*    */   public static List<class_243> findClosestValidStandingPos(List<class_2248> targetBlocks, double maxAirGapDistance) {
/* 19 */     class_2338 playerPos = MeteorClient.mc.field_1724.method_24515();
/* 20 */     BlockCache blockCache = AutoplayAddon.blockCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     List<class_2338> filteredPositions = (List<class_2338>)blockCache.blockMap.entrySet().stream().filter(entry -> targetBlocks.contains(entry.getValue())).map(entry -> (class_2338)entry.getKey()).collect(Collectors.toList());
/*    */ 
/*    */     
/* 29 */     filteredPositions.sort(Comparator.comparingInt(pos -> pos.method_19455((class_2382)playerPos)));
/*    */ 
/*    */     
/* 32 */     for (class_2338 currentPos : filteredPositions) {
/* 33 */       class_243 airGapPos = findAirGapNearBlock(currentPos, maxAirGapDistance);
/* 34 */       if (airGapPos != null) {
/* 35 */         ChatUtils.info("Found", new Object[0]);
/* 36 */         List<class_243> result = new ArrayList<>();
/* 37 */         result.add(new class_243(currentPos.method_10263(), currentPos.method_10264(), currentPos.method_10260()));
/* 38 */         result.add(airGapPos);
/* 39 */         return result;
/*    */       } 
/*    */     } 
/* 42 */     ChatUtils.info("Didn't find", new Object[0]);
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public static class_243 findAirGapNearBlock(class_2338 targetPos, double maxAirGapDistance) {
/* 47 */     class_2338 closestValidPos = null;
/* 48 */     double minSquaredDistance = maxAirGapDistance * maxAirGapDistance;
/*    */     
/* 50 */     for (class_2338 pos : class_2338.method_10097(targetPos.method_10069((int)-maxAirGapDistance, (int)-maxAirGapDistance, (int)-maxAirGapDistance), targetPos
/* 51 */         .method_10069((int)maxAirGapDistance, (int)maxAirGapDistance, (int)maxAirGapDistance))) {
/*    */       
/* 53 */       double squaredDistance = squaredDistanceBetweenBlockPos(targetPos, pos);
/*    */       
/* 55 */       if (squaredDistance > minSquaredDistance) {
/*    */         continue;
/*    */       }
/*    */       
/* 59 */       if (!MeteorClient.mc.field_1687.method_8320(pos).method_26212((class_1922)MeteorClient.mc.field_1687, pos) && !MeteorClient.mc.field_1687.method_8320(pos.method_10084()).method_26212((class_1922)MeteorClient.mc.field_1687, pos.method_10084()) && 
/* 60 */         squaredDistance < minSquaredDistance) {
/* 61 */         closestValidPos = pos.method_10062();
/* 62 */         minSquaredDistance = squaredDistance;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 67 */     if (closestValidPos == null) {
/* 68 */       return null;
/*    */     }
/*    */     
/* 71 */     double offsetX = (closestValidPos.method_10263() < targetPos.method_10263()) ? 0.7D : ((closestValidPos.method_10263() > targetPos.method_10263()) ? 0.3D : 0.5D);
/* 72 */     double offsetZ = (closestValidPos.method_10260() < targetPos.method_10260()) ? 0.7D : ((closestValidPos.method_10260() > targetPos.method_10260()) ? 0.3D : 0.5D);
/* 73 */     return new class_243(closestValidPos.method_10263() + offsetX, closestValidPos.method_10264(), closestValidPos.method_10260() + offsetZ);
/*    */   }
/*    */   
/*    */   private static double squaredDistanceBetweenBlockPos(class_2338 pos1, class_2338 pos2) {
/* 77 */     double dx = (pos1.method_10263() - pos2.method_10263());
/* 78 */     double dy = (pos1.method_10264() - pos2.method_10264());
/* 79 */     double dz = (pos1.method_10260() - pos2.method_10260());
/* 80 */     return dx * dx + dy * dy + dz * dz;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Locator\AirGapFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */