/*    */ package AutoplayAddon.AutoPlay.Locator;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_310;
/*    */ 
/*    */ public class EntityCoordinatesUtil {
/*    */   public static class_243 getEntityCoordinatesByUUID(Optional<UUID> entityUUID) {
/* 11 */     class_310 client = class_310.method_1551();
/*    */     
/* 13 */     if (client == null || client.field_1687 == null) {
/* 14 */       return null;
/*    */     }
/*    */     
/* 17 */     for (class_1297 entity : client.field_1687.method_18112()) {
/* 18 */       if (entity.method_5667().equals(entityUUID)) {
/* 19 */         return entity.method_19538();
/*    */       }
/*    */     } 
/*    */     
/* 23 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Locator\EntityCoordinatesUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */