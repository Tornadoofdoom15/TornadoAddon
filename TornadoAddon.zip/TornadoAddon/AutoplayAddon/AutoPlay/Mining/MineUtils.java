/*    */ package AutoplayAddon.AutoPlay.Mining;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_1292;
/*    */ import net.minecraft.class_1294;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1890;
/*    */ import net.minecraft.class_1922;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_3486;
/*    */ 
/*    */ public class MineUtils {
/*    */   public static float calcBlockBreakingDelta(class_2680 state, class_2338 pos) {
/* 15 */     float g = state.method_26214((class_1922)MeteorClient.mc.field_1687, pos);
/* 16 */     if (g == -1.0F) {
/* 17 */       return 0.0F;
/*    */     }
/* 19 */     int h = MeteorClient.mc.field_1724.method_7305(state) ? 30 : 100;
/*    */ 
/*    */     
/* 22 */     float f = MeteorClient.mc.field_1724.method_6047().method_7924(state);
/*    */     
/* 24 */     if (f > 1.0F) {
/* 25 */       int i = class_1890.method_8234((class_1309)MeteorClient.mc.field_1724);
/* 26 */       class_1799 itemStack = MeteorClient.mc.field_1724.method_6047();
/* 27 */       if (i > 0 && !itemStack.method_7960()) {
/* 28 */         f += (i * i + 1);
/*    */       }
/*    */     } 
/* 31 */     if (class_1292.method_5576((class_1309)MeteorClient.mc.field_1724)) {
/* 32 */       f *= 1.0F + (class_1292.method_5575((class_1309)MeteorClient.mc.field_1724) + 1) * 0.2F;
/*    */     }
/* 34 */     if (MeteorClient.mc.field_1724.method_6059(class_1294.field_5901)) {
/* 35 */       switch (MeteorClient.mc.field_1724.method_6112(class_1294.field_5901).method_5578()) { case 0: case 1: case 2: default: break; }  f *= 
/*    */ 
/*    */ 
/*    */         
/* 39 */         8.1E-4F;
/*    */     } 
/*    */     
/* 42 */     if (MeteorClient.mc.field_1724.method_5777(class_3486.field_15517) && !class_1890.method_8200((class_1309)MeteorClient.mc.field_1724)) {
/* 43 */       f /= 5.0F;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 50 */     return f / g / h;
/*    */   }
/*    */   
/*    */   public static boolean canInstaBreak(class_2680 blockState, class_2338 blockPos) {
/* 54 */     if (calcBlockBreakingDelta(blockState, blockPos) >= 0.7F) return true; 
/* 55 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Mining\MineUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */