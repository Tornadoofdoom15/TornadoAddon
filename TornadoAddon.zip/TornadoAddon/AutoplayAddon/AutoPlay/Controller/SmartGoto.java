/*    */ package AutoplayAddon.AutoPlay.Controller;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Locator.AirGapFinder;
/*    */ import AutoplayAddon.AutoPlay.Locator.GetLocUtil;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class SmartGoto {
/*    */   public static class_243 gotoblock(List<class_2248> targetBlocks) {
/* 13 */     ChatUtils.info("Searching for blocks " + targetBlocks.toString(), new Object[0]);
/* 14 */     class_2338 targetBlockPositions = GetLocUtil.findBlocks(targetBlocks, 5);
/* 15 */     if (targetBlockPositions == null) {
/* 16 */       ChatUtils.info("No target blocks found within 5 blocks.", new Object[0]);
/*    */     } else {
/* 18 */       return targetBlockPositions.method_46558();
/*    */     } 
/* 20 */     List<class_243> collectableBlock = AirGapFinder.findClosestValidStandingPos(targetBlocks, 5.0D);
/* 21 */     class_243 currentPos = collectableBlock.get(0);
/* 22 */     class_243 airGapPos = collectableBlock.get(1);
/* 23 */     ChatUtils.info("Found air gap at: " + airGapPos.toString(), new Object[0]);
/* 24 */     if (airGapPos != null)
/*    */     {
/* 26 */       return currentPos;
/*    */     }
/* 28 */     ChatUtils.info("No target blocks found within the search radius.", new Object[0]);
/* 29 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Controller\SmartGoto.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */