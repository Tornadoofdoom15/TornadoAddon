/*    */ package AutoplayAddon.AutoPlay.Controller;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Locator.CanPickUpTest;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.meteorclient.utils.player.PlayerUtils;
/*    */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*    */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2374;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2846;
/*    */ import net.minecraft.class_638;
/*    */ 
/*    */ public class SmartMine {
/*    */   private static CompletableFuture<Void> tickEventFuture;
/*    */   private static class_2338 targetBlockPos;
/*    */   private static int amount;
/*    */   
/*    */   @EventHandler
/*    */   private void onRender(Render3DEvent event) {
/* 31 */     double x1 = targetBlockPos.method_10263();
/* 32 */     double y1 = targetBlockPos.method_10264();
/* 33 */     double z1 = targetBlockPos.method_10260();
/* 34 */     double x2 = x1 + 1.0D;
/* 35 */     double y2 = y1 + 1.0D;
/* 36 */     double z2 = z1 + 1.0D;
/* 37 */     event.renderer.box(x1, y1, z1, x2, y2, z2, (Color)new SettingColor(255, 0, 255, 15), (Color)new SettingColor(255, 0, 255, 15), ShapeMode.Both, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   private void onTick(TickEvent.Pre event) {
/* 44 */     if (tickEventFuture != null && targetBlockPos != null) {
/* 45 */       class_638 class_638 = MeteorClient.mc.field_1687;
/* 46 */       if (class_638 != null && class_638.method_8320(targetBlockPos).method_26215()) {
/* 47 */         tickEventFuture.complete(null);
/* 48 */         amount--;
/* 49 */         if (amount <= 0) {
/* 50 */           ChatUtils.info("Finished mining the specified amount of blocks.", new Object[0]);
/*    */         }
/*    */       } else {
/* 53 */         MeteorClient.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12973, targetBlockPos, class_2350.field_11036));
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void mineBlocks(List<class_1792> targetBlocks, int Amount) {
/* 60 */     amount = Amount;
/* 61 */     MeteorClient.EVENT_BUS.subscribe(new SmartMine());
/* 62 */     tickEventFuture = new CompletableFuture<>();
/* 63 */     while (amount > 0) {
/* 64 */       List<class_243> collectableBlock = CanPickUpTest.findCollectableItem(targetBlocks);
/* 65 */       if (collectableBlock == null) {
/* 66 */         ChatUtils.info("No more target blocks found within the search radius.", new Object[0]);
/*    */         break;
/*    */       } 
/* 69 */       class_243 targetpos = collectableBlock.get(0);
/* 70 */       class_243 airGapPos = collectableBlock.get(1);
/* 71 */       mine(targetpos, airGapPos);
/* 72 */       ChatUtils.info("done mining", new Object[0]);
/*    */     } 
/* 74 */     MeteorClient.EVENT_BUS.unsubscribe(new SmartMine());
/* 75 */     if (amount > 0) {
/* 76 */       ChatUtils.info("No more target blocks found within the search radius.", new Object[0]);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static void mine(class_243 targetCenterPos, class_243 airGapPos) {
/* 82 */     if (PlayerUtils.distanceTo(targetCenterPos) > 5.0D);
/*    */ 
/*    */     
/* 85 */     targetBlockPos = class_2338.method_49638((class_2374)targetCenterPos);
/* 86 */     ChatUtils.info("Mining block at " + targetBlockPos.method_23854(), new Object[0]);
/* 87 */     MeteorClient.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12968, targetBlockPos, class_2350.field_11036));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Controller\SmartMine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */