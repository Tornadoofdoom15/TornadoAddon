/*    */ package AutoplayAddon.AutoPlay.Actions;
/*    */ 
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*    */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2846;
/*    */ import net.minecraft.class_638;
/*    */ 
/*    */ public class MineUtil
/*    */ {
/*    */   private static CompletableFuture<Void> tickEventFuture;
/*    */   private class_2338 targetBlockPos;
/*    */   
/*    */   @EventHandler
/*    */   private void onTick(TickEvent.Pre event) {
/* 25 */     if (tickEventFuture != null && this.targetBlockPos != null) {
/* 26 */       class_638 class_638 = MeteorClient.mc.field_1687;
/* 27 */       if (class_638 != null && class_638.method_8320(this.targetBlockPos).method_26215()) {
/* 28 */         tickEventFuture.complete(null);
/*    */       } else {
/* 30 */         MeteorClient.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12973, this.targetBlockPos, class_2350.field_11036));
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onRender(Render3DEvent event) {
/* 37 */     double x1 = this.targetBlockPos.method_10263();
/* 38 */     double y1 = this.targetBlockPos.method_10264();
/* 39 */     double z1 = this.targetBlockPos.method_10260();
/* 40 */     double x2 = x1 + 1.0D;
/* 41 */     double y2 = y1 + 1.0D;
/* 42 */     double z2 = z1 + 1.0D;
/*    */     
/* 44 */     event.renderer.box(x1, y1, z1, x2, y2, z2, (Color)new SettingColor(255, 0, 255, 15), (Color)new SettingColor(255, 0, 255, 15), ShapeMode.Both, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public void mine(class_2338 blockPos) {
/* 49 */     this.targetBlockPos = blockPos;
/* 50 */     ChatUtils.info("Mining block at " + this.targetBlockPos.method_23854(), new Object[0]);
/* 51 */     MeteorClient.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12968, this.targetBlockPos, class_2350.field_11036));
/* 52 */     MeteorClient.EVENT_BUS.subscribe(this);
/* 53 */     tickEventFuture = new CompletableFuture<>();
/*    */     try {
/* 55 */       tickEventFuture.get();
/* 56 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/* 57 */       e.printStackTrace();
/*    */     } 
/* 59 */     MeteorClient.EVENT_BUS.unsubscribe(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Actions\MineUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */