/*    */ package AutoplayAddon.AutoPlay.Actions;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Controller.SmartGoto;
/*    */ import AutoplayAddon.AutoPlay.Other.WaitUtil;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.meteorclient.utils.player.InvUtils;
/*    */ import meteordevelopment.meteorclient.utils.world.BlockUtils;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_2246;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_3858;
/*    */ import net.minecraft.class_3965;
/*    */ 
/*    */ public class CookingUtils {
/*    */   public static void cook(class_1792 itemToCook) {
/* 24 */     ChatUtils.info("going to furnace", new Object[0]);
/* 25 */     class_243 e = SmartGoto.gotoblock(List.of(class_2246.field_10181));
/* 26 */     class_2338 epos = new class_2338((int)Math.floor(e.method_10216()), (int)Math.floor(e.method_10214()), (int)Math.floor(e.method_10215()));
/* 27 */     ChatUtils.info("Waiting before cooking", new Object[0]);
/* 28 */     WaitUtil.wait1sec();
/*    */     
/* 30 */     class_243 playerEyePos = MeteorClient.mc.field_1724.method_33571();
/* 31 */     class_243 vec3d = playerEyePos.method_1019(e.method_1020(playerEyePos).method_1029().method_1021(0.5D));
/* 32 */     class_3965 blockHitResult = new class_3965(vec3d, class_2350.field_11036, epos, false);
/* 33 */     BlockUtils.interact(blockHitResult, class_1268.field_5808, false);
/* 34 */     ChatUtils.info("clicked furnace, waiting before cooking", new Object[0]);
/* 35 */     WaitUtil.wait1sec();
/* 36 */     int itemslot = InvUtils.find(new class_1792[] { itemToCook }).slot();
/* 37 */     int fuelslot = InvUtils.find(new class_1792[] { class_1802.field_8713 }).slot();
/* 38 */     ChatUtils.info("coal slot: " + fuelslot + " itemslot: " + itemslot, new Object[0]);
/*    */     
/* 40 */     InvUtils.move().from(itemslot).to(0);
/* 41 */     InvUtils.move().from(fuelslot).to(1);
/*    */ 
/*    */     
/* 44 */     boolean itemCooked = false;
/* 45 */     while (!itemCooked) {
/* 46 */       class_1703 class_1703 = MeteorClient.mc.field_1724.field_7512; if (class_1703 instanceof class_3858) { class_3858 furnaceScreenHandler = (class_3858)class_1703;
/* 47 */         class_1799 outputStack = furnaceScreenHandler.method_7611(2).method_7677();
/* 48 */         if (!outputStack.method_7960() && outputStack.method_7909() != itemToCook) {
/* 49 */           itemCooked = true; continue;
/*    */         } 
/* 51 */         WaitUtil.wait1sec(); }
/*    */     
/*    */     } 
/*    */     
/* 55 */     ChatUtils.info("Item cooked, retrieving from furnace", new Object[0]);
/* 56 */     InvUtils.move().from(2).toHotbar(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Actions\CookingUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */