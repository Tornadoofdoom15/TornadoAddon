/*    */ package AutoplayAddon.AutoPlay.Actions;
/*    */ 
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.meteorclient.utils.player.InvUtils;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1860;
/*    */ import net.minecraft.class_1869;
/*    */ import net.minecraft.class_1935;
/*    */ import net.minecraft.class_5455;
/*    */ 
/*    */ public class CraftUtil {
/*    */   public static class_1799 craftItem(class_1792 itemToCraft, int craftCount) {
/* 15 */     class_1860<?> recipeToCraft = findRecipeForItem(itemToCraft);
/* 16 */     boolean needsCraftingTable = needsCraftingTable(recipeToCraft);
/* 17 */     if (recipeToCraft != null) {
/* 18 */       for (int i = 0; i < craftCount; i++);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 45 */       int craftedSlot = InvUtils.find(new class_1792[] { itemToCraft }).slot();
/* 46 */       if (craftedSlot != -1) {
/* 47 */         InvUtils.move().from(craftedSlot).toHotbar(0);
/* 48 */         return new class_1799((class_1935)itemToCraft);
/*    */       } 
/*    */     } else {
/* 51 */       ChatUtils.info("no recipe provided", new Object[0]);
/*    */     } 
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   private static class_1860<?> findRecipeForItem(class_1792 itemToCraft) {
/* 57 */     class_5455 registryManager = MeteorClient.mc.field_1687.method_30349();
/* 58 */     class_1860<?> bestRecipe = null;
/* 59 */     int maxOutputCount = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     if (bestRecipe != null) {
/* 72 */       return bestRecipe;
/*    */     }
/* 74 */     ChatUtils.info("recipe not found", new Object[0]);
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean needsCraftingTable(class_1860<?> recipe) {
/* 80 */     if (recipe instanceof class_1869) { class_1869 shapedRecipe = (class_1869)recipe;
/* 81 */       int width = shapedRecipe.method_8150();
/* 82 */       int height = shapedRecipe.method_8158();
/* 83 */       return (width > 2 || height > 2); }
/*    */     
/* 85 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Actions\CraftUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */