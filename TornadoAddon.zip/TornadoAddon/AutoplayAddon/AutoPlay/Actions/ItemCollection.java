/*    */ package AutoplayAddon.AutoPlay.Actions;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Locator.GetLocUtil;
/*    */ import AutoplayAddon.AutoPlay.Locator.ValidPickupPoint;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class ItemCollection
/*    */ {
/*    */   public static boolean collect(List<class_1792> targetItems) {
/* 16 */     List<class_2338> itemPositions = GetLocUtil.findItemEntities(targetItems, 100.0D);
/* 17 */     if (itemPositions.isEmpty()) {
/* 18 */       return false;
/*    */     }
/* 20 */     for (class_2338 itemPosition : itemPositions) {
/* 21 */       ChatUtils.info("Item found at: " + itemPosition.method_10263() + " " + itemPosition.method_10264() + " " + itemPosition.method_10260(), new Object[0]);
/* 22 */       class_243 test = ValidPickupPoint.findFitSpot((class_1937)MeteorClient.mc.field_1687, itemPosition);
/* 23 */       if (test != null)
/*    */       {
/* 25 */         return true;
/*    */       }
/*    */     } 
/* 28 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Actions\ItemCollection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */