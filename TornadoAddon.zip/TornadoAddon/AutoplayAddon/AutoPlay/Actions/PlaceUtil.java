/*    */ package AutoplayAddon.AutoPlay.Actions;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.meteorclient.utils.player.FindItemResult;
/*    */ import meteordevelopment.meteorclient.utils.player.InvUtils;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_2246;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_310;
/*    */ 
/*    */ public class PlaceUtil
/*    */ {
/* 15 */   private static final class_310 mc = class_310.method_1551();
/*    */   public static void randomplace(class_2248 block) {
/* 17 */     class_1792 item = block.method_8389();
/* 18 */     ChatUtils.info("Looking for: " + item, new Object[0]);
/* 19 */     FindItemResult result = InvUtils.find(new class_1792[] { item });
/* 20 */     int craftedSlot = result.slot();
/* 21 */     ChatUtils.info("Crafted slot: " + craftedSlot, new Object[0]);
/* 22 */     List<class_2248> targetBlocks = Collections.singletonList(class_2246.field_10124);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\AutoPlay\Actions\PlaceUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */