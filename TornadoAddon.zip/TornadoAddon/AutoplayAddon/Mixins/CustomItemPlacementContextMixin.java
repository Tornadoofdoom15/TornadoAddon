/*    */ package AutoplayAddon.Mixins;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import net.minecraft.class_1750;
/*    */ import net.minecraft.class_2350;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ @Mixin({class_1750.class})
/*    */ public abstract class CustomItemPlacementContextMixin
/*    */ {
/*    */   @Inject(method = {"getPlayerLookDirection"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void injectCustomDirection(CallbackInfoReturnable<class_2350> cir) {
/* 17 */     if (AutoplayAddon.playerlookdirecrion == null) {
/*    */       return;
/*    */     }
/* 20 */     class_2350 customDirection = AutoplayAddon.playerlookdirecrion;
/* 21 */     cir.setReturnValue(customDirection);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Mixins\CustomItemPlacementContextMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */