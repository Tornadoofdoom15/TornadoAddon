package AutoplayAddon.Mixins;

import net.minecraft.class_1646;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1646.class})
public interface VillagerEntityAccessor {
  @Accessor
  long getLastRestockTime();
}


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Mixins\VillagerEntityAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */