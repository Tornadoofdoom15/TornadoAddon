package AutoplayAddon.Mixins;

import io.netty.channel.Channel;
import net.minecraft.class_2535;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2535.class})
public interface ClientConnectionMixin {
  @Accessor("channel")
  Channel getChannel();
}


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Mixins\ClientConnectionMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */