package AutoplayAddon.Mixins;

import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2828.class})
public interface PlayerMoveC2SPacketMixin {
  @Mutable
  @Accessor("onGround")
  void setOnGround(boolean paramBoolean);
  
  @Mutable
  @Accessor("x")
  void setX(double paramDouble);
  
  @Mutable
  @Accessor("y")
  void setY(double paramDouble);
  
  @Mutable
  @Accessor("z")
  void setZ(double paramDouble);
  
  @Mutable
  @Accessor("yaw")
  void setYaw(float paramFloat);
  
  @Mutable
  @Accessor("pitch")
  void setPitch(float paramFloat);
  
  @Mutable
  @Accessor("changePosition")
  void setChangePosition(boolean paramBoolean);
  
  @Mutable
  @Accessor("changeLook")
  void setChangeLook(boolean paramBoolean);
}


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Mixins\PlayerMoveC2SPacketMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */