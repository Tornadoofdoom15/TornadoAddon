/*    */ package AutoplayAddon.Mixins;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import net.minecraft.class_1838;
/*    */ import net.minecraft.class_2350;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ @Mixin({class_1838.class})
/*    */ public abstract class CustomItemUsageContextMixin
/*    */ {
/*    */   @Inject(method = {"getHorizontalPlayerFacing"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void injectCustomDirection(CallbackInfoReturnable<class_2350> cir) {
/* 17 */     class_2350 customDirection = AutoplayAddon.playerfacingdirecrion;
/* 18 */     if (customDirection == class_2350.field_11033 || customDirection == class_2350.field_11036 || customDirection == null) {
/*    */       return;
/*    */     }
/* 21 */     cir.setReturnValue(customDirection);
/*    */   }
/*    */   
/*    */   @Inject(method = {"getSide"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void injectCustomSide(CallbackInfoReturnable<class_2350> cir) {
/* 26 */     class_2350 customDirection = AutoplayAddon.blockhitdirection;
/* 27 */     if (customDirection == null) {
/*    */       return;
/*    */     }
/* 30 */     cir.setReturnValue(customDirection);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Mixins\CustomItemUsageContextMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */