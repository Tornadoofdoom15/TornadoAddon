package AutoplayAddon.Mixins;

import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_465.class})
public interface HandledScreenAccessor<T extends net.minecraft.class_1703> {
  @Accessor
  T getHandler();
}


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\Mixins\HandledScreenAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */