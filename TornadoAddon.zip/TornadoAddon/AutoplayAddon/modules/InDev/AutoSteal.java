/*    */ package AutoplayAddon.modules.InDev;
/*    */ import AutoplayAddon.AutoPlay.Actions.ItemCollection;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.ItemListSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_1792;
/*    */ 
/*    */ public class AutoSteal extends Module {
/*    */   private final SettingGroup sgGeneral;
/*    */   
/*    */   public AutoSteal() {
/* 18 */     super(AutoplayAddon.autoplay, "auto-steal", "master thief");
/*    */     
/* 20 */     this.sgGeneral = this.settings.getDefaultGroup();
/*    */     
/* 22 */     this.itemsToCollect = this.sgGeneral.add((Setting)((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder())
/* 23 */         .name("items-to-collect"))
/* 24 */         .description("Items to drop."))
/* 25 */         .build());
/*    */   }
/*    */   private final Setting<List<class_1792>> itemsToCollect;
/*    */   
/*    */   @EventHandler
/*    */   private void onPreTick(TickEvent.Pre event) {
/* 31 */     if (((List)this.itemsToCollect.get()).isEmpty())
/* 32 */       return;  (new Thread(() -> {
/*    */           if (ItemCollection.collect((List)this.itemsToCollect.get())) {
/*    */             ChatUtils.info("Item found", new Object[0]);
/*    */           }
/* 36 */         })).start();
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InDev\AutoSteal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */