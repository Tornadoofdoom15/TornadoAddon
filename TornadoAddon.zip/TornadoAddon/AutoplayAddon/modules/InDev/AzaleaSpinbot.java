/*     */ package AutoplayAddon.modules.InDev;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_243;
/*     */ import org.json.simple.JSONObject;
/*     */ 
/*     */ public class AzaleaSpinbot extends Module {
/*  18 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*  19 */   private final Map<Integer, Double> clientAngles = new HashMap<>(); private final Setting<Mode> mode; private final Setting<Integer> distanceFromPlayer; private final Setting<Integer> spinSpeed; private final Setting<Integer> totalClients; private int prevTotalClients;
/*     */   public AzaleaSpinbot() {
/*  21 */     super(AutoplayAddon.autoplay, "azalea-controller", "Allows multiple players to circle around a player in a synchronized fashion");
/*     */ 
/*     */     
/*  24 */     this.mode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  25 */         .name("formation-mode"))
/*  26 */         .description("The formation mode, either line or circle."))
/*  27 */         .defaultValue(Mode.Circle))
/*  28 */         .build());
/*  29 */     this.distanceFromPlayer = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  30 */         .name("distance-from-player"))
/*  31 */         .description("Distance each client should maintain from the server player."))
/*  32 */         .defaultValue(Integer.valueOf(20)))
/*  33 */         .min(0)
/*  34 */         .sliderMax(300)
/*  35 */         .build());
/*     */     
/*  37 */     this.spinSpeed = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  38 */         .name("spin-speed"))
/*  39 */         .description("Distance each client should maintain from the server player."))
/*  40 */         .defaultValue(Integer.valueOf(20)))
/*  41 */         .min(0)
/*  42 */         .sliderMax(300)
/*  43 */         .build());
/*     */     
/*  45 */     this.totalClients = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  46 */         .name("total-clients1"))
/*  47 */         .description("Total number of clients."))
/*  48 */         .defaultValue(Integer.valueOf(20)))
/*  49 */         .min(0)
/*  50 */         .sliderMax(300)
/*  51 */         .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.prevTotalClients = 0;
/*     */   } public enum Mode {
/*     */     Line, Circle, Raycast; } @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*  65 */     if (((Integer)this.totalClients.get()).intValue() != this.prevTotalClients) {
/*  66 */       updateClientAngles();
/*  67 */       this.prevTotalClients = ((Integer)this.totalClients.get()).intValue();
/*     */     } 
/*  69 */     writeToJsonFile();
/*     */   }
/*     */   
/*     */   private void writeToJsonFile() {
/*  73 */     JSONObject allClientsData = new JSONObject();
/*     */     
/*  75 */     for (int id = 0; id <= ((Integer)this.totalClients.get()).intValue() + 1; id++) {
/*     */       class_243 pos;
/*  77 */       if (this.mode.get() == Mode.Line) {
/*  78 */         pos = calculatePositionBasedOnAngle(id + 1);
/*     */       } else {
/*  80 */         pos = calculatePositionBasedOnAngle(id);
/*     */       } 
/*     */ 
/*     */       
/*  84 */       float pitch = this.mc.field_1724.method_5695(1.0F);
/*  85 */       float yaw = this.mc.field_1724.method_5705(1.0F);
/*     */       
/*  87 */       JSONObject clientData = new JSONObject();
/*  88 */       clientData.put("x", Double.valueOf(pos.field_1352));
/*  89 */       clientData.put("y", Double.valueOf(pos.field_1351));
/*  90 */       clientData.put("z", Double.valueOf(pos.field_1350));
/*  91 */       clientData.put("pitch", Float.valueOf(pitch));
/*  92 */       clientData.put("yaw", Float.valueOf(yaw));
/*     */       
/*  94 */       allClientsData.put(String.valueOf(id), clientData);
/*     */     } 
/*     */ 
/*     */     
/*  98 */     String homeDirectory = System.getProperty("user.home");
/*  99 */     String filePath = homeDirectory + "/test/test.json";
/*     */     
/* 101 */     try { FileWriter file = new FileWriter(filePath, false); 
/* 102 */       try { file.write(allClientsData.toJSONString());
/* 103 */         file.close(); } catch (Throwable throwable) { try { file.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 104 */     { e.printStackTrace(); }
/*     */   
/*     */   }
/*     */   
/*     */   private void updateClientAngles() {
/* 109 */     int totalClientsCount = ((Integer)this.totalClients.get()).intValue();
/* 110 */     double anglePerClient = 6.283185307179586D / totalClientsCount;
/*     */     
/* 112 */     this.clientAngles.clear();
/* 113 */     for (int id = 1; id <= totalClientsCount; id++) {
/* 114 */       double baseAngle = anglePerClient * (id - 1);
/* 115 */       this.clientAngles.put(Integer.valueOf(id), Double.valueOf(baseAngle));
/*     */     } 
/*     */   }
/*     */   
/*     */   private class_243 calculatePositionBasedOnAngle(int id) {
/* 120 */     Mode currentMode = (Mode)this.mode.get();
/* 121 */     float playerYaw = this.mc.field_1724.method_5705(1.0F);
/* 122 */     double playerYawRadians = Math.toRadians(playerYaw);
/*     */     
/* 124 */     if (currentMode == Mode.Circle) {
/* 125 */       if (this.clientAngles.get(Integer.valueOf(id)) == null)
/*     */       {
/* 127 */         return this.mc.field_1724.method_19538();
/*     */       }
/*     */       
/* 130 */       double currentAngle = ((Double)this.clientAngles.get(Integer.valueOf(id))).doubleValue();
/*     */       
/* 132 */       double normalizedSpinSpeed = ((Integer)this.spinSpeed.get()).intValue() / 300.0D;
/* 133 */       double incrementAngle = 6.283185307179586D * normalizedSpinSpeed / 360.0D;
/* 134 */       currentAngle = (currentAngle + incrementAngle) % 6.283185307179586D;
/*     */       
/* 136 */       this.clientAngles.put(Integer.valueOf(id), Double.valueOf(currentAngle));
/*     */       
/* 138 */       double dx = Math.cos(currentAngle + playerYawRadians) * ((Integer)this.distanceFromPlayer.get()).intValue();
/* 139 */       double dz = Math.sin(currentAngle + playerYawRadians) * ((Integer)this.distanceFromPlayer.get()).intValue();
/*     */       
/* 141 */       return new class_243(this.mc.field_1724.method_23317() + dx, this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321() + dz);
/* 142 */     }  if (currentMode == Mode.Line)
/* 143 */       return lineFormation(id, playerYaw); 
/* 144 */     if (currentMode == Mode.Raycast) {
/* 145 */       int newid = id - 1;
/* 146 */       class_243 cameraPos = this.mc.field_1724.method_19538().method_1031(0.0D, this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()), 0.0D);
/*     */       
/* 148 */       class_243 direction = class_243.method_1030(this.mc.field_1724.method_36455(), this.mc.field_1724.method_36454()).method_1029();
/*     */       
/* 150 */       class_243 increment = direction.method_1021(newid);
/* 151 */       class_243 pos1 = cameraPos.method_1019(increment);
/* 152 */       class_243 newpos = pos1.method_1023(0.0D, this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()), 0.0D);
/* 153 */       return newpos;
/*     */     } 
/*     */     
/* 156 */     return new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
/*     */   }
/*     */   
/*     */   private class_243 lineFormation(int id, float playerYaw) {
/* 160 */     double angle = Math.toRadians(playerYaw);
/* 161 */     int sign = (id % 2 == 0) ? 1 : -1;
/* 162 */     int distanceFactor = id / 2;
/* 163 */     double distance = ((Integer)this.distanceFromPlayer.get()).intValue();
/*     */     
/* 165 */     double x = (sign * distanceFactor) * distance * Math.cos(angle) + this.mc.field_1724.method_23317();
/* 166 */     double y = this.mc.field_1724.method_23318();
/* 167 */     double z = (sign * distanceFactor) * distance * Math.sin(angle) + this.mc.field_1724.method_23321();
/*     */     
/* 169 */     return new class_243(x, y, z);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InDev\AzaleaSpinbot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */