/*     */ package AutoplayAddon.modules.InDev;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import java.io.IOException;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2848;
/*     */ 
/*     */ public class AzaleaControllerTest extends Module {
/*     */   private final SettingGroup sgGeneral;
/*     */   private final Setting<Integer> time;
/*     */   private final Setting<Integer> yoffset;
/*     */   private final Setting<Integer> zoffset;
/*     */   
/*     */   public AzaleaControllerTest() {
/*  18 */     super(AutoplayAddon.autoplay, "AzaleaControllerTest", "Attempts to instantly mine blocks.");
/*     */     
/*  20 */     this.sgGeneral = this.settings.getDefaultGroup();
/*  21 */     this.time = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  22 */         .name("Ticks to skip"))
/*  23 */         .description("How many ticks to wait betyween each teleport."))
/*  24 */         .defaultValue(Integer.valueOf(0)))
/*  25 */         .min(0)
/*  26 */         .sliderMax(100)
/*  27 */         .build());
/*     */ 
/*     */     
/*  30 */     this.yoffset = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  31 */         .name("yoffset"))
/*  32 */         .description("How many ticks to wait betyween each teleport."))
/*  33 */         .defaultValue(Integer.valueOf(20)))
/*  34 */         .min(0)
/*  35 */         .sliderMax(100)
/*  36 */         .build());
/*     */ 
/*     */     
/*  39 */     this.zoffset = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  40 */         .name("zoffset"))
/*  41 */         .description("How many ticks to wait betyween each teleport."))
/*  42 */         .defaultValue(Integer.valueOf(20)))
/*  43 */         .min(0)
/*  44 */         .sliderMax(100)
/*  45 */         .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.lock = new Object();
/*  52 */     this.boatId = null;
/*     */   }
/*     */   private Socket socket; private PrintWriter out; private BufferedReader in; private final Object lock; private Integer boatId;
/*     */   public void onActivate() {
/*  56 */     (new Thread(() -> {
/*     */           try {
/*     */             startConnection("127.0.0.1", 34254);
/*     */             
/*     */             double x = this.mc.field_1724.method_23317();
/*     */             
/*     */             double y = this.mc.field_1724.method_23318();
/*     */             double z = this.mc.field_1724.method_23321();
/*     */             String positionData = String.format("{\"x\": %.2f, \"y\": %.2f, \"z\": %.2f}\n", new Object[] { Double.valueOf(x), Double.valueOf(y + 2.0D), Double.valueOf(z) });
/*     */             sendMessage(positionData);
/*     */             this.boatId = null;
/*     */             startResponseListener();
/*     */             synchronized (this.lock) {
/*     */               while (this.boatId == null) {
/*     */                 this.lock.wait();
/*     */               }
/*     */             } 
/*     */             info("We have received the first response from the server we can now get in the boat " + this.boatId, new Object[0]);
/*     */             class_1297 entity = this.mc.field_1687.method_8469(this.boatId.intValue());
/*     */             Thread.sleep(((Integer)this.time.get()).intValue());
/*     */             PacketUtils.sendPacket((class_2596)class_2824.method_34207(entity, false, class_1268.field_5808));
/*     */             info("We have entered the boat with id " + this.boatId + " we can now move the boat", new Object[0]);
/*     */             Thread.sleep(((Integer)this.time.get()).intValue());
/*     */             class_243 newpos = new class_243(x, y, z + ((Integer)this.zoffset.get()).intValue());
/*     */             String positionData1 = String.format("{\"x\": %.2f, \"y\": %.2f, \"z\": %.2f}\n", new Object[] { Double.valueOf(newpos.field_1352), Double.valueOf(newpos.field_1351), Double.valueOf(newpos.field_1350) });
/*     */             this.boatId = null;
/*     */             sendMessage(positionData1);
/*     */             synchronized (this.lock) {
/*     */               while (this.boatId == null) {
/*     */                 this.lock.wait();
/*     */               }
/*     */             } 
/*     */             info("We have received the second response from the server we can now exit the boat " + this.boatId, new Object[0]);
/*     */             Thread.sleep(((Integer)this.time.get()).intValue());
/*     */             PacketUtils.sendPacket((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12979));
/*     */             Thread.sleep(((Integer)this.time.get()).intValue());
/*     */             String positionData2 = String.format("{\"x\": %.2f, \"y\": %.2f, \"z\": %.2f}\n", new Object[] { Double.valueOf(newpos.field_1352), Double.valueOf(newpos.field_1351 + ((Integer)this.yoffset.get()).intValue()), Double.valueOf(newpos.field_1350) });
/*     */             sendMessage(positionData2);
/*     */             info("We have told the boat to go 20 blocks above up", new Object[0]);
/*  95 */           } catch (IOException|InterruptedException e) {
/*     */             e.printStackTrace();
/*     */           } 
/*  98 */         })).start();
/*     */   }
/*     */   
/*     */   private void startResponseListener() {
/* 102 */     (new Thread(() -> {
/*     */           try {
/*     */             String response;
/*     */             while ((response = this.in.readLine()) != null) {
/*     */               synchronized (this.lock) {
/*     */                 if (!response.equals("NULL")) {
/*     */                   try {
/*     */                     this.boatId = Integer.valueOf(Integer.parseInt(response));
/* 110 */                   } catch (NumberFormatException e) {
/*     */                     this.boatId = null;
/*     */                   } 
/*     */                 } else {
/*     */                   this.boatId = null;
/*     */                 } 
/*     */                 this.lock.notifyAll();
/*     */               } 
/*     */             } 
/* 119 */           } catch (IOException e) {
/*     */             e.printStackTrace();
/*     */           } 
/* 122 */         })).start();
/*     */   }
/*     */   
/*     */   private void startConnection(String ip, int port) throws IOException {
/* 126 */     this.socket = new Socket(ip, port);
/* 127 */     this.out = new PrintWriter(this.socket.getOutputStream(), true);
/* 128 */     this.in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
/*     */   }
/*     */   
/*     */   private void sendMessage(String msg) throws IOException {
/* 132 */     this.out.println(msg);
/*     */   }
/*     */   
/*     */   public void onDeactivate() {
/*     */     try {
/* 137 */       if (this.socket != null && !this.socket.isClosed()) {
/* 138 */         this.socket.close();
/*     */       }
/* 140 */     } catch (IOException e) {
/* 141 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InDev\AzaleaControllerTest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */