/*     */ package AutoplayAddon.modules.InDev;
/*     */ import AutoplayAddon.modules.ScardyCat;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.ModuleListSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2663;
/*     */ import net.minecraft.class_2749;
/*     */ 
/*     */ public class AntiDeath extends Module {
/*     */   private final SettingGroup sgGeneral;
/*     */   private final Setting<Boolean> totem;
/*     */   private final Setting<Boolean> belowhp;
/*     */   private final Setting<Integer> minhp;
/*     */   
/*     */   public AntiDeath() {
/*  23 */     super(AutoplayAddon.autoplay, "anti-death", "Automatically trigger an action when you are about to die.");
/*     */     
/*  25 */     this.sgGeneral = this.settings.getDefaultGroup();
/*     */ 
/*     */     
/*  28 */     this.totem = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  29 */         .name("trigger-on-totem"))
/*  30 */         .description("Trigger the action on popping a totem."))
/*  31 */         .defaultValue(Boolean.valueOf(true)))
/*  32 */         .build());
/*     */ 
/*     */     
/*  35 */     this.belowhp = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  36 */         .name("trigger-when-below-hp"))
/*  37 */         .description("Trigger the action when your health goes below the selected hp."))
/*  38 */         .defaultValue(Boolean.valueOf(false)))
/*  39 */         .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     Objects.requireNonNull(this.belowhp); this.minhp = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("hp-to-trigger-on")).description("Trigger the action when below or on this hp")).defaultValue(Integer.valueOf(10))).min(0).sliderMax(300).visible(this.belowhp::get))
/*  48 */         .build());
/*     */ 
/*     */     
/*  51 */     this.pauseModules = this.sgGeneral.add((Setting)((ModuleListSetting.Builder)((ModuleListSetting.Builder)(new ModuleListSetting.Builder())
/*  52 */         .name("modules-to-enable"))
/*  53 */         .description("Enables any of the selected modules when AntiDeath triggers."))
/*  54 */         .defaultValue(new Class[] { ScardyCat.class
/*  55 */           }).build());
/*     */ 
/*     */ 
/*     */     
/*  59 */     this.disconnect = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  60 */         .name("disconnect"))
/*  61 */         .description("Do you want to disconnect when AntoDeath triggers?"))
/*  62 */         .defaultValue(Boolean.valueOf(false)))
/*  63 */         .build());
/*     */ 
/*     */     
/*  66 */     this.tpabove = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  67 */         .name("TP-above-build-limit"))
/*  68 */         .description("Do you want to teleport above build limit when AntoDeath triggers?"))
/*  69 */         .defaultValue(Boolean.valueOf(false)))
/*  70 */         .build());
/*     */   }
/*     */   public final Setting<List<Module>> pauseModules; private final Setting<Boolean> disconnect; private final Setting<Boolean> tpabove;
/*     */   float currentHealth;
/*     */   
/*     */   private class StaticListener { @EventHandler
/*     */     private void healthListener(PacketEvent.Receive event) {
/*  77 */       if (event.packet instanceof class_2749) {
/*  78 */         class_2749 packet = (class_2749)event.packet;
/*  79 */         AntiDeath.this.currentHealth = packet.method_11833();
/*     */       } 
/*     */     } }
/*     */   
/*     */   @EventHandler(priority = 202)
/*     */   public void onRecievePacket(PacketEvent.Receive event) {
/*  85 */     if (event.packet instanceof class_2663) {
/*  86 */       class_2663 packet = (class_2663)event.packet;
/*  87 */       if (((Boolean)this.totem.get()).booleanValue() && packet.method_11470() == 35 && packet.method_11469((class_1937)this.mc.field_1687) == this.mc.field_1724) doAction(); 
/*     */     } 
/*  89 */     if (event.packet instanceof class_2749) {
/*  90 */       class_2749 packet = (class_2749)event.packet;
/*  91 */       if (((Boolean)this.belowhp.get()).booleanValue() && packet.method_11833() <= ((Integer)this.minhp.get()).intValue()) doAction(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doAction() {
/*  96 */     ChatUtils.info("Anti Death triggered", new Object[0]);
/*  97 */     for (Module module : this.pauseModules.get()) {
/*  98 */       if (!module.isActive()) module.toggle(); 
/*     */     } 
/* 100 */     if (((Boolean)this.tpabove.get()).booleanValue()) Movement.setPos(new class_243((this.mc.field_1724.method_19538()).field_1352, Math.max(ServerSideValues.serversidedposition.field_1351, 320.0D), (this.mc.field_1724.method_19538()).field_1350), true, null, null); 
/* 101 */     if (((Boolean)this.disconnect.get()).booleanValue()) PacketUtils.sendPacket((class_2596)new class_2868(10)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InDev\AntiDeath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */