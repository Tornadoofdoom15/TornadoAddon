/*    */ package AutoplayAddon.modules.InDev;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.Socket;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ 
/*    */ public class AzaleaManager extends Module {
/* 15 */   private int tickCounter = 0;
/* 16 */   private int messageCounter = 0;
/* 17 */   private final String serverAddress = "127.0.0.1";
/* 18 */   private final int serverPort = 34254;
/*    */   
/*    */   private Socket socket;
/*    */   
/*    */   public AzaleaManager() {
/* 23 */     super(AutoplayAddon.autoplay, "AzaleaManager", "Attempts to instantly mine blocks.");
/*    */   }
/*    */   private PrintWriter out; private BufferedReader in;
/*    */   @EventHandler
/*    */   private void onTick(TickEvent.Pre event) {
/* 28 */     this.tickCounter++;
/* 29 */     this.messageCounter++;
/*    */ 
/*    */     
/* 32 */     if (this.tickCounter >= 20 && (this.socket == null || this.socket.isClosed())) {
/*    */       try {
/* 34 */         this.socket = new Socket("127.0.0.1", 34254);
/* 35 */         this.out = new PrintWriter(this.socket.getOutputStream(), true);
/* 36 */         ChatUtils.info("Successfully connected", new Object[0]);
/* 37 */         this.tickCounter = 0;
/* 38 */       } catch (IOException iOException) {}
/*    */     }
/*    */     
/* 41 */     if (this.socket != null && !this.socket.isClosed() && this.in == null) {
/* 42 */       startListening();
/*    */     }
/*    */     
/* 45 */     if (this.messageCounter >= 100 && this.socket != null && !this.socket.isClosed()) {
/*    */       try {
/* 47 */         String playerName = this.mc.field_1724.method_5476().getString();
/* 48 */         String jsonMessage = "{\"sendername\": \"" + playerName + "\", \"message\": \"test\"}";
/* 49 */         this.out.println(jsonMessage);
/* 50 */         this.messageCounter = 0;
/* 51 */       } catch (Exception exception) {}
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void startListening() {
/*    */     try {
/* 59 */       this.in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
/* 60 */       (new Thread(() -> {
/*    */             try {
/*    */               String line;
/*    */               while ((line = this.in.readLine()) != null) {
/*    */                 ChatUtils.info(line, new Object[0]);
/*    */               }
/* 66 */             } catch (IOException iOException) {}
/* 67 */           })).start();
/* 68 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InDev\AzaleaManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */