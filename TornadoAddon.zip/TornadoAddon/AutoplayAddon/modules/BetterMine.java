/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoPlay.Mining.MineUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_265;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2828;
/*     */ import net.minecraft.class_2846;
/*     */ import net.minecraft.class_2879;
/*     */ 
/*     */ public class BetterMine extends Module {
/*  29 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*  30 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*  31 */   private final Setting<Boolean> swinghandclient = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  32 */       .name("swing-hand-client"))
/*  33 */       .description("Clients will copy the servers sneaking status"))
/*  34 */       .defaultValue(Boolean.valueOf(true)))
/*  35 */       .build());
/*     */   
/*  37 */   private final Setting<Boolean> swinghandserver = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  38 */       .name("swing-hand-server"))
/*  39 */       .description("Clients will copy the servers sneaking status"))
/*  40 */       .defaultValue(Boolean.valueOf(false)))
/*  41 */       .build());
/*     */ 
/*     */   
/*  44 */   private final Setting<Boolean> mineSecondary = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  45 */       .name("secondary-block"))
/*  46 */       .description("Clients will copy the servers sneaking status"))
/*  47 */       .defaultValue(Boolean.valueOf(false)))
/*  48 */       .build());
/*     */ 
/*     */   
/*  51 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  52 */       .name("shape-mode"))
/*  53 */       .description("How the shapes are rendered."))
/*  54 */       .defaultValue(ShapeMode.Both))
/*  55 */       .build());
/*     */ 
/*     */   
/*  58 */   private final Setting<SettingColor> startColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  59 */       .name("start-color"))
/*  60 */       .description("The color for the non-broken block."))
/*  61 */       .defaultValue(new SettingColor(25, 252, 25, 150))
/*  62 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  66 */   private final Setting<SettingColor> endColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  67 */       .name("end-color"))
/*  68 */       .description("The color for the fully-broken block."))
/*  69 */       .defaultValue(new SettingColor(255, 25, 25, 150))
/*  70 */       .build());
/*     */ 
/*     */   
/*  73 */   private final Color cSides = new Color();
/*  74 */   private final Color cLines = new Color(); private int startTick;
/*     */   private float destroyProgressFast;
/*     */   private float destroyProgressSlow;
/*  77 */   private final class_2350 direction = class_2350.field_11036; private class_2680 fastBlockState; private class_2680 secondaryBlockState; private class_2338 fastBlockPos; private class_2338 secondaryBlockPos;
/*     */   
/*     */   public BetterMine() {
/*  80 */     super(AutoplayAddon.autoplay, "better-mine", "Attempts to instantly mine blocks.");
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.fastBlockState = null; this.secondaryBlockState = null;
/*  85 */     this.fastBlockPos = null; this.secondaryBlockPos = null;
/*     */   }
/*     */   
/*     */   public void onActivate() {
/*  89 */     this.fastBlockPos = null;
/*  90 */     this.fastBlockState = null;
/*  91 */     this.secondaryBlockState = null;
/*  92 */     this.secondaryBlockPos = null;
/*  93 */     this.destroyProgressSlow = 0.0F;
/*  94 */     this.destroyProgressFast = 0.0F;
/*  95 */     this.startTick = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onStartBreakingBlock(StartBreakingBlockEvent event) {
/* 101 */     event.cancel();
/* 102 */     event.setCancelled(true);
/* 103 */     if (this.fastBlockPos != null || this.secondaryBlockPos != null)
/* 104 */       return;  this.destroyProgressFast = 0.0F;
/* 105 */     this.destroyProgressSlow = 0.0F;
/* 106 */     this.startTick = ServerSideValues.ticks;
/* 107 */     class_2338 hitBlockPos = event.blockPos;
/*     */     
/* 109 */     class_2338 downBlock = hitBlockPos.method_10074();
/* 110 */     class_2680 downBlockState = this.mc.field_1687.method_8320(downBlock);
/*     */     
/* 112 */     this.secondaryBlockState = this.mc.field_1687.method_8320(hitBlockPos);
/* 113 */     this.secondaryBlockPos = hitBlockPos;
/*     */ 
/*     */     
/* 116 */     if (!downBlockState.method_51367() || !((Boolean)this.mineSecondary.get()).booleanValue()) {
/* 117 */       this.secondaryBlockPos = null;
/* 118 */       fastBreak(hitBlockPos);
/*     */       
/*     */       return;
/*     */     } 
/* 122 */     if (MineUtils.canInstaBreak(this.secondaryBlockState, hitBlockPos)) {
/* 123 */       ChatUtils.info("We can Insta Break the bottom below", new Object[0]);
/* 124 */       fastBreak(downBlock);
/* 125 */       fastBreak(hitBlockPos);
/*     */       return;
/*     */     } 
/* 128 */     if (MineUtils.canInstaBreak(downBlockState, downBlock)) {
/* 129 */       ChatUtils.info("We can Insta Break the block", new Object[0]);
/* 130 */       fastBreak(hitBlockPos);
/* 131 */       fastBreak(downBlock);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 136 */     PacketUtils.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12968, hitBlockPos, this.direction));
/* 137 */     PacketUtils.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, hitBlockPos, this.direction));
/*     */     
/* 139 */     fastBreak(hitBlockPos.method_10074());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fastBreak(class_2338 blockPos) {
/* 145 */     this.fastBlockState = this.mc.field_1687.method_8320(blockPos);
/* 146 */     this.fastBlockPos = blockPos;
/*     */     
/* 148 */     if (((Boolean)this.swinghandclient.get()).booleanValue()) this.mc.field_1724.method_6104(this.mc.field_1724.method_6058()); 
/* 149 */     if (((Boolean)this.swinghandserver.get()).booleanValue()) PacketUtils.sendPacket((class_2596)new class_2879(this.mc.field_1724.method_6058())); 
/* 150 */     PacketUtils.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12968, blockPos, this.direction));
/* 151 */     float f1 = MineUtils.calcBlockBreakingDelta(this.fastBlockState, blockPos);
/*     */ 
/*     */     
/* 154 */     if (f1 >= 1.0F) {
/* 155 */       ChatUtils.info("Insta Break with progress: " + f1, new Object[0]);
/* 156 */       this.mc.field_1687.method_8501(blockPos, class_2246.field_10124.method_9564());
/* 157 */       this.fastBlockPos = null;
/* 158 */       this.fastBlockState = null;
/*     */       
/*     */       return;
/*     */     } 
/* 162 */     if (f1 >= 0.7F) {
/* 163 */       this.mc.method_1562().method_52787((class_2596)new class_2828.class_5911(true));
/* 164 */       PacketUtils.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, blockPos, this.direction));
/* 165 */       ChatUtils.info("Block broken at start with progress: " + f1, new Object[0]);
/* 166 */       this.mc.field_1687.method_8501(blockPos, class_2246.field_10124.method_9564());
/* 167 */       this.fastBlockPos = null;
/* 168 */       this.fastBlockState = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/* 174 */     int l = ServerSideValues.ticks - this.startTick;
/* 175 */     if (this.fastBlockPos != null || this.secondaryBlockPos != null) {
/* 176 */       if (((Boolean)this.swinghandclient.get()).booleanValue()) this.mc.field_1724.method_6104(this.mc.field_1724.method_6058()); 
/* 177 */       if (((Boolean)this.swinghandserver.get()).booleanValue()) PacketUtils.sendPacket((class_2596)new class_2879(this.mc.field_1724.method_6058())); 
/*     */     } 
/* 179 */     if (this.fastBlockPos != null) {
/* 180 */       float fast = MineUtils.calcBlockBreakingDelta(this.fastBlockState, this.fastBlockPos) * (l + 1);
/* 181 */       this.destroyProgressFast = fast / 0.7F;
/* 182 */       if (fast >= 0.7F) {
/* 183 */         this.mc.method_1562().method_52787((class_2596)new class_2828.class_5911(true));
/* 184 */         PacketUtils.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, this.fastBlockPos, this.direction));
/* 185 */         this.mc.field_1687.method_8501(this.fastBlockPos, class_2246.field_10124.method_9564());
/* 186 */         this.fastBlockPos = null;
/* 187 */         this.fastBlockState = null;
/* 188 */         this.destroyProgressFast = 0.0F;
/*     */       } 
/*     */     } 
/* 191 */     if (this.secondaryBlockPos != null) {
/* 192 */       float slow = MineUtils.calcBlockBreakingDelta(this.secondaryBlockState, this.secondaryBlockPos) * (l + 1);
/* 193 */       this.destroyProgressSlow = slow;
/* 194 */       if (slow >= 1.0F) {
/* 195 */         ChatUtils.info("Removed slow block: " + slow, new Object[0]);
/* 196 */         this.mc.field_1687.method_8501(this.secondaryBlockPos, class_2246.field_10124.method_9564());
/* 197 */         this.secondaryBlockPos = null;
/* 198 */         this.secondaryBlockState = null;
/* 199 */         this.destroyProgressSlow = 0.0F;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 207 */     if (this.fastBlockPos != null) {
/* 208 */       renderBlockFromPos(event, this.fastBlockPos, this.destroyProgressFast);
/*     */     }
/* 210 */     if (this.secondaryBlockPos != null)
/* 211 */       renderBlockFromPos(event, this.secondaryBlockPos, this.destroyProgressSlow); 
/*     */   }
/*     */   
/*     */   private void renderBlockFromPos(Render3DEvent event, class_2338 blockPos, double progress) {
/* 215 */     class_2680 state = this.mc.field_1687.method_8320(blockPos);
/* 216 */     class_265 shape = state.method_26218((class_1922)this.mc.field_1687, blockPos);
/* 217 */     if (shape == null || shape.method_1110())
/*     */       return; 
/* 219 */     class_238 orig = shape.method_1107();
/*     */     
/* 221 */     double shrinkFactor = 1.0D - progress;
/*     */     
/* 223 */     renderBlock(event, orig, blockPos, shrinkFactor, progress);
/*     */   }
/*     */   
/*     */   private void renderBlock(Render3DEvent event, class_238 orig, class_2338 pos, double shrinkFactor, double progress) {
/* 227 */     class_238 box = orig.method_1002(orig
/* 228 */         .method_17939() * shrinkFactor, orig
/* 229 */         .method_17940() * shrinkFactor, orig
/* 230 */         .method_17941() * shrinkFactor);
/*     */ 
/*     */     
/* 233 */     double xShrink = orig.method_17939() * shrinkFactor / 2.0D;
/* 234 */     double yShrink = orig.method_17940() * shrinkFactor / 2.0D;
/* 235 */     double zShrink = orig.method_17941() * shrinkFactor / 2.0D;
/*     */     
/* 237 */     double x1 = pos.method_10263() + box.field_1323 + xShrink;
/* 238 */     double y1 = pos.method_10264() + box.field_1322 + yShrink;
/* 239 */     double z1 = pos.method_10260() + box.field_1321 + zShrink;
/* 240 */     double x2 = pos.method_10263() + box.field_1320 + xShrink;
/* 241 */     double y2 = pos.method_10264() + box.field_1325 + yShrink;
/* 242 */     double z2 = pos.method_10260() + box.field_1324 + zShrink;
/*     */     
/* 244 */     Color c1Sides = ((SettingColor)this.startColor.get()).copy().a(((SettingColor)this.startColor.get()).a / 2);
/* 245 */     Color c2Sides = ((SettingColor)this.endColor.get()).copy().a(((SettingColor)this.endColor.get()).a / 2);
/*     */     
/* 247 */     this.cSides.set(
/* 248 */         (int)Math.round(c1Sides.r + (c2Sides.r - c1Sides.r) * progress), 
/* 249 */         (int)Math.round(c1Sides.g + (c2Sides.g - c1Sides.g) * progress), 
/* 250 */         (int)Math.round(c1Sides.b + (c2Sides.b - c1Sides.b) * progress), 
/* 251 */         (int)Math.round(c1Sides.a + (c2Sides.a - c1Sides.a) * progress));
/*     */ 
/*     */     
/* 254 */     Color c1Lines = (Color)this.startColor.get();
/* 255 */     Color c2Lines = (Color)this.endColor.get();
/*     */     
/* 257 */     this.cLines.set(
/* 258 */         (int)Math.round(c1Lines.r + (c2Lines.r - c1Lines.r) * progress), 
/* 259 */         (int)Math.round(c1Lines.g + (c2Lines.g - c1Lines.g) * progress), 
/* 260 */         (int)Math.round(c1Lines.b + (c2Lines.b - c1Lines.b) * progress), 
/* 261 */         (int)Math.round(c1Lines.a + (c2Lines.a - c1Lines.a) * progress));
/*     */ 
/*     */     
/* 264 */     event.renderer.box(x1, y1, z1, x2, y2, z2, this.cSides, this.cLines, (ShapeMode)this.shapeMode.get(), 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\BetterMine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */