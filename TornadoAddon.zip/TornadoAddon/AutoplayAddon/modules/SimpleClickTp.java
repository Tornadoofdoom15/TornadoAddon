/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoPlay.Movement.CanTeleport;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3959;
/*     */ import net.minecraft.class_4184;
/*     */ 
/*     */ public class SimpleClickTp extends Module {
/*  21 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*  22 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*     */ 
/*     */   
/*  25 */   private final Setting<Boolean> render = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  26 */       .name("render"))
/*  27 */       .description("Renders a block overlay where you will be teleported."))
/*  28 */       .defaultValue(Boolean.valueOf(true)))
/*  29 */       .build());
/*     */   
/*  31 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  32 */       .name("shape-mode"))
/*  33 */       .description("How the shapes are rendered."))
/*  34 */       .defaultValue(ShapeMode.Both))
/*  35 */       .visible(() -> ((Boolean)this.render.get()).booleanValue()))
/*  36 */       .build());
/*     */ 
/*     */   
/*  39 */   private final Setting<SettingColor> sideColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  40 */       .name("side-color-solid-block"))
/*  41 */       .description("The color of the sides of the blocks being rendered."))
/*  42 */       .defaultValue(new SettingColor(255, 0, 255, 15))
/*  43 */       .visible(() -> ((Boolean)this.render.get()).booleanValue()))
/*  44 */       .build());
/*     */ 
/*     */   
/*  47 */   private final Setting<SettingColor> lineColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  48 */       .name("line-color-solid-block"))
/*  49 */       .description("The color of the lines of the blocks being rendered."))
/*  50 */       .defaultValue(new SettingColor(255, 0, 255, 255))
/*  51 */       .visible(() -> ((Boolean)this.render.get()).booleanValue()))
/*  52 */       .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Setting<Keybind> cancelBlink2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Setting<Keybind> cancelBlink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Setting<Keybind> cancelBlink1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleClickTp() {
/* 117 */     super(AutoplayAddon.autoplay, "simple-click-tp", "its clicktp");
/*     */     this.cancelBlink2 = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder()).name("Keybind to tp2")).description("Cancels sending packets and sends you back to your original position.")).defaultValue(Keybind.none())).action(() -> {
/*     */             class_4184 camera = this.mc.field_1773.method_19418();
/*     */             class_243 cameraPos = camera.method_19326();
/*     */             float pitch = camera.method_19329();
/*     */             float yaw = camera.method_19330();
/*     */             class_243 rotationVec = class_243.method_1030(pitch, yaw);
/*     */             class_243 raycastEnd = cameraPos.method_1019(rotationVec.method_1021(300.0D));
/*     */             class_2338 blockpos = this.mc.field_1687.method_17742(new class_3959(cameraPos, raycastEnd, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)this.mc.field_1724)).method_17777().method_10084();
/*     */             class_243 pos = new class_243(blockpos.method_10263() + 0.5D, blockpos.method_10264(), blockpos.method_10260() + 0.5D);
/*     */             this.mc.field_1724.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
/*     */           }).build());
/*     */     this.cancelBlink = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder()).name("Keybind to tp")).description("Cancels sending packets and sends you back to your original position.")).defaultValue(Keybind.none())).action(() -> {
/*     */             class_4184 camera = this.mc.field_1773.method_19418();
/*     */             class_243 cameraPos = camera.method_19326();
/*     */             float pitch = camera.method_19329();
/*     */             float yaw = camera.method_19330();
/*     */             class_243 rotationVec = class_243.method_1030(pitch, yaw);
/*     */             class_243 raycastEnd = cameraPos.method_1019(rotationVec.method_1021(300.0D));
/*     */             class_2338 blockpos = this.mc.field_1687.method_17742(new class_3959(cameraPos, raycastEnd, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)this.mc.field_1724)).method_17777().method_10084();
/*     */             class_243 pos = new class_243(blockpos.method_10263() + 0.5D, blockpos.method_10264(), blockpos.method_10260() + 0.5D);
/*     */             ChatUtils.info(" lazyCheck: " + CanTeleport.lazyCheck(this.mc.field_1724.method_19538(), pos) + " slowCheck: " + CanTeleport.oldCheck(this.mc.field_1724.method_19538(), pos), new Object[0]);
/*     */             ChatUtils.info(String.valueOf(System.currentTimeMillis()), new Object[0]);
/*     */           }).build());
/*     */     this.cancelBlink1 = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder()).name("interact test")).description("Cancels sending packets and sends you back to your original position.")).defaultValue(Keybind.none())).action(() -> {
/*     */             class_4184 camera = this.mc.field_1773.method_19418();
/*     */             class_243 cameraPos = camera.method_19326();
/*     */             float pitch = camera.method_19329();
/*     */             float yaw = camera.method_19330();
/*     */             class_243 rotationVec = class_243.method_1030(pitch, yaw);
/*     */             class_243 raycastEnd = cameraPos.method_1019(rotationVec.method_1021(300.0D));
/*     */             class_2338 blockpos = this.mc.field_1687.method_17742(new class_3959(cameraPos, raycastEnd, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)this.mc.field_1724)).method_17777();
/*     */             this.mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5808, new class_3965(blockpos.method_46558(), class_2350.field_11036, blockpos, false), 0));
/*     */           }).build());
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\SimpleClickTp.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */