/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.settings.BlockListSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2626;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ public class BlockUpdateDetector extends Module {
/* 17 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/* 18 */   private final Setting<List<class_2248>> blocks = this.sgGeneral.add((Setting)((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder())
/* 19 */       .name("blocks-to-detect"))
/* 20 */       .description("The blocks you want to detect an update for."))
/* 21 */       .build());
/*    */ 
/*    */ 
/*    */   
/*    */   public BlockUpdateDetector() {
/* 26 */     super(AutoplayAddon.autoplay, "block-update-detector", "Detects when a cauldron gets filled with lava");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onReceivePacket(PacketEvent.Receive event) {
/* 31 */     if (event.packet instanceof class_2626) {
/* 32 */       class_2626 packet = (class_2626)event.packet;
/* 33 */       class_2338 pos = packet.method_11309();
/* 34 */       class_2680 state = packet.method_11308();
/* 35 */       class_2248 block = state.method_26204();
/* 36 */       if (((List)this.blocks.get()).contains(block))
/* 37 */         info("Update:" + pos.method_23854() + " info: " + state, new Object[0]); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\BlockUpdateDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */