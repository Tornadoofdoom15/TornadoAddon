/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2708;
/*    */ 
/*    */ public class ServerTeleportNotifier extends Module {
/*    */   public ServerTeleportNotifier() {
/* 14 */     super(AutoplayAddon.autoplay, "server-teleport-notifier", "Example");
/*    */   }
/*    */   @EventHandler(priority = 202)
/*    */   private static void onRecievePacket(PacketEvent.Receive event) {
/* 18 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2708) { class_2708 packet = (class_2708)class_2596;
/* 19 */       class_2338 roundedPos = new class_2338((int)packet.method_11734(), (int)packet.method_11735(), (int)packet.method_11738());
/* 20 */       ChatUtils.info("Server is trying to teleport you to " + roundedPos.toString(), new Object[0]); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\ServerTeleportNotifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */