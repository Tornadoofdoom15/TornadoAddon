/*    */ package AutoplayAddon.modules;
/*    */ import java.util.HashMap;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*    */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2604;
/*    */ import net.minecraft.class_2684;
/*    */ import net.minecraft.class_2743;
/*    */ import net.minecraft.class_2777;
/*    */ 
/*    */ public class LOTEST extends Module {
/* 18 */   private final Map<Integer, class_243> entityPositions = new HashMap<>();
/*    */   public LOTEST() {
/* 20 */     super(AutoplayAddon.autoplay, "test-module-1", "bypass live overflows movement checks");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onReceivePacket(PacketEvent.Receive event) {
/* 25 */     int EntityId = 0;
/* 26 */     class_243 newPos = class_243.field_1353;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 32 */     if (event.packet instanceof class_2604) {
/* 33 */       class_2604 packet = (class_2604)event.packet;
/* 34 */       EntityId = packet.method_11167();
/* 35 */       newPos = new class_243(packet.method_11175(), packet.method_11174(), packet.method_11176());
/*    */     } 
/* 37 */     if (event.packet instanceof class_2743) {
/* 38 */       class_2743 packet = (class_2743)event.packet;
/* 39 */       EntityId = packet.method_11818();
/* 40 */       class_243 currPos = this.entityPositions.getOrDefault(Integer.valueOf(packet.method_11818()), class_243.field_1353);
/*    */       
/* 42 */       double velocityX = packet.method_11815() / 8000.0D;
/* 43 */       double velocityY = packet.method_11816() / 8000.0D;
/* 44 */       double velocityZ = packet.method_11819() / 8000.0D;
/*    */ 
/*    */       
/* 47 */       ChatUtils.info("Velocity for " + EntityId + " is (" + velocityX + ", " + velocityY + ", " + velocityZ + ")", new Object[0]);
/*    */       
/* 49 */       newPos = currPos.method_1031(velocityX, velocityY, velocityZ);
/*    */     } 
/*    */ 
/*    */     
/* 53 */     if (event.packet instanceof class_2684) {
/* 54 */       class_2684 packet = (class_2684)event.packet;
/*    */       
/* 56 */       class_1297 entity = packet.method_11645((class_1937)this.mc.field_1687);
/*    */       
/* 58 */       if (entity != null) {
/* 59 */         EntityId = entity.method_5628();
/* 60 */         class_243 currPos = this.entityPositions.getOrDefault(Integer.valueOf(EntityId), class_243.field_1353);
/* 61 */         newPos = currPos.method_1031(packet.method_36150(), packet.method_36151(), packet.method_36152());
/*    */       } else {
/* 63 */         ChatUtils.info("Entity is null", new Object[0]);
/*    */       } 
/*    */     } 
/*    */     
/* 67 */     if (event.packet instanceof class_2777) {
/* 68 */       class_2777 packet = (class_2777)event.packet;
/* 69 */       EntityId = packet.method_11916();
/* 70 */       newPos = new class_243(packet.method_11917(), packet.method_11919(), packet.method_11918());
/*    */     } 
/* 72 */     if (newPos != class_243.field_1353 && EntityId != 0) {
/* 73 */       this.entityPositions.put(Integer.valueOf(EntityId), newPos);
/* 74 */       String packetType = event.packet.getClass().getSimpleName();
/* 75 */       ChatUtils.info("New Position for " + EntityId + " is " + this.entityPositions.get(Integer.valueOf(EntityId)) + " from packet " + packetType, new Object[0]);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   private void onRender(Render3DEvent event) {
/* 82 */     for (class_243 position : this.entityPositions.values()) {
/* 83 */       double x1 = position.field_1352 - 0.5D;
/* 84 */       double y1 = position.field_1351;
/* 85 */       double z1 = position.field_1350 - 0.5D;
/* 86 */       double x2 = position.field_1352 + 0.5D;
/* 87 */       double y2 = position.field_1351 + 2.0D;
/* 88 */       double z2 = position.field_1350 + 0.5D;
/* 89 */       event.renderer.box(x1, y1, z1, x2, y2, z2, Color.ORANGE, Color.ORANGE, ShapeMode.Both, 0);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\LOTEST.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */