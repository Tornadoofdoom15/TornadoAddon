/*    */ package AutoplayAddon.modules;
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.DoubleSetting;
/*    */ import meteordevelopment.meteorclient.settings.IntSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2661;
/*    */ import net.minecraft.class_2828;
/*    */ 
/*    */ public class UpFly extends Module {
/*    */   private final SettingGroup sgGeneral;
/*    */   
/*    */   public UpFly() {
/* 23 */     super(AutoplayAddon.autoplay, "up-fly", "bypass live overflows movement checks");
/*    */     
/* 25 */     this.sgGeneral = this.settings.getDefaultGroup();
/*    */     
/* 27 */     this.autoDiscHeight = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/* 28 */         .name("auto-disconnect-below-height"))
/* 29 */         .description("test"))
/* 30 */         .defaultValue(Integer.valueOf(300)))
/* 31 */         .min(0)
/* 32 */         .sliderMax(20000000)
/* 33 */         .build());
/*    */ 
/*    */     
/* 36 */     this.blocks = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder())
/* 37 */         .name("uowards-amount-per-tick"))
/* 38 */         .description("test"))
/* 39 */         .defaultValue(190.0D)
/* 40 */         .min(-200.0D)
/* 41 */         .sliderMax(200.0D)
/* 42 */         .build());
/*    */   }
/*    */   public final Setting<Integer> autoDiscHeight; public final Setting<Double> blocks;
/*    */   @EventHandler(priority = 200)
/*    */   private static void onSendPacket(PacketEvent.Send event) {
/* 47 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2828) { class_2828 packet = (class_2828)class_2596;
/* 48 */       event.cancel(); }
/*    */   
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onTick(TickEvent.Post event) {
/* 54 */     if (this.mc.field_1724.method_23318() < ((Integer)this.autoDiscHeight.get()).intValue()) {
/* 55 */       Module autoReconnect = Modules.get().get(AutoReconnect.class);
/* 56 */       if (autoReconnect.isActive()) autoReconnect.toggle(); 
/* 57 */       this.mc.field_1724.field_3944.method_52781(new class_2661(class_2561.method_30163("Disconnected due to height being below the disconnect height in UpFly.")));
/* 58 */       toggle();
/*    */       return;
/*    */     } 
/* 61 */     class_243 newpos = new class_243(ServerSideValues.serversidedposition.field_1352, ServerSideValues.serversidedposition.field_1351 + ((Double)this.blocks.get()).doubleValue(), ServerSideValues.serversidedposition.field_1350);
/* 62 */     int packetsRequired = (int)Math.ceil(Math.abs(((Double)this.blocks.get()).doubleValue() / 10.0D)) - 1;
/* 63 */     for (int packetNumber = 0; packetNumber < packetsRequired; packetNumber++) {
/* 64 */       PacketUtils.packetQueue.add(new class_2828.class_5911(true));
/*    */     }
/* 66 */     PacketUtils.packetQueue.add(new class_2828.class_2829(newpos.field_1352, newpos.field_1351, newpos.field_1350, true));
/* 67 */     PacketUtils.sendAllPacketsInQueue();
/* 68 */     ServerSideValues.serversidedposition = newpos;
/* 69 */     this.mc.field_1724.method_33574(newpos);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\UpFly.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */