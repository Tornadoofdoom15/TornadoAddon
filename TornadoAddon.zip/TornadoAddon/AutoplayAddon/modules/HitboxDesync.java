/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2374;
/*    */ import net.minecraft.class_238;
/*    */ import net.minecraft.class_2382;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class HitboxDesync extends Module {
/*    */   private static final double MAGIC_OFFSET = 0.20000996883537D;
/*    */   
/*    */   public HitboxDesync() {
/* 18 */     super(AutoplayAddon.autoplay, "HitboxDesync", "Crashes chinese crystal auras.");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onTick(TickEvent.Post event) {
/* 23 */     if (this.mc.field_1687 == null)
/* 24 */       return;  class_2350 f = this.mc.field_1724.method_5735();
/* 25 */     class_238 bb = this.mc.field_1724.method_5829();
/* 26 */     class_243 center = bb.method_1005();
/* 27 */     class_243 offset = new class_243(f.method_23955());
/*    */     
/* 29 */     class_243 fin = merge(class_243.method_24954((class_2382)class_2338.method_49638((class_2374)center)).method_1031(0.5D, 0.0D, 0.5D).method_1019(offset.method_1021(0.20000996883537D)), f);
/* 30 */     this.mc.field_1724.method_5814((fin.field_1352 == 0.0D) ? this.mc.field_1724.method_23317() : fin.field_1352, this.mc.field_1724
/* 31 */         .method_23318(), 
/* 32 */         (fin.field_1350 == 0.0D) ? this.mc.field_1724.method_23321() : fin.field_1350);
/* 33 */     toggle();
/*    */   }
/*    */   
/*    */   private class_243 merge(class_243 a, class_2350 facing) {
/* 37 */     return new class_243(a.field_1352 * Math.abs(facing.method_23955().x()), a.field_1351 * Math.abs(facing.method_23955().y()), a.field_1350 * Math.abs(facing.method_23955().z()));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\HitboxDesync.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */