/*    */ package AutoplayAddon.modules;
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import AutoplayAddon.AutoPlay.Other.Utils;
/*    */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*    */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*    */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*    */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*    */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*    */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*    */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class ClickTp extends Module {
/* 20 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/* 21 */   private final SettingGroup sgRender = this.settings.createGroup("Render"); private final Setting<Boolean> render; private final Setting<ShapeMode> shapeMode;
/*    */   public ClickTp() {
/* 23 */     super(AutoplayAddon.autoplay, "click-tp", "its clicktp");
/*    */ 
/*    */     
/* 26 */     this.render = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 27 */         .name("render"))
/* 28 */         .description("Renders a block overlay where you will be teleported."))
/* 29 */         .defaultValue(Boolean.valueOf(true)))
/* 30 */         .build());
/*    */     
/* 32 */     this.shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/* 33 */         .name("shape-mode"))
/* 34 */         .description("How the shapes are rendered."))
/* 35 */         .defaultValue(ShapeMode.Both))
/* 36 */         .visible(() -> ((Boolean)this.render.get()).booleanValue()))
/* 37 */         .build());
/*    */ 
/*    */     
/* 40 */     this.sideColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/* 41 */         .name("side-color-solid-block"))
/* 42 */         .description("The color of the sides of the blocks being rendered."))
/* 43 */         .defaultValue(new SettingColor(255, 0, 255, 15))
/* 44 */         .visible(() -> ((Boolean)this.render.get()).booleanValue()))
/* 45 */         .build());
/*    */ 
/*    */     
/* 48 */     this.lineColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/* 49 */         .name("line-color-solid-block"))
/* 50 */         .description("The color of the lines of the blocks being rendered."))
/* 51 */         .defaultValue(new SettingColor(255, 0, 255, 255))
/* 52 */         .visible(() -> ((Boolean)this.render.get()).booleanValue()))
/* 53 */         .build());
/*    */ 
/*    */     
/* 56 */     this.clickTP = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/* 57 */         .name("Keybind to tp"))
/* 58 */         .description("Cancels sending packets and sends you back to your original position."))
/* 59 */         .defaultValue(Keybind.none()))
/* 60 */         .action(() -> {
/*    */             class_2338 validPos = Utils.getStaredBlock();
/*    */             
/*    */             if (validPos != null) {
/*    */               class_243 toPos = new class_243(validPos.method_10263() + 0.5D, validPos.method_10264(), validPos.method_10260() + 0.5D);
/*    */               Movement.setPos(toPos, true, Float.valueOf(this.mc.field_1724.method_36455()), Float.valueOf(this.mc.field_1724.method_36454()));
/*    */             } else {
/*    */               ChatUtils.error("No valid position found.", new Object[0]);
/*    */             } 
/* 69 */           }).build());
/*    */   }
/*    */   private final Setting<SettingColor> sideColor; private final Setting<SettingColor> lineColor; private final Setting<Keybind> clickTP;
/*    */   @EventHandler
/*    */   private void onRender(Render3DEvent event) {
/* 74 */     class_2338 validPos = Utils.getStaredBlock();
/* 75 */     if (validPos == null)
/* 76 */       return;  double x1 = validPos.method_10263();
/* 77 */     double y1 = validPos.method_10264();
/* 78 */     double z1 = validPos.method_10260();
/* 79 */     double x2 = x1 + 1.0D;
/* 80 */     double y2 = y1 + 1.0D;
/* 81 */     double z2 = z1 + 1.0D;
/*    */     
/* 83 */     if (((Boolean)this.render.get()).booleanValue())
/* 84 */       event.renderer.box(x1, y1, z1, x2, y2, z2, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0); 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\ClickTp.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */