/*     */ package AutoplayAddon.modules;
/*     */ 
/*     */ import AutoplayAddon.AutoPlay.Mining.MineUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.Render;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2846;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BreakingBlock
/*     */ {
/*     */   public final class_2338 pos;
/*     */   public final class_2680 state;
/*     */   public final int startTick;
/*     */   public final class_2350 direction;
/*     */   
/*     */   public BreakingBlock(class_2338 pos, class_2350 direction) {
/*  99 */     this.pos = pos;
/* 100 */     this.state = (InfiniteMine.access$000(InfiniteMine.this)).field_1687.method_8320(pos);
/* 101 */     this.startTick = ServerSideValues.ticks;
/* 102 */     this.direction = direction;
/*     */   }
/*     */   public boolean startBreaking() {
/* 105 */     InfiniteMine.this.info("start breaking", new Object[0]);
/* 106 */     float f1 = MineUtils.calcBlockBreakingDelta(this.state, this.pos);
/* 107 */     PacketUtils.packetQueue.add(new class_2846(class_2846.class_2847.field_12968, this.pos, this.direction));
/* 108 */     if (f1 >= 1.0F) return true; 
/* 109 */     if (f1 >= 0.7F) {
/* 110 */       PacketUtils.packetQueue.add(new class_2846(class_2846.class_2847.field_12973, this.pos, this.direction));
/* 111 */       return true;
/*     */     } 
/* 113 */     InfiniteMine.this.info("we cant insta break the block", new Object[0]);
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canMine() {
/* 118 */     int l = ServerSideValues.ticks - this.startTick;
/* 119 */     float f = MineUtils.calcBlockBreakingDelta(this.state, this.pos) * (l + 1);
/* 120 */     return (f >= 0.7F);
/*     */   }
/*     */   public void Mine() {
/* 123 */     InfiniteMine.this.info("mining", new Object[0]);
/* 124 */     PacketUtils.packetQueue.add(new class_2846(class_2846.class_2847.field_12973, this.pos, this.direction));
/*     */   }
/*     */   
/*     */   public void render(Render3DEvent event) {
/* 128 */     int l = ServerSideValues.ticks - this.startTick;
/* 129 */     float fast = MineUtils.calcBlockBreakingDelta(this.state, this.pos) * (l + 1);
/* 130 */     Render.renderBlock(event, this.pos, (fast / 0.7F));
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InfiniteMine$BreakingBlock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */