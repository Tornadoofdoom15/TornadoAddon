/*    */ package AutoplayAddon.modules;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.mixininterface.IPlayerMoveC2SPacket;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2828;
/*    */ 
/*    */ public class Disabler extends Module {
/*    */   public Disabler() {
/* 13 */     super(AutoplayAddon.autoplay, "disabler", "Uncaps your server sided allowed player ticks.");
/*    */   }
/*    */   @EventHandler(priority = 202)
/*    */   private void onSendPacket(PacketEvent.Send event) {
/* 17 */     if (event.packet instanceof class_2828) {
/* 18 */       class_2828.class_2830 class_2830; class_2828 packet = (class_2828)event.packet;
/* 19 */       IPlayerMoveC2SPacket iPacket = (IPlayerMoveC2SPacket)event.packet;
/* 20 */       if (iPacket.getTag() == 13377)
/* 21 */         return;  double X = packet.method_12269(this.mc.field_1724.method_23317());
/* 22 */       double Y = packet.method_12268(this.mc.field_1724.method_23318());
/* 23 */       double Z = packet.method_12274(this.mc.field_1724.method_23321());
/* 24 */       float Yaw = packet.method_12271(this.mc.field_1724.method_36454());
/* 25 */       float Pitch = packet.method_12270(this.mc.field_1724.method_36455());
/* 26 */       boolean Ground = packet.method_12273();
/* 27 */       class_2828 newPacket = packet;
/*    */       
/* 29 */       if (packet instanceof class_2828.class_2829) {
/* 30 */         class_2830 = new class_2828.class_2830(X, Y, Z, Yaw, Pitch, Ground);
/*    */       }
/*    */       
/* 33 */       if (packet instanceof class_2828.class_5911) {
/* 34 */         event.cancel();
/*    */         return;
/*    */       } 
/* 37 */       boolean lookignore = false;
/* 38 */       boolean posignore = false;
/* 39 */       if (class_2830.method_36172()) {
/* 40 */         if (Pitch == ServerSideValues.lastPitch && Yaw == ServerSideValues.lastYaw) {
/* 41 */           lookignore = true;
/*    */         }
/*    */       } else {
/* 44 */         lookignore = true;
/*    */       } 
/* 46 */       if (class_2830.method_36171()) {
/* 47 */         if (ServerSideValues.serversidedposition.field_1352 == X && ServerSideValues.serversidedposition.field_1351 == Y && ServerSideValues.serversidedposition.field_1350 == Z) {
/* 48 */           posignore = true;
/*    */         }
/*    */       } else {
/* 51 */         posignore = true;
/*    */       } 
/* 53 */       if (posignore && lookignore) {
/* 54 */         event.cancel();
/*    */         
/*    */         return;
/*    */       } 
/* 58 */       if (class_2830 != packet) {
/* 59 */         ((IPlayerMoveC2SPacket)class_2830).setTag(13377);
/* 60 */         this.mc.field_1724.field_3944.method_52787((class_2596)class_2830);
/* 61 */         event.cancel();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Disabler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */