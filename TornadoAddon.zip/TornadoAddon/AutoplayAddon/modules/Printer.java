/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import fi.dy.masa.litematica.world.WorldSchematic;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.utils.player.FindItemResult;
/*     */ import meteordevelopment.meteorclient.utils.player.InvUtils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1750;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1838;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2487;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_3545;
/*     */ import net.minecraft.class_3965;
/*     */ 
/*     */ public class Printer extends Module {
/*  44 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*  45 */   private final SettingGroup sgRendering = this.settings.createGroup("Rendering");
/*     */   
/*  47 */   public final Setting<Integer> squareddistance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  48 */       .name("squared-distance"))
/*  49 */       .description("test"))
/*  50 */       .defaultValue(Integer.valueOf(35)))
/*  51 */       .min(0)
/*  52 */       .sliderMax(100)
/*  53 */       .build());
/*     */   
/*  55 */   public final Setting<Integer> scandistance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  56 */       .name("block-scan-distance"))
/*  57 */       .description("test"))
/*  58 */       .defaultValue(Integer.valueOf(7)))
/*  59 */       .min(0)
/*  60 */       .sliderMax(100)
/*  61 */       .build());
/*     */ 
/*     */   
/*  64 */   private final Setting<Boolean> returnHand = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  65 */       .name("return-slot"))
/*  66 */       .description("Return to old slot."))
/*  67 */       .defaultValue(Boolean.valueOf(false)))
/*  68 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  72 */   private final Setting<Boolean> dirtgrass = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  73 */       .name("dirt-as-grass"))
/*  74 */       .description("Use dirt instead of grass."))
/*  75 */       .defaultValue(Boolean.valueOf(true)))
/*  76 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  80 */   private final Setting<Boolean> sameproperities = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  81 */       .name("same-properties"))
/*  82 */       .description("Trys to interact with the block to get the properties to match."))
/*  83 */       .defaultValue(Boolean.valueOf(true)))
/*  84 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  88 */   private final Setting<Boolean> renderBlocks = this.sgRendering.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  89 */       .name("render-placed-blocks"))
/*  90 */       .description("Renders block placements."))
/*  91 */       .defaultValue(Boolean.valueOf(true)))
/*  92 */       .build());
/*     */ 
/*     */ 
/*     */   
/*     */   private final Setting<Integer> fadeTime;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Setting<SettingColor> colour;
/*     */ 
/*     */ 
/*     */   
/*     */   private float yaw;
/*     */ 
/*     */   
/*     */   private float pitch;
/*     */ 
/*     */   
/*     */   private int usedSlot;
/*     */ 
/*     */   
/*     */   private final List<class_3545<Integer, class_2338>> placed_fade;
/*     */ 
/*     */ 
/*     */   
/*     */   public Printer() {
/* 118 */     super(AutoplayAddon.autoplay, "fast-litematica-printer", "Automatically prints open schematics"); Objects.requireNonNull(this.renderBlocks); this.fadeTime = this.sgRendering.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("fade-time")).description("Time for the rendering to fade, in ticks.")).defaultValue(Integer.valueOf(3))).min(1).sliderMin(1).max(1000).sliderMax(20).visible(this.renderBlocks::get)).build());
/*     */     Objects.requireNonNull(this.renderBlocks);
/*     */     this.colour = this.sgRendering.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("colour")).description("The cubes colour.")).defaultValue(new SettingColor(95, 190, 255)).visible(this.renderBlocks::get)).build());
/*     */     this.yaw = 0.0F;
/*     */     this.pitch = 0.0F;
/*     */     this.usedSlot = -1;
/* 124 */     this.placed_fade = new ArrayList<>(); } public void onActivate() { this.placed_fade.clear(); }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Post event) {
/* 129 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/* 130 */       this.placed_fade.clear();
/*     */       
/*     */       return;
/*     */     } 
/* 134 */     this.placed_fade.forEach(s -> s.method_34964(Integer.valueOf(((Integer)s.method_15442()).intValue() - 1)));
/* 135 */     this.placed_fade.removeIf(s -> (((Integer)s.method_15442()).intValue() <= 0));
/*     */     
/* 137 */     WorldSchematic worldSchematic = SchematicWorldHandler.getSchematicWorld();
/* 138 */     if (worldSchematic == null) {
/* 139 */       this.placed_fade.clear();
/* 140 */       toggle();
/*     */       return;
/*     */     } 
/* 143 */     class_243 pos = ServerSideValues.serversidedposition;
/* 144 */     class_243 tickeyepos = new class_243(pos.field_1352, pos.field_1351 + this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()), pos.field_1350);
/* 145 */     class_2338 playerPos = this.mc.field_1724.method_24515();
/* 146 */     for (int x = -((Integer)this.scandistance.get()).intValue(); x <= ((Integer)this.scandistance.get()).intValue(); x++) {
/* 147 */       for (int y = -((Integer)this.scandistance.get()).intValue(); y <= ((Integer)this.scandistance.get()).intValue(); y++) {
/* 148 */         for (int z = -((Integer)this.scandistance.get()).intValue(); z <= ((Integer)this.scandistance.get()).intValue(); z++) {
/* 149 */           if (!ServerSideValues.canPlace())
/* 150 */             return;  class_2338 blockPos = playerPos.method_10069(x, y, z);
/*     */           
/* 152 */           class_2680 required = worldSchematic.method_8320(blockPos);
/* 153 */           class_2680 current = this.mc.field_1687.method_8320(blockPos);
/*     */           
/* 155 */           if (!required.method_26215() && !required.method_51176()) {
/* 156 */             if (current.method_26204() == required.method_26204() && current.method_28501() != required.method_28501()) {
/* 157 */               if (((Boolean)this.sameproperities.get()).booleanValue()) {
/* 158 */                 tryUse(blockPos, current, required);
/*     */ 
/*     */               
/*     */               }
/*     */             
/*     */             }
/* 164 */             else if (tickeyepos.method_1025(class_243.method_24953((class_2382)blockPos)) <= ((Integer)this.squareddistance.get()).intValue()) {
/* 165 */               class_1792 item = required.method_26204().method_8389();
/* 166 */               if (((Boolean)this.dirtgrass.get()).booleanValue() && item == class_1802.field_8270)
/* 167 */                 item = class_1802.field_8831; 
/* 168 */               if (switchItem(item, required, () -> Boolean.valueOf(place(blockPos, required))) && (
/* 169 */                 (Boolean)this.renderBlocks.get()).booleanValue()) {
/* 170 */                 this.placed_fade.add(new class_3545(this.fadeTime.get(), new class_2338((class_2382)blockPos)));
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 177 */     AutoplayAddon.playerlookdirecrion = null;
/* 178 */     AutoplayAddon.playerfacingdirecrion = null;
/* 179 */     AutoplayAddon.blockhitdirection = null;
/*     */   }
/*     */   
/*     */   private void tryUse(class_2338 pos, class_2680 currentstate, class_2680 targetstate) {
/* 183 */     class_2680 originalstate = currentstate;
/* 184 */     for (int i = 0; i < 8; i++) {
/* 185 */       currentstate.method_26174((class_1937)this.mc.field_1687, (class_1657)this.mc.field_1724, class_1268.field_5808, new class_3965(pos.method_46558(), class_2350.field_11036, pos, false));
/* 186 */       if (currentstate.method_28501() == targetstate.method_28501()) {
/* 187 */         System.out.println("Matched after " + i + " tries");
/*     */         return;
/*     */       } 
/*     */     } 
/* 191 */     List<class_2350> horizontalDirections = Arrays.asList(new class_2350[] { class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039 });
/* 192 */     for (class_2350 lookDirection : horizontalDirections) {
/* 193 */       ArrayList<class_2350> blockHitDirections = new ArrayList<>(Arrays.asList(new class_2350[] { lookDirection.method_10153(), class_2350.field_11036, class_2350.field_11033 }));
/* 194 */       AutoplayAddon.playerfacingdirecrion = lookDirection;
/* 195 */       AutoplayAddon.playerlookdirecrion = lookDirection;
/* 196 */       for (class_2350 blockHitDirection : blockHitDirections) {
/* 197 */         AutoplayAddon.blockhitdirection = blockHitDirection;
/* 198 */         class_2680 tempState = originalstate;
/* 199 */         int j = 0; if (j < 3) {
/* 200 */           tempState.method_26174((class_1937)this.mc.field_1687, (class_1657)this.mc.field_1724, class_1268.field_5808, new class_3965(pos.method_46558(), blockHitDirection, pos, false));
/* 201 */           if (tempState.method_28501() == targetstate.method_28501()) {
/* 202 */             System.out.println("Matched after " + j + " tries with blockhitdirection");
/*     */             return;
/*     */           } 
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean place(class_2338 pos, class_2680 state) {
/* 214 */     if (!BlockUtils.canPlace(pos) || !state.method_26184((class_4538)this.mc.field_1687, pos)) return false; 
/* 215 */     class_3965 temphitresult = new class_3965(pos.method_46558(), class_2350.field_11033, pos, false);
/* 216 */     class_2248 block = state.method_26204();
/*     */     
/* 218 */     String targetValue = null;
/* 219 */     class_2769<?> targetProperty = null;
/*     */ 
/*     */     
/* 222 */     for (class_2769<?> property : (Iterable<class_2769<?>>)state.method_28501()) {
/* 223 */       String target = state.method_11654(property).toString();
/* 224 */       String propertyname = property.method_11899();
/* 225 */       if (block instanceof net.minecraft.class_2241 && propertyname.equals("shape")) {
/* 226 */         if (Arrays.<String>asList(new String[] { "east_west", "ascending_east", "ascending_west" }).contains(target)) targetValue = "east_west"; 
/* 227 */         if (Arrays.<String>asList(new String[] { "north_south", "ascending_north", "ascending_south" }).contains(target)) targetValue = "north_south"; 
/* 228 */         targetProperty = property;
/*     */         break;
/*     */       } 
/* 231 */       if (Arrays.<String>asList(new String[] { "facing", "half", "type", "axis" }).contains(propertyname)) {
/* 232 */         targetValue = target;
/* 233 */         targetProperty = property;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 238 */     if (targetValue == null) {
/* 239 */       doplace((class_2350)null, (class_2350)null, pos, state);
/* 240 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 244 */     List<class_2350> horizontalDirections = Arrays.asList(new class_2350[] { class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039 });
/*     */ 
/*     */     
/* 247 */     for (class_2350 lookDirection : horizontalDirections) {
/* 248 */       ArrayList<class_2350> blockHitDirections = new ArrayList<>(Arrays.asList(new class_2350[] { lookDirection.method_10153(), class_2350.field_11036, class_2350.field_11033 }));
/* 249 */       AutoplayAddon.playerfacingdirecrion = lookDirection;
/* 250 */       AutoplayAddon.playerlookdirecrion = lookDirection;
/* 251 */       for (class_2350 blockHitDirection : blockHitDirections) {
/* 252 */         AutoplayAddon.blockhitdirection = blockHitDirection;
/* 253 */         class_2680 tempState = block.method_9605(new class_1750(new class_1838((class_1657)this.mc.field_1724, class_1268.field_5808, temphitresult)));
/* 254 */         if (tempState != null && tempState.method_11654(targetProperty).toString() == targetValue) {
/* 255 */           doplace(lookDirection, blockHitDirection, pos, tempState);
/* 256 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 260 */     for (class_2350 generalDirection : class_2350.values()) {
/* 261 */       AutoplayAddon.playerfacingdirecrion = generalDirection;
/* 262 */       AutoplayAddon.playerlookdirecrion = generalDirection;
/* 263 */       AutoplayAddon.blockhitdirection = generalDirection.method_10153();
/* 264 */       class_2680 tempState = block.method_9605(new class_1750(new class_1838((class_1657)this.mc.field_1724, class_1268.field_5808, temphitresult)));
/* 265 */       if (tempState != null && tempState.method_11654(targetProperty).toString() == targetValue) {
/* 266 */         doplace(generalDirection, generalDirection.method_10153(), pos, tempState);
/* 267 */         return true;
/*     */       } 
/*     */     } 
/* 270 */     doplace((class_2350)null, (class_2350)null, pos, state);
/* 271 */     return true;
/*     */   }
/*     */   
/*     */   private void doplace(class_2350 horzonitallook, class_2350 blockHitDirection, class_2338 pos, class_2680 state) {
/* 275 */     AutoplayAddon.playerlookdirecrion = null;
/* 276 */     AutoplayAddon.playerfacingdirecrion = null;
/* 277 */     AutoplayAddon.blockhitdirection = null;
/* 278 */     float targetyaw = this.yaw;
/*     */ 
/*     */     
/* 281 */     float targetpitch = this.pitch;
/* 282 */     if (blockHitDirection != null) {
/* 283 */       if (blockHitDirection == class_2350.field_11033) {
/* 284 */         targetpitch = -90.0F;
/* 285 */       } else if (blockHitDirection == class_2350.field_11036) {
/* 286 */         targetpitch = 90.0F;
/*     */       } else {
/* 288 */         targetpitch = 0.0F;
/*     */       } 
/*     */     }
/*     */     
/* 292 */     if (horzonitallook != null) {
/* 293 */       targetyaw = horzonitallook.method_10144();
/*     */     }
/*     */     
/* 296 */     if (targetpitch != this.pitch || targetyaw != this.yaw) {
/* 297 */       PacketUtils.sendPacket((class_2596)new class_2828.class_2831(targetyaw, targetpitch, this.mc.field_1724.method_24828()));
/* 298 */       System.out.println("targetpitch: " + targetpitch + " targetyaw: " + targetyaw + " pitch: " + this.pitch + " yaw: " + this.yaw);
/* 299 */       this.pitch = targetpitch;
/* 300 */       this.yaw = targetyaw;
/*     */     } 
/* 302 */     System.out.println("horzonitallook: " + horzonitallook + " blockHitDirection: " + blockHitDirection);
/* 303 */     if (blockHitDirection == null) blockHitDirection = class_2350.field_11036; 
/* 304 */     class_3965 hitresult = new class_3965(pos.method_46558(), blockHitDirection, pos, false);
/* 305 */     this.mc.field_1687.method_8501(pos, state);
/* 306 */     PacketUtils.sendPacket((class_2596)new class_2885(class_1268.field_5808, hitresult, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean switchItem(class_1792 item, class_2680 state, Supplier<Boolean> action) {
/* 311 */     int selectedSlot = (this.mc.field_1724.method_31548()).field_7545;
/* 312 */     boolean isCreative = (this.mc.field_1724.method_31549()).field_7477;
/* 313 */     class_1799 requiredItemStack = item.method_7854();
/* 314 */     class_2487 nbt = getNbtFromBlockState(requiredItemStack, state);
/* 315 */     requiredItemStack.method_7980(nbt);
/* 316 */     FindItemResult result = InvUtils.find(new class_1792[] { item });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 321 */     if ((!isCreative && this.mc.field_1724
/*     */       
/* 323 */       .method_6047().method_7909() == item) || (isCreative && this.mc.field_1724
/*     */       
/* 325 */       .method_6047().method_7909() == item && 
/*     */       
/* 327 */       class_1799.method_31577(this.mc.field_1724
/* 328 */         .method_6047(), requiredItemStack))) {
/*     */ 
/*     */ 
/*     */       
/* 332 */       if (((Boolean)action.get()).booleanValue()) {
/* 333 */         this.usedSlot = (this.mc.field_1724.method_31548()).field_7545;
/* 334 */         return true;
/* 335 */       }  return false;
/*     */     } 
/* 337 */     if ((!isCreative && this.usedSlot != -1 && this.mc.field_1724
/*     */ 
/*     */       
/* 340 */       .method_31548().method_5438(this.usedSlot).method_7909() == item) || (isCreative && this.usedSlot != -1 && this.mc.field_1724
/*     */ 
/*     */       
/* 343 */       .method_31548().method_5438(this.usedSlot).method_7909() == item && 
/*     */       
/* 345 */       class_1799.method_31577(this.mc.field_1724
/* 346 */         .method_31548().method_5438(this.usedSlot), requiredItemStack))) {
/*     */ 
/*     */       
/* 349 */       InvUtils.swap(this.usedSlot, ((Boolean)this.returnHand.get()).booleanValue());
/* 350 */       if (((Boolean)action.get()).booleanValue()) {
/* 351 */         return true;
/*     */       }
/* 353 */       InvUtils.swap(selectedSlot, ((Boolean)this.returnHand.get()).booleanValue());
/* 354 */       return false;
/*     */     } 
/*     */     
/* 357 */     if ((result
/* 358 */       .found() && !isCreative) || (result
/*     */       
/* 360 */       .found() && isCreative && result
/*     */       
/* 362 */       .found() && result
/* 363 */       .slot() != -1 && 
/*     */       
/* 365 */       class_1799.method_31577(requiredItemStack, this.mc.field_1724
/*     */         
/* 367 */         .method_31548().method_5438(result.slot())))) {
/*     */ 
/*     */       
/* 370 */       if (result.isHotbar()) {
/* 371 */         InvUtils.swap(result.slot(), ((Boolean)this.returnHand.get()).booleanValue());
/*     */         
/* 373 */         if (((Boolean)action.get()).booleanValue()) {
/* 374 */           this.usedSlot = (this.mc.field_1724.method_31548()).field_7545;
/* 375 */           return true;
/*     */         } 
/* 377 */         InvUtils.swap(selectedSlot, ((Boolean)this.returnHand.get()).booleanValue());
/* 378 */         return false;
/*     */       } 
/*     */       
/* 381 */       if (result.isMain()) {
/* 382 */         FindItemResult empty = InvUtils.findEmpty();
/*     */         
/* 384 */         if (empty.found() && empty.isHotbar()) {
/* 385 */           InvUtils.move().from(result.slot()).toHotbar(empty.slot());
/* 386 */           InvUtils.swap(empty.slot(), ((Boolean)this.returnHand.get()).booleanValue());
/*     */           
/* 388 */           if (((Boolean)action.get()).booleanValue()) {
/* 389 */             this.usedSlot = (this.mc.field_1724.method_31548()).field_7545;
/* 390 */             return true;
/*     */           } 
/* 392 */           InvUtils.swap(selectedSlot, ((Boolean)this.returnHand.get()).booleanValue());
/* 393 */           return false;
/*     */         } 
/*     */         
/* 396 */         if (this.usedSlot != -1) {
/* 397 */           InvUtils.move().from(result.slot()).toHotbar(this.usedSlot);
/* 398 */           InvUtils.swap(this.usedSlot, ((Boolean)this.returnHand.get()).booleanValue());
/*     */           
/* 400 */           if (((Boolean)action.get()).booleanValue()) {
/* 401 */             return true;
/*     */           }
/* 403 */           InvUtils.swap(selectedSlot, ((Boolean)this.returnHand.get()).booleanValue());
/* 404 */           return false;
/*     */         } 
/*     */         
/* 407 */         return false;
/* 408 */       }  return false;
/* 409 */     }  if (isCreative) {
/* 410 */       int slot = 0;
/* 411 */       FindItemResult fir = InvUtils.find(class_1799::method_7960, 0, 8);
/* 412 */       if (fir.found()) {
/* 413 */         slot = fir.slot();
/*     */       }
/* 415 */       this.mc.method_1562().method_52787((class_2596)new class_2873(36 + slot, requiredItemStack));
/* 416 */       InvUtils.swap(slot, ((Boolean)this.returnHand.get()).booleanValue());
/* 417 */       return true;
/* 418 */     }  return false;
/*     */   }
/*     */   
/*     */   static class_2487 getNbtFromBlockState(class_1799 itemStack, class_2680 state) {
/* 422 */     class_2487 nbt = itemStack.method_7948();
/* 423 */     class_2487 subNbt = new class_2487();
/* 424 */     for (class_2769<?> property : (Iterable<class_2769<?>>)state.method_28501()) {
/* 425 */       subNbt.method_10582(property.method_11899(), state.method_11654(property).toString());
/*     */     }
/* 427 */     nbt.method_10566("BlockStateTag", (class_2520)subNbt);
/* 428 */     return nbt;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 433 */     this.placed_fade.forEach(s -> {
/*     */           Color a = new Color(((SettingColor)this.colour.get()).r, ((SettingColor)this.colour.get()).g, ((SettingColor)this.colour.get()).b, (int)(((Integer)s.method_15442()).intValue() / ((Integer)this.fadeTime.get()).intValue() * ((SettingColor)this.colour.get()).a));
/*     */           event.renderer.box((class_2338)s.method_15441(), a, null, ShapeMode.Sides, 0);
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Printer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */