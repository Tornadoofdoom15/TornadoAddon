/*    */ package AutoplayAddon.modules;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.BlockPosSetting;
/*    */ import meteordevelopment.meteorclient.settings.IntSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class LongDistanceTest extends Module {
/* 14 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*    */   
/* 16 */   public final Setting<class_2338> pos = this.sgGeneral.add((Setting)((BlockPosSetting.Builder)((BlockPosSetting.Builder)((BlockPosSetting.Builder)(new BlockPosSetting.Builder())
/* 17 */       .name("Destination"))
/* 18 */       .description("The to position."))
/* 19 */       .defaultValue(class_2338.field_10980))
/* 20 */       .build());
/*    */ 
/*    */   
/* 23 */   private final Setting<Integer> ticksToSkip = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/* 24 */       .name("Ticks to skip"))
/* 25 */       .description("How many ticks to wait betyween each teleport."))
/* 26 */       .defaultValue(Integer.valueOf(0)))
/* 27 */       .min(0)
/* 28 */       .sliderMax(100)
/* 29 */       .build());
/*    */   int tickCounter;
/*    */   
/*    */   public LongDistanceTest() {
/* 33 */     super(AutoplayAddon.autoplay, "long-tp", "Goes to somewhere");
/*    */     
/* 35 */     this.tickCounter = 0;
/*    */   } @EventHandler
/*    */   private void onTick(TickEvent.Post event) {
/* 38 */     double playerY = this.mc.field_1724.method_23318();
/* 39 */     if (playerY != -66.0D || playerY != 322.0D) {
/* 40 */       double targetValue1 = -66.0D;
/* 41 */       double targetValue2 = 322.0D;
/*    */       
/* 43 */       double differenceToValue1 = Math.abs(playerY - targetValue1);
/* 44 */       double differenceToValue2 = Math.abs(playerY - targetValue2);
/*    */       
/* 46 */       if (differenceToValue1 < differenceToValue2) {
/* 47 */         class_243 pos = new class_243(this.mc.field_1724.method_23317(), -66.0D, this.mc.field_1724.method_23321());
/*    */       } else {
/* 49 */         class_243 pos = new class_243(this.mc.field_1724.method_23317(), 322.0D, this.mc.field_1724.method_23321());
/*    */       } 
/*    */       
/*    */       return;
/*    */     } 
/* 54 */     this.tickCounter++;
/* 55 */     if (this.tickCounter < ((Integer)this.ticksToSkip.get()).intValue()) {
/*    */       return;
/*    */     }
/* 58 */     this.tickCounter = 0;
/* 59 */     class_243 playerPos = this.mc.field_1724.method_19538();
/*    */     
/* 61 */     class_243 destination = new class_243(((class_2338)this.pos.get()).method_10263(), ((class_2338)this.pos.get()).method_10264(), ((class_2338)this.pos.get()).method_10260());
/* 62 */     class_243 direction = destination.method_1020(playerPos).method_1029();
/* 63 */     double step = 16.0D;
/*    */     
/* 65 */     class_243 currentPos = playerPos;
/* 66 */     class_2338 lastLoadedPos = null;
/* 67 */     double maxDistance = Math.min(1000.0D, currentPos.method_1022(destination));
/* 68 */     while (currentPos.method_1022(playerPos) < maxDistance) {
/* 69 */       currentPos = currentPos.method_1019(direction.method_1021(step));
/* 70 */       class_2338 blockPos = new class_2338((int)currentPos.field_1352, (int)currentPos.field_1351, (int)currentPos.field_1350);
/* 71 */       assert this.mc.field_1687 != null;
/* 72 */       if (this.mc.field_1687.method_8393(blockPos.method_10263() >> 4, blockPos.method_10260() >> 4)) {
/* 73 */         lastLoadedPos = blockPos;
/*    */       }
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 80 */     if (lastLoadedPos == null) {
/* 81 */       ChatUtils.info("No loaded chunks found in the direction of the destination.", new Object[0]);
/*    */       
/*    */       return;
/*    */     } 
/* 85 */     ChatUtils.info("Teleporting to " + lastLoadedPos.method_10263() + " " + lastLoadedPos.method_10264() + " " + lastLoadedPos.method_10260(), new Object[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\LongDistanceTest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */