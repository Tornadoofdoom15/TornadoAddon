/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Other.AnchorUtils;
/*    */ import AutoplayAddon.AutoPlay.Other.Utils;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Excavator
/*    */   extends Module
/*    */ {
/* 22 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/* 23 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*    */   public Excavator() {
/* 25 */     super(AutoplayAddon.autoplay, "excavator", "boom boom boom boom boom i want to go boom boom lets spend the night together together in my room");
/*    */ 
/*    */     
/* 28 */     this.clickTP = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/* 29 */         .name("Boom Boom"))
/* 30 */         .description("im gonna blowwwwwww"))
/* 31 */         .defaultValue(Keybind.none()))
/* 32 */         .action(() -> {
/*    */             class_2338 validPos = Utils.getStaredBlock();
/*    */             
/*    */             if (validPos != null) {
/*    */               AnchorUtils.blow(validPos, ServerSideValues.serversidedposition);
/*    */               ChatUtils.info("Boom Boom", new Object[0]);
/*    */             } else {
/*    */               ChatUtils.error("No valid position found.", new Object[0]);
/*    */             } 
/* 41 */           }).build());
/*    */   }
/*    */   
/*    */   private final Setting<Keybind> clickTP;
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Excavator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */