/*     */ package AutoplayAddon.modules;
/*     */ 
/*     */ import AutoplayAddon.AutoPlay.Movement.Paths.MulitPath;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.entity.EntityUtils;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_1310;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1743;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1829;
/*     */ import net.minecraft.class_1890;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2868;
/*     */ import net.minecraft.class_8143;
/*     */ 
/*     */ public class DamageLogger extends Module {
/*     */   private final SettingGroup sgGeneral;
/*     */   
/*  34 */   public DamageLogger() { super(AutoplayAddon.autoplay, "damage-logger", "Example");
/*     */ 
/*     */     
/*  37 */     this.sgGeneral = this.settings.getDefaultGroup();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.attackback = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  96 */         .name("attack-back-if-attacked"))
/*  97 */         .description("Do you want to attack back any player that attacks you?"))
/*  98 */         .defaultValue(Boolean.valueOf(true)))
/*  99 */         .build());
/*     */ 
/*     */     
/* 102 */     this.attackbackautoweapon = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 103 */         .name("attack-back-auto-weapon"))
/* 104 */         .description("Do you want to anchor your friends?"))
/* 105 */         .defaultValue(Boolean.valueOf(true)))
/* 106 */         .build());
/*     */ 
/*     */     
/* 109 */     this.weapon = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/* 110 */         .name("weapon"))
/* 111 */         .description("What type of weapon to use."))
/* 112 */         .defaultValue(Weapon.Sword))
/* 113 */         .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     this.threshold = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/* 122 */         .name("threshold"))
/* 123 */         .description("If the non-preferred weapon produces this much damage this will favor it over your preferred weapon."))
/* 124 */         .defaultValue(Integer.valueOf(4)))
/* 125 */         .build());
/*     */ 
/*     */     
/* 128 */     this.antiBreak = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 129 */         .name("anti-break"))
/* 130 */         .description("Prevents you from breaking your weapon."))
/* 131 */         .defaultValue(Boolean.valueOf(false)))
/* 132 */         .build());
/*     */ 
/*     */ 
/*     */     
/* 136 */     this.entities = this.sgGeneral.add((Setting)((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder())
/* 137 */         .name("entities-to-log"))
/* 138 */         .description("Entities that we will log if they take damage."))
/* 139 */         .onlyAttackable()
/* 140 */         .defaultValue(new class_1299[] { class_1299.field_6097
/* 141 */           }).build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     this.logif = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/* 151 */         .name("log-if-damage-type"))
/* 152 */         .description("Logs if the damage is environmental or attack damage."))
/* 153 */         .defaultValue(LogIf.AttackDamage))
/* 154 */         .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     this.logifattacket = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/* 161 */         .name("log-if-attacking-entity"))
/* 162 */         .description("Logs if the attacking entity is a higher threat."))
/* 163 */         .defaultValue(RequiredAttackEntity.Player))
/* 164 */         .visible(() -> (this.logif.get() == LogIf.AttackDamage)))
/* 165 */         .build());
/*     */ 
/*     */ 
/*     */     
/* 169 */     this.logplayersmode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/* 170 */         .name("log-players-mode"))
/* 171 */         .description("What players do you want to log when one gets attacked?"))
/* 172 */         .defaultValue(LogPlayersMode.FriendsAndSelf))
/* 173 */         .build()); } public enum LogIf {
/*     */     Both, EnvironmentalDamage, AttackDamage; } private static final List<String> damageTypes = new ArrayList<>(Arrays.asList(new String[] { 
/*     */           "arrow", "bad respawn point", "cactus", "cramming", "dragon breath", "drowning", "drying out", "explosion", "fall damage", "falling anvil", 
/*     */           "falling block", "falling stalactite", "fireball", "firework", "fly into wall", "freeze", "generic", "generic kill", "hot floor", "in fire", 
/*     */           "in wall", "indirect magic", "lava", "lightning bolt", "magic", "mob attack", "mob attack no aggro", "mob projectile", "on fire", "out of world", 
/*     */           "outside border", "player attack", "player explosion", "sonic boom", "stalagmite", "starve", "sting", "sweet berry bush", "thorns", "thrown", 
/* 179 */           "trident", "unattributed fireball", "wither", "wither skull" })); private final Setting<Boolean> attackback; private final Setting<Boolean> attackbackautoweapon; private final Setting<Weapon> weapon; private final Setting<Integer> threshold; private final Setting<Boolean> antiBreak; @EventHandler private void onReceivePacket(PacketEvent.Receive event) { if (event.packet instanceof class_8143) {
/* 180 */       class_8143 packet = (class_8143)event.packet;
/* 181 */       int source = packet.comp_1269();
/* 182 */       class_1297 cause = this.mc.field_1687.method_8469(source);
/* 183 */       class_1297 target = this.mc.field_1687.method_8469(packet.comp_1267());
/* 184 */       String causeName = (cause != null) ? cause.method_5477().getString() : "Environmental";
/* 185 */       String targetName = (target != null) ? target.method_5477().getString() : "Unknown";
/* 186 */       int attackMethod = packet.comp_1268();
/* 187 */       String attackMethodName = damageTypes.get(attackMethod);
/*     */       
/* 189 */       if (cause == null && source != -1 && target == this.mc.field_1724) {
/* 190 */         ChatUtils.error("Unknown entity hit you!, proabably phillipp, he does that type of thing.", new Object[0]);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 195 */       if (((Boolean)this.attackback.get()).booleanValue() && target == this.mc.field_1724 && cause instanceof class_1657 && cause != this.mc.field_1724) {
/* 196 */         attack(cause);
/*     */       }
/* 198 */       if (shouldLog(target, cause)) {
/*     */         String message;
/* 200 */         if (cause != null) {
/* 201 */           int distance = (int)cause.method_19538().method_1022(target.method_19538());
/* 202 */           if (attackMethodName.equals("player attack")) {
/* 203 */             message = causeName + " attacked " + causeName + " from " + targetName + " blocks away.";
/*     */           } else {
/* 205 */             message = causeName + " attacked " + causeName + " via " + targetName + " from " + attackMethodName + " blocks away.";
/*     */           } 
/*     */         } else {
/* 208 */           message = targetName + " received damage from " + targetName;
/*     */         } 
/*     */         
/* 211 */         ChatUtils.info(message, new Object[0]);
/*     */       } 
/*     */     }  }
/*     */    private final Setting<Set<class_1299<?>>> entities; private final Setting<LogIf> logif; private final Setting<RequiredAttackEntity> logifattacket; private final Setting<LogPlayersMode> logplayersmode; public enum Weapon {
/*     */     Sword, Axe; } public enum LogPlayersMode {
/*     */     All, FriendsAndSelf, Self; } public enum RequiredAttackEntity {
/*     */     Any, Player; } private int getBestWeapon(class_1310 group) {
/* 218 */     int slotS = (this.mc.field_1724.method_31548()).field_7545;
/* 219 */     int slotA = (this.mc.field_1724.method_31548()).field_7545;
/* 220 */     double damageS = 0.0D;
/* 221 */     double damageA = 0.0D;
/*     */ 
/*     */     
/* 224 */     for (int i = 0; i < 9; i++) {
/* 225 */       class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
/* 226 */       class_1792 class_1792 = stack.method_7909(); if (class_1792 instanceof class_1829) { class_1829 swordItem = (class_1829)class_1792;
/* 227 */         if (!((Boolean)this.antiBreak.get()).booleanValue() || stack.method_7936() - stack.method_7919() > 10) {
/* 228 */           double currentDamageS = (swordItem.method_8022().method_8028() + class_1890.method_8218(stack, group) + 2.0F);
/* 229 */           if (currentDamageS > damageS)
/* 230 */           { damageS = currentDamageS;
/* 231 */             slotS = i; }  continue;
/*     */         }  }
/* 233 */        class_1792 = stack.method_7909(); if (class_1792 instanceof class_1743) { class_1743 axeItem = (class_1743)class_1792;
/* 234 */         if (!((Boolean)this.antiBreak.get()).booleanValue() || stack.method_7936() - stack.method_7919() > 10) {
/* 235 */           double currentDamageA = (axeItem.method_8022().method_8028() + class_1890.method_8218(stack, group) + 2.0F);
/* 236 */           if (currentDamageA > damageA) {
/* 237 */             damageA = currentDamageA;
/* 238 */             slotA = i;
/*     */           } 
/*     */         }  }
/*     */        continue;
/* 242 */     }  if (this.weapon.get() == Weapon.Sword && ((Integer)this.threshold.get()).intValue() > damageA - damageS) return slotS; 
/* 243 */     if (this.weapon.get() == Weapon.Axe && ((Integer)this.threshold.get()).intValue() > damageS - damageA) return slotA; 
/* 244 */     if (this.weapon.get() == Weapon.Sword && ((Integer)this.threshold.get()).intValue() < damageA - damageS) return slotA; 
/* 245 */     if (this.weapon.get() == Weapon.Axe && ((Integer)this.threshold.get()).intValue() < damageS - damageA) return slotS; 
/* 246 */     return (this.mc.field_1724.method_31548()).field_7545;
/*     */   }
/*     */ 
/*     */   
/*     */   private void attack(class_1297 entity) {
/* 251 */     List<class_243> list = new ArrayList<>();
/* 252 */     int originalslot = -1;
/* 253 */     PacketUtils.packetQueue.clear();
/* 254 */     if (((Boolean)this.attackbackautoweapon.get()).booleanValue()) {
/* 255 */       originalslot = (this.mc.field_1724.method_31548()).field_7545;
/* 256 */       int optimalSlot = getBestWeapon(EntityUtils.getGroup(entity));
/* 257 */       PacketUtils.packetQueue.add(new class_2868(optimalSlot));
/*     */     } 
/*     */     
/* 260 */     list.add(entity.method_19538().method_1031(0.0D, 0.1D, 0.0D));
/* 261 */     list.add(entity.method_19538());
/* 262 */     list.add(ServerSideValues.serversidedposition);
/* 263 */     MulitPath path = new MulitPath(list);
/* 264 */     if (!path.canExecute().booleanValue()) {
/* 265 */       Disabler disabler = (Disabler)Modules.get().get(Disabler.class);
/* 266 */       if (!disabler.isActive()) {
/* 267 */         ChatUtils.error("Not enough charge. Enable Disabler to build up more.", new Object[0]);
/*     */         return;
/*     */       } 
/* 270 */       ChatUtils.error("Not enough charge.", new Object[0]);
/*     */       
/*     */       return;
/*     */     } 
/* 274 */     path.sendPackets(false);
/* 275 */     path.execute(0);
/* 276 */     path.execute(1, false, null, null);
/* 277 */     PacketUtils.packetQueue.add(class_2824.method_34206(entity, false));
/* 278 */     if (originalslot != -1) PacketUtils.packetQueue.add(new class_2868(originalslot)); 
/* 279 */     path.execute(2);
/* 280 */     PacketUtils.sendAllPacketsInQueue();
/*     */   }
/*     */   
/*     */   private boolean shouldLog(class_1297 target, class_1297 cause) {
/* 284 */     if (target == null || !((Set)this.entities.get()).contains(target.method_5864())) {
/* 285 */       return false;
/*     */     }
/*     */     
/* 288 */     if (this.logif.get() == LogIf.AttackDamage && this.logifattacket.get() == RequiredAttackEntity.Player && !(cause instanceof class_1657)) {
/* 289 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 293 */     switch ((LogPlayersMode)this.logplayersmode.get()) {
/*     */ 
/*     */       
/*     */       case EnvironmentalDamage:
/* 297 */         if (target instanceof class_1657) {
/* 298 */           class_1657 playerTarget = (class_1657)target;
/* 299 */           if (!playerTarget.equals(this.mc.field_1724) && !Friends.get().isFriend(playerTarget)) {
/* 300 */             return false;
/*     */           }
/*     */         } 
/*     */         break;
/*     */       case AttackDamage:
/* 305 */         if (!(target instanceof class_1657) && 
/* 306 */           !target.equals(this.mc.field_1724)) {
/* 307 */           return false;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 313 */     switch ((LogIf)this.logif.get()) {
/*     */       case Both:
/* 315 */         return true;
/*     */       case EnvironmentalDamage:
/* 317 */         return (cause == null);
/*     */       case AttackDamage:
/* 319 */         return (cause != null);
/*     */     } 
/* 321 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\DamageLogger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */