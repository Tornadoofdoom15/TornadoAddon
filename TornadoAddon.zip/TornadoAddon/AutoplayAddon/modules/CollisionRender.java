/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*     */ import AutoplayAddon.AutoPlay.Other.FastBox;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ 
/*     */ public class CollisionRender extends Module {
/*     */   final List<class_2338> blockPosList;
/*  25 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup(); private final Setting<Boolean> renderTrap;
/*     */   public CollisionRender() {
/*  27 */     super(AutoplayAddon.autoplay, "collision-render", "module used for testing");
/*     */     
/*  29 */     this.blockPosList = new ArrayList<>();
/*     */     
/*  31 */     this.renderTrap = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  32 */         .name("render-trap"))
/*  33 */         .description("Renders a block overlay where you will be teleported."))
/*  34 */         .defaultValue(Boolean.valueOf(true)))
/*  35 */         .build());
/*     */ 
/*     */ 
/*     */     
/*  39 */     this.renderPath = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  40 */         .name("render-path"))
/*  41 */         .description("Renders a block overlay where you will be teleported."))
/*  42 */         .defaultValue(Boolean.valueOf(true)))
/*  43 */         .build());
/*     */ 
/*     */ 
/*     */     
/*  47 */     this.cancelBlink = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/*  48 */         .name("Keybind to tp"))
/*  49 */         .description("Cancels sending packets and sends you back to your original position."))
/*  50 */         .defaultValue(Keybind.none()))
/*  51 */         .action(() -> {
/*     */             Movement.fastBoxList.clear();
/*     */             
/*     */             Movement.fastBoxBadList.clear();
/*     */             this.blockPosList.clear();
/*  56 */           }).build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     this.allEntities = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/*  64 */         .name("allentities"))
/*  65 */         .description("Cancels sending packets and sends you back to your original position."))
/*  66 */         .defaultValue(Keybind.none()))
/*  67 */         .action(() -> {
/*     */ 
/*     */             
/*     */             for (class_1297 entity : this.mc.field_1687.method_18112()) {
/*     */               Movement.fastBoxList.add(new FastBox(entity));
/*     */             }
/*  73 */           }).build());
/*     */   }
/*     */   private final Setting<Boolean> renderPath; private final Setting<Keybind> cancelBlink;
/*     */   private final Setting<Keybind> allEntities;
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Post event) {
/*  80 */     if (!((Boolean)this.renderTrap.get()).booleanValue())
/*  81 */       return;  List<class_2338> tempBlocPosList = new ArrayList<>();
/*  82 */     this.blockPosList.clear();
/*     */     
/*  84 */     for (class_1297 entity : this.mc.field_1687.method_18112()) {
/*  85 */       FastBox fastBox = new FastBox(entity);
/*  86 */       List<class_2338> collidedBlocks = fastBox.getOccupiedBlockPos();
/*     */       
/*  88 */       int minX = Integer.MAX_VALUE;
/*  89 */       int maxX = Integer.MIN_VALUE;
/*  90 */       int minY = Integer.MAX_VALUE;
/*  91 */       int maxY = Integer.MIN_VALUE;
/*  92 */       int minZ = Integer.MAX_VALUE;
/*  93 */       int maxZ = Integer.MIN_VALUE;
/*     */       
/*  95 */       for (class_2338 pos : collidedBlocks) {
/*  96 */         minX = Math.min(minX, pos.method_10263());
/*  97 */         maxX = Math.max(maxX, pos.method_10263());
/*  98 */         minY = Math.min(minY, pos.method_10264());
/*  99 */         maxY = Math.max(maxY, pos.method_10264());
/* 100 */         minZ = Math.min(minZ, pos.method_10260());
/* 101 */         maxZ = Math.max(maxZ, pos.method_10260());
/*     */       } 
/*     */       
/* 104 */       for (class_2338 blockPos : collidedBlocks) {
/* 105 */         for (class_2350 dir : class_2350.values()) {
/* 106 */           class_2338 offsetPos = blockPos.method_10093(dir);
/* 107 */           if (!collidedBlocks.contains(offsetPos)) {
/* 108 */             tempBlocPosList.add(offsetPos);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 114 */       for (int x = minX; x <= maxX; x++) {
/* 115 */         for (int z = minZ; z <= maxZ; z++) {
/* 116 */           tempBlocPosList.add(new class_2338(x, minY - 1, z));
/* 117 */           tempBlocPosList.add(new class_2338(x, maxY + 1, z));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 123 */     this.blockPosList.addAll(tempBlocPosList);
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onRender3D(Render3DEvent event) {
/* 129 */     if (((Boolean)this.renderTrap.get()).booleanValue() && !this.blockPosList.isEmpty()) {
/* 130 */       for (class_2338 pos : this.blockPosList) {
/* 131 */         event.renderer.box(pos
/* 132 */             .method_10263(), pos.method_10264(), pos.method_10260(), (pos
/* 133 */             .method_10263() + 1), (pos.method_10264() + 1), (pos.method_10260() + 1), Color.CYAN, Color.BLUE, ShapeMode.Lines, 0);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 138 */     if (((Boolean)this.renderPath.get()).booleanValue())
/*     */       try {
/* 140 */         for (FastBox fastBox : Movement.fastBoxList) {
/* 141 */           if (fastBox.corners == null)
/* 142 */             continue;  for (class_243 corner1 : fastBox.corners) {
/* 143 */             for (class_243 corner2 : fastBox.corners) {
/* 144 */               if (corner1 == null || corner2 == null)
/* 145 */                 continue;  event.renderer.line(corner1.field_1352, corner1.field_1351, corner1.field_1350, corner2.field_1352, corner2.field_1351, corner2.field_1350, Color.ORANGE);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 150 */         for (FastBox fastBox : Movement.fastBoxBadList) {
/* 151 */           for (class_243 corner1 : fastBox.corners) {
/* 152 */             for (class_243 corner2 : fastBox.corners) {
/* 153 */               event.renderer.line(corner1.field_1352, corner1.field_1351, corner1.field_1350, corner2.field_1352, corner2.field_1351, corner2.field_1350, Color.RED);
/*     */             }
/*     */           } 
/*     */         } 
/* 157 */       } catch (Exception exception) {} 
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\CollisionRender.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */