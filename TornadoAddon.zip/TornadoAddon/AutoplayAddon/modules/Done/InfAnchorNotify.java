/*    */ package AutoplayAddon.modules.Done;
/*    */ import AutoplayAddon.AutoPlay.Other.AnchorUtils;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_8143;
/*    */ 
/*    */ public class InfAnchorNotify extends Module {
/*    */   public InfAnchorNotify() {
/* 15 */     super(AutoplayAddon.autoplay, "inf-anchor-notify", "testicle");
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onPacket(PacketEvent.Receive event) {
/* 20 */     if (event.packet instanceof class_8143) {
/* 21 */       class_8143 packet = (class_8143)event.packet;
/* 22 */       int attackMethod = packet.comp_1268();
/* 23 */       class_1297 target = this.mc.field_1687.method_8469(packet.comp_1267());
/* 24 */       if (attackMethod == 1 && target instanceof class_1657 && target != this.mc.field_1724) {
/* 25 */         class_243 damageLocation = packet.comp_1271().get();
/* 26 */         if (AnchorUtils.bedDamage(target.method_19538(), (class_1657)target, damageLocation) == 0.0D)
/* 27 */           ChatUtils.info(target.method_5477().getString() + " used infinite anchor.", new Object[0]); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\InfAnchorNotify.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */