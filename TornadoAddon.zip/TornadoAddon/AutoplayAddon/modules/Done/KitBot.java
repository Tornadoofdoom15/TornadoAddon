/*     */ package AutoplayAddon.modules.Done;
/*     */ import AutoplayAddon.AutoPlay.Other.BotUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.Villagerutils;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.stream.StreamSupport;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1893;
/*     */ import net.minecraft.class_1914;
/*     */ import net.minecraft.class_1916;
/*     */ import net.minecraft.class_2824;
/*     */ 
/*     */ public class KitBot extends Module {
/*     */   private final SettingGroup sgGeneral;
/*     */   private Queue<class_1297> villagers_to_interact;
/*     */   private Queue<class_1297> villagers_interacted_with_unknown_trades;
/*     */   
/*     */   public KitBot() {
/*  32 */     super(AutoplayAddon.autoplay, "kit-bot", "cock and ball torture");
/*     */ 
/*     */     
/*  35 */     this.sgGeneral = this.settings.getDefaultGroup();
/*  36 */     this.villagers_to_interact = new LinkedList<>();
/*  37 */     this.villagers_interacted_with_unknown_trades = new LinkedList<>();
/*  38 */     this.villagerTrades = new HashMap<>();
/*  39 */     this.indexbutton = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/*  40 */         .name("index"))
/*  41 */         .description("Indexes villagers for later use."))
/*  42 */         .defaultValue(Keybind.none()))
/*  43 */         .action(() -> {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (this.mc.field_1687 != null) {
/*     */               StreamSupport.stream(this.mc.field_1687.method_18112().spliterator(), false).filter(()).forEach(());
/*     */             }
/*  53 */           }).build());
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.testbutton = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/*  58 */         .name("test"))
/*  59 */         .description("lists every trade for every villager"))
/*  60 */         .defaultValue(Keybind.none()))
/*  61 */         .action(() -> {
/*     */             for (Map.Entry<class_1297, class_1916> entry : this.villagerTrades.entrySet()) {
/*     */               class_1297 villager = entry.getKey();
/*     */               
/*     */               class_1916 offers = entry.getValue();
/*     */               for (class_1914 offer : offers) {
/*     */                 class_1799 sellItem = offer.method_8250();
/*     */                 String sellItemDetails = Villagerutils.getDetailedItemDescription(sellItem);
/*     */                 String priceDetails = Villagerutils.getPriceDescription(offer);
/*     */                 System.out.println("Villager ID: " + villager.method_5628() + ", Selling: " + sellItemDetails + ", Price: " + priceDetails);
/*     */               } 
/*     */             } 
/*  73 */           }).build());
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.buyProtectionBookButton = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/*  78 */         .name("buy-protection-book"))
/*  79 */         .description("Buys a Protection book from a villager."))
/*  80 */         .defaultValue(Keybind.none()))
/*  81 */         .action(() -> {
/*     */             Villagerutils.buyItem(Villagerutils.createBookItemStack(class_1893.field_9127, 3), this.villagerTrades);
/*     */             
/*     */             Villagerutils.buyItem(Villagerutils.createBookItemStack(class_1893.field_9116, 1), this.villagerTrades);
/*     */             PacketUtils.sendAllPacketsInQueue();
/*  86 */           }).build());
/*     */   }
/*     */   private Map<class_1297, class_1916> villagerTrades; private final Setting<Keybind> indexbutton; private final Setting<Keybind> testbutton; private final Setting<Keybind> buyProtectionBookButton;
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*  92 */     PacketUtils.packetQueue.clear();
/*  93 */     while (!this.villagers_to_interact.isEmpty() && ServerSideValues.canPlace()) {
/*  94 */       class_1297 villager = this.villagers_to_interact.poll();
/*  95 */       if (villager == null || !ServerSideValues.canPlace()) {
/*  96 */         PacketUtils.sendAllPacketsInQueue();
/*     */         return;
/*     */       } 
/*  99 */       BotUtils.setPos(villager.method_19538());
/* 100 */       PacketUtils.packetQueue.add(class_2824.method_34207(villager, false, class_1268.field_5808));
/* 101 */       ServerSideValues.handleUse();
/* 102 */       ServerSideValues.lastScreenSyncId++;
/* 103 */       PacketUtils.packetQueue.add(new class_2815(ServerSideValues.lastScreenSyncId));
/* 104 */       this.villagers_interacted_with_unknown_trades.offer(villager);
/*     */     } 
/* 106 */     PacketUtils.sendAllPacketsInQueue();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onReceivePacket(PacketEvent.Receive event) {
/* 111 */     if (event.packet instanceof class_3943) {
/* 112 */       class_1297 villager = this.villagers_interacted_with_unknown_trades.poll();
/* 113 */       if (villager != null) {
/* 114 */         class_1916 offers = ((class_3943)event.packet).method_17590();
/* 115 */         this.villagerTrades.put(villager, offers);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\KitBot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */