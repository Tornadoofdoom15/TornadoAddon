/*    */ package AutoplayAddon.modules.Done;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.UUID;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.settings.StringListSetting;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2703;
/*    */ import net.minecraft.class_7828;
/*    */ 
/*    */ public class JoinLeaveNotify extends Module {
/*    */   private final SettingGroup sgGeneral;
/*    */   
/*    */   public JoinLeaveNotify() {
/* 22 */     super(AutoplayAddon.autoplay, "join-leave-notify", "testicle");
/*    */     
/* 24 */     this.sgGeneral = this.settings.getDefaultGroup();
/* 25 */     this.players = this.sgGeneral.add((Setting)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder())
/* 26 */         .name("player-name-contains-ignore"))
/* 27 */         .description("Players to target."))
/* 28 */         .defaultValue(List.of("N00bBot")))
/* 29 */         .build());
/*    */   }
/*    */   private final Setting<List<String>> players;
/*    */   @EventHandler
/*    */   private void onReceivePacket(PacketEvent.Receive event) {
/* 34 */     if (event.packet instanceof class_2703) {
/* 35 */       class_2703 packet = (class_2703)event.packet;
/* 36 */       for (class_2703.class_2705 playerEntry : packet.method_46329()) {
/* 37 */         GameProfile player = playerEntry.comp_1107();
/*    */         
/* 39 */         String playerName = player.getName();
/* 40 */         Objects.requireNonNull(playerName); if (player == null || ((List)this.players.get()).stream().anyMatch(playerName::contains))
/* 41 */           continue;  this.mc.field_1705.method_1743().method_1812((class_2561)class_2561.method_43470("§e" + playerName + " joined the game."));
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 46 */     if (event.packet instanceof class_7828) {
/* 47 */       class_7828 packet = (class_7828)event.packet;
/* 48 */       for (UUID id : packet.comp_1105()) {
/* 49 */         GameProfile profile = this.mc.method_1562().method_2871(id).method_2966();
/* 50 */         if (profile != null) {
/* 51 */           String playerName = profile.getName();
/* 52 */           Objects.requireNonNull(playerName); if (playerName != null && ((List)this.players.get()).stream().anyMatch(playerName::contains))
/* 53 */             continue;  this.mc.field_1705.method_1743().method_1812((class_2561)class_2561.method_43470("§e" + playerName + " left the game."));
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\JoinLeaveNotify.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */