package AutoplayAddon.modules.Done;

import com.google.common.reflect.TypeToken;
import java.util.List;

class null extends TypeToken<List<StashFinder.Chunk>> {}


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\StashFinder$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */