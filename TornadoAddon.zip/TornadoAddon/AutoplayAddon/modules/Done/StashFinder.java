/*     */ package AutoplayAddon.modules.Done;
/*     */ import AutoplayAddon.modules.SimpcraftNetherTravel;
/*     */ import com.google.common.reflect.TypeToken;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
/*     */ import meteordevelopment.meteorclient.gui.GuiTheme;
/*     */ import meteordevelopment.meteorclient.gui.widgets.WWidget;
/*     */ import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
/*     */ import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
/*     */ import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
/*     */ import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
/*     */ import meteordevelopment.meteorclient.settings.BlockListSetting;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
/*     */ import meteordevelopment.meteorclient.systems.modules.Modules;
/*     */ import meteordevelopment.meteorclient.utils.Utils;
/*     */ import meteordevelopment.meteorclient.utils.render.MeteorToast;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2586;
/*     */ import net.minecraft.class_2591;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_368;
/*     */ import net.minecraft.class_437;
/*     */ 
/*     */ public class StashFinder extends Module {
/*  41 */   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
/*     */   
/*  43 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*     */   
/*  45 */   private final Setting<List<class_2591<?>>> storageBlocks = this.sgGeneral.add((Setting)((StorageBlockListSetting.Builder)((StorageBlockListSetting.Builder)(new StorageBlockListSetting.Builder())
/*  46 */       .name("storage-blocks"))
/*  47 */       .description("Select the storage blocks to search for."))
/*  48 */       .defaultValue(StorageBlockListSetting.STORAGE_BLOCKS)
/*  49 */       .build());
/*     */ 
/*     */   
/*  52 */   private final Setting<List<class_2248>> regularBlocks = this.sgGeneral.add((Setting)((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder())
/*  53 */       .name("regular-blocks"))
/*  54 */       .description("Select the regular blocks to search for."))
/*  55 */       .build());
/*     */ 
/*     */   
/*  58 */   private final Setting<Integer> otherCount = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  59 */       .name("other-count"))
/*  60 */       .description("The minimum amount of storage blocks in a chunk to record the chunk."))
/*  61 */       .defaultValue(Integer.valueOf(4)))
/*  62 */       .min(1)
/*  63 */       .sliderMin(1)
/*  64 */       .build());
/*     */ 
/*     */   
/*  67 */   private final Setting<Integer> chestCount = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  68 */       .name("chest-count"))
/*  69 */       .description("The minimum amount of storage blocks in a chunk to record the chunk."))
/*  70 */       .defaultValue(Integer.valueOf(4)))
/*  71 */       .min(1)
/*  72 */       .sliderMin(1)
/*  73 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  77 */   private final Setting<Integer> shulkerCount = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  78 */       .name("shulker-count"))
/*  79 */       .description("The minimum amount of storage blocks in a chunk to record the chunk."))
/*  80 */       .defaultValue(Integer.valueOf(4)))
/*  81 */       .min(1)
/*  82 */       .sliderMin(1)
/*  83 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  87 */   private final Setting<Integer> minimumDistance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  88 */       .name("minimum-distance"))
/*  89 */       .description("The minimum distance you must be from spawn to record a certain chunk."))
/*  90 */       .defaultValue(Integer.valueOf(0)))
/*  91 */       .min(0)
/*  92 */       .sliderMax(10000)
/*  93 */       .build());
/*     */ 
/*     */   
/*  96 */   private final Setting<Boolean> sendNotifications = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  97 */       .name("notifications"))
/*  98 */       .description("Sends Minecraft notifications when new stashes are found."))
/*  99 */       .defaultValue(Boolean.valueOf(true)))
/* 100 */       .build());
/*     */ 
/*     */ 
/*     */   
/*     */   private final Setting<Mode> notificationMode;
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Chunk> chunks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StashFinder() {
/* 114 */     super(AutoplayAddon.autoplay, "stash-finder-plus", "stash finder but also for regular blocks");
/*     */     Objects.requireNonNull(this.sendNotifications);
/*     */     this.notificationMode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("notification-mode")).description("The mode to use for notifications.")).defaultValue(Mode.Both)).visible(this.sendNotifications::get)).build());
/*     */     this.chunks = new ArrayList<>();
/*     */   } public void onActivate() {
/* 119 */     load();
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onChunkData(ChunkDataEvent event) {
/* 125 */     double chunkXAbs = Math.abs((event.chunk.method_12004()).field_9181 * 16);
/* 126 */     double chunkZAbs = Math.abs((event.chunk.method_12004()).field_9180 * 16);
/* 127 */     if (Math.sqrt(chunkXAbs * chunkXAbs + chunkZAbs * chunkZAbs) < ((Integer)this.minimumDistance.get()).intValue())
/*     */       return; 
/* 129 */     Chunk chunk = new Chunk(event.chunk.method_12004());
/* 130 */     for (class_2586 blockEntity : event.chunk.method_12214().values()) {
/* 131 */       if (!((List)this.storageBlocks.get()).contains(blockEntity.method_11017()))
/*     */         continue; 
/* 133 */       if (blockEntity instanceof net.minecraft.class_2595) { chunk.chests++; continue; }
/* 134 */        if (blockEntity instanceof net.minecraft.class_3719) { chunk.barrels++; continue; }
/* 135 */        if (blockEntity instanceof net.minecraft.class_2627) { chunk.shulkers++; continue; }
/* 136 */        if (blockEntity instanceof net.minecraft.class_2611) { chunk.enderChests++; continue; }
/* 137 */        if (blockEntity instanceof net.minecraft.class_2609) { chunk.furnaces++; continue; }
/* 138 */        if (blockEntity instanceof net.minecraft.class_2601) { chunk.dispensersDroppers++; continue; }
/* 139 */        if (blockEntity instanceof net.minecraft.class_2614) chunk.hoppers++;
/*     */     
/*     */     } 
/* 142 */     if (!((List)this.regularBlocks.get()).isEmpty()) {
/* 143 */       for (class_2826 section : event.chunk.method_12006()) {
/* 144 */         for (int x = 0; x < 15; x++) {
/* 145 */           for (int y = 0; y < 15; y++) {
/* 146 */             for (int z = 0; z < 15; z++) {
/* 147 */               class_2248 block = section.method_12254(x, y, z).method_26204();
/* 148 */               if (((List)this.regularBlocks.get()).contains(block)) chunk.regular++;
/*     */             
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 155 */     if (chunk.chests + chunk.barrels >= ((Integer)this.chestCount.get()).intValue()) notify(chunk, "chests"); 
/* 156 */     if (chunk.shulkers >= ((Integer)this.shulkerCount.get()).intValue()) notify(chunk, "shulker"); 
/* 157 */     if (chunk.regular >= ((Integer)this.otherCount.get()).intValue()) notify(chunk, "other");
/*     */     
/* 159 */     ChunkDataEvent.returnChunkDataEvent(event);
/*     */   }
/*     */   
/*     */   private void notify(Chunk chunk, String type) {
/* 163 */     Chunk prevChunk = null;
/* 164 */     int i = this.chunks.indexOf(chunk);
/*     */     
/* 166 */     if (i < 0) { this.chunks.add(chunk); }
/* 167 */     else { prevChunk = this.chunks.set(i, chunk); }
/*     */     
/* 169 */     saveJson();
/* 170 */     saveCsv();
/*     */     
/* 172 */     if (((Boolean)this.sendNotifications.get()).booleanValue() && (!chunk.equals(prevChunk) || !chunk.countsEqual(prevChunk))) {
/* 173 */       switch ((Mode)this.notificationMode.get()) { case Chat:
/* 174 */           info("Found stash with (highlight)%s(default) at (highlight)%s(default), (highlight)%s(default).", new Object[] { type, Integer.valueOf(chunk.x), Integer.valueOf(chunk.z) }); break;
/* 175 */         case Toast: this.mc.method_1566().method_1999((class_368)new MeteorToast(class_1802.field_8106, this.title, "Found Stash!")); break;
/*     */         case Both:
/* 177 */           info("Found stash at (highlight)%s(default), (highlight)%s(default).", new Object[] { Integer.valueOf(chunk.x), Integer.valueOf(chunk.z) });
/* 178 */           this.mc.method_1566().method_1999((class_368)new MeteorToast(class_1802.field_8106, this.title, "Found Stash!"));
/*     */           break; }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WWidget getWidget(GuiTheme theme) {
/* 188 */     this.chunks.sort(Comparator.comparingInt(value -> -value.getTotal()));
/*     */     
/* 190 */     WVerticalList list = theme.verticalList();
/*     */ 
/*     */     
/* 193 */     WButton clear = (WButton)list.add((WWidget)theme.button("Clear")).widget();
/*     */     
/* 195 */     WTable table = new WTable();
/* 196 */     if (this.chunks.size() > 0) list.add((WWidget)table);
/*     */     
/* 198 */     clear.action = (() -> {
/*     */         this.chunks.clear();
/*     */         
/*     */         table.clear();
/*     */       });
/*     */     
/* 204 */     fillTable(theme, table);
/*     */     
/* 206 */     return (WWidget)list;
/*     */   }
/*     */   
/*     */   private void fillTable(GuiTheme theme, WTable table) {
/* 210 */     for (Iterator<Chunk> iterator = this.chunks.iterator(); iterator.hasNext(); ) { Chunk chunk = iterator.next();
/* 211 */       table.add((WWidget)theme.label("Pos: " + chunk.x + ", " + chunk.z));
/* 212 */       table.add((WWidget)theme.label("Total: " + chunk.getTotal()));
/*     */       
/* 214 */       WButton open = (WButton)table.add((WWidget)theme.button("Open")).widget();
/* 215 */       open.action = (() -> this.mc.method_1507((class_437)new ChunkScreen(theme, chunk)));
/* 216 */       SimpcraftNetherTravel netherTravel = (SimpcraftNetherTravel)Modules.get().get(SimpcraftNetherTravel.class);
/*     */       
/* 218 */       WButton nethertravel = (WButton)table.add((WWidget)theme.button("NetherTravel")).widget();
/* 219 */       nethertravel.action = (() -> nethertravelto(chunk));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       WMinus delete = (WMinus)table.add((WWidget)theme.minus()).widget();
/* 226 */       delete.action = (() -> {
/*     */           if (this.chunks.remove(chunk)) {
/*     */             table.clear();
/*     */             
/*     */             fillTable(theme, table);
/*     */             
/*     */             saveJson();
/*     */             saveCsv();
/*     */           } 
/*     */         });
/* 236 */       table.row(); }
/*     */   
/*     */   }
/*     */   
/*     */   private void nethertravelto(Chunk chunk) {
/* 241 */     SimpcraftNetherTravel netherTravel = (SimpcraftNetherTravel)Modules.get().get(SimpcraftNetherTravel.class);
/* 242 */     netherTravel.pos.set(new class_2338(chunk.x, 0, chunk.z));
/* 243 */     if (!netherTravel.isActive()) netherTravel.toggle(); 
/*     */   }
/*     */   
/*     */   private void load() {
/* 247 */     boolean loaded = false;
/*     */ 
/*     */     
/* 250 */     File file = getJsonFile();
/* 251 */     if (file.exists()) {
/*     */       try {
/* 253 */         FileReader reader = new FileReader(file);
/* 254 */         this.chunks = (List<Chunk>)GSON.fromJson(reader, (new TypeToken<List<Chunk>>() {  }).getType());
/* 255 */         reader.close();
/*     */         
/* 257 */         for (Chunk chunk : this.chunks) chunk.calculatePos();
/*     */         
/* 259 */         loaded = true;
/* 260 */       } catch (Exception ignored) {
/* 261 */         if (this.chunks == null) this.chunks = new ArrayList<>();
/*     */       
/*     */       } 
/*     */     }
/*     */     
/* 266 */     file = getCsvFile();
/* 267 */     if (!loaded && file.exists())
/*     */       try {
/* 269 */         BufferedReader reader = new BufferedReader(new FileReader(file));
/* 270 */         reader.readLine();
/*     */         
/*     */         String line;
/* 273 */         while ((line = reader.readLine()) != null) {
/* 274 */           String[] values = line.split(" ");
/* 275 */           Chunk chunk = new Chunk(new class_1923(Integer.parseInt(values[0]), Integer.parseInt(values[1])));
/*     */           
/* 277 */           chunk.chests = Integer.parseInt(values[2]);
/* 278 */           chunk.shulkers = Integer.parseInt(values[3]);
/* 279 */           chunk.enderChests = Integer.parseInt(values[4]);
/* 280 */           chunk.furnaces = Integer.parseInt(values[5]);
/* 281 */           chunk.dispensersDroppers = Integer.parseInt(values[6]);
/* 282 */           chunk.hoppers = Integer.parseInt(values[7]);
/*     */           
/* 284 */           this.chunks.add(chunk);
/*     */         } 
/*     */         
/* 287 */         reader.close();
/* 288 */       } catch (Exception ignored) {
/* 289 */         if (this.chunks == null) this.chunks = new ArrayList<>();
/*     */       
/*     */       }  
/*     */   }
/*     */   
/*     */   private void saveCsv() {
/*     */     try {
/* 296 */       File file = getCsvFile();
/* 297 */       file.getParentFile().mkdirs();
/* 298 */       Writer writer = new FileWriter(file);
/*     */       
/* 300 */       writer.write("X,Z,Chests,Barrels,Shulkers,EnderChests,Furnaces,DispensersDroppers,Hoppers\n");
/* 301 */       for (Chunk chunk : this.chunks) chunk.write(writer);
/*     */       
/* 303 */       writer.close();
/* 304 */     } catch (IOException e) {
/* 305 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void saveJson() {
/*     */     try {
/* 311 */       File file = getJsonFile();
/* 312 */       file.getParentFile().mkdirs();
/* 313 */       Writer writer = new FileWriter(file);
/* 314 */       GSON.toJson(this.chunks, writer);
/* 315 */       writer.close();
/* 316 */     } catch (IOException e) {
/* 317 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private File getJsonFile() {
/* 322 */     return new File(new File(new File(MeteorClient.FOLDER, "stashes"), Utils.getWorldName()), "stashes.json");
/*     */   }
/*     */   
/*     */   private File getCsvFile() {
/* 326 */     return new File(new File(new File(MeteorClient.FOLDER, "stashes"), Utils.getWorldName()), "stashes.csv");
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 330 */     Chat,
/* 331 */     Toast,
/* 332 */     Both;
/*     */   }
/*     */   
/*     */   public static class Chunk {
/* 336 */     private static final StringBuilder sb = new StringBuilder(); public final class_1923 chunkPos; public transient int x; public transient int z; public int chests; public int barrels; public int shulkers; public int enderChests;
/*     */     public int furnaces;
/*     */     public int dispensersDroppers;
/*     */     public int hoppers;
/*     */     public int regular;
/*     */     
/*     */     public Chunk(class_1923 chunkPos) {
/* 343 */       this.chunkPos = chunkPos;
/*     */       
/* 345 */       calculatePos();
/*     */     }
/*     */     
/*     */     public void calculatePos() {
/* 349 */       this.x = this.chunkPos.field_9181 * 16 + 8;
/* 350 */       this.z = this.chunkPos.field_9180 * 16 + 8;
/*     */     }
/*     */     public int getOther() {
/* 353 */       return this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers + this.regular;
/*     */     }
/*     */     public int getTotal() {
/* 356 */       return this.chests + this.barrels + this.shulkers + this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers + this.regular;
/*     */     }
/*     */     
/*     */     public void write(Writer writer) throws IOException {
/* 360 */       sb.setLength(0);
/* 361 */       sb.append(this.x).append(',').append(this.z).append(',');
/* 362 */       sb.append(this.chests).append(',').append(this.barrels).append(',').append(this.shulkers).append(',').append(this.enderChests).append(',').append(this.furnaces).append(',').append(this.dispensersDroppers).append(',').append(this.hoppers).append('\n');
/* 363 */       writer.write(sb.toString());
/*     */     }
/*     */     
/*     */     public boolean countsEqual(Chunk c) {
/* 367 */       if (c == null) return false; 
/* 368 */       return (this.chests != c.chests || this.barrels != c.barrels || this.shulkers != c.shulkers || this.enderChests != c.enderChests || this.furnaces != c.furnaces || this.dispensersDroppers != c.dispensersDroppers || this.hoppers != c.hoppers);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 373 */       if (this == o) return true; 
/* 374 */       if (o == null || getClass() != o.getClass()) return false; 
/* 375 */       Chunk chunk = (Chunk)o;
/* 376 */       return Objects.equals(this.chunkPos, chunk.chunkPos);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 381 */       return Objects.hash(new Object[] { this.chunkPos });
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ChunkScreen extends WindowScreen {
/*     */     private final StashFinder.Chunk chunk;
/*     */     
/*     */     public ChunkScreen(GuiTheme theme, StashFinder.Chunk chunk) {
/* 389 */       super(theme, "Chunk at " + chunk.x + ", " + chunk.z);
/*     */       
/* 391 */       this.chunk = chunk;
/*     */     }
/*     */ 
/*     */     
/*     */     public void initWidgets() {
/* 396 */       WTable t = (WTable)add((WWidget)this.theme.table()).expandX().widget();
/*     */ 
/*     */       
/* 399 */       t.add((WWidget)this.theme.label("Total:"));
/* 400 */       t.add((WWidget)this.theme.label("" + this.chunk.getTotal()));
/* 401 */       t.row();
/*     */       
/* 403 */       t.add((WWidget)this.theme.horizontalSeparator()).expandX();
/* 404 */       t.row();
/*     */ 
/*     */       
/* 407 */       t.add((WWidget)this.theme.label("Chests:"));
/* 408 */       t.add((WWidget)this.theme.label("" + this.chunk.chests));
/* 409 */       t.row();
/*     */       
/* 411 */       t.add((WWidget)this.theme.label("Barrels:"));
/* 412 */       t.add((WWidget)this.theme.label("" + this.chunk.barrels));
/* 413 */       t.row();
/*     */       
/* 415 */       t.add((WWidget)this.theme.label("Shulkers:"));
/* 416 */       t.add((WWidget)this.theme.label("" + this.chunk.shulkers));
/* 417 */       t.row();
/*     */       
/* 419 */       t.add((WWidget)this.theme.label("Ender Chests:"));
/* 420 */       t.add((WWidget)this.theme.label("" + this.chunk.enderChests));
/* 421 */       t.row();
/*     */       
/* 423 */       t.add((WWidget)this.theme.label("Furnaces:"));
/* 424 */       t.add((WWidget)this.theme.label("" + this.chunk.furnaces));
/* 425 */       t.row();
/*     */       
/* 427 */       t.add((WWidget)this.theme.label("Dispensers and droppers:"));
/* 428 */       t.add((WWidget)this.theme.label("" + this.chunk.dispensersDroppers));
/* 429 */       t.row();
/*     */       
/* 431 */       t.add((WWidget)this.theme.label("Hoppers:"));
/* 432 */       t.add((WWidget)this.theme.label("" + this.chunk.hoppers));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\StashFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */