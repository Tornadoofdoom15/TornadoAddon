/*    */ package AutoplayAddon.modules.Done;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.BlockPosSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ public class BackAndForth
/*    */   extends Module {
/*    */   private final SettingGroup sgGeneral;
/*    */   public final Setting<class_2338> pos1;
/*    */   public final Setting<class_2338> pos2;
/*    */   public boolean bool;
/*    */   
/*    */   public BackAndForth() {
/* 21 */     super(AutoplayAddon.autoplay, "back-and-forth", "testicle");
/*    */     
/* 23 */     this.sgGeneral = this.settings.getDefaultGroup();
/* 24 */     this.pos1 = this.sgGeneral.add((Setting)((BlockPosSetting.Builder)((BlockPosSetting.Builder)(new BlockPosSetting.Builder())
/* 25 */         .name("pos1"))
/* 26 */         .defaultValue(class_2338.field_10980))
/* 27 */         .build());
/*    */ 
/*    */     
/* 30 */     this.pos2 = this.sgGeneral.add((Setting)((BlockPosSetting.Builder)((BlockPosSetting.Builder)(new BlockPosSetting.Builder())
/* 31 */         .name("pos2"))
/* 32 */         .defaultValue(class_2338.field_10980))
/* 33 */         .build());
/*    */     
/* 35 */     this.bool = false;
/*    */   } @EventHandler
/*    */   private void onTick(TickEvent.Pre event) {
/* 38 */     if (this.bool) {
/* 39 */       Movement.setPos(((class_2338)this.pos1.get()).method_46558(), true, null, null);
/* 40 */       this.bool = false;
/*    */     } else {
/* 42 */       Movement.setPos(((class_2338)this.pos2.get()).method_46558(), true, null, null);
/* 43 */       this.bool = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\BackAndForth.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */