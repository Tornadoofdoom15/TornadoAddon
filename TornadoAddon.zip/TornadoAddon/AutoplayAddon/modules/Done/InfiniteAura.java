/*    */ package AutoplayAddon.modules.Done;
/*    */ import AutoplayAddon.AutoPlay.Movement.Paths.MulitPath;
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.AutoPlay.Other.TargetUtils;
/*    */ import AutoplayAddon.modules.Disabler;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*    */ import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
/*    */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*    */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.settings.StringListSetting;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class InfiniteAura extends Module {
/* 22 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup(); private final SettingGroup sgTargeting; private final Setting<Set<class_1299<?>>> entities; private final Setting<TargetUtils.Mode> targetmode; private final Setting<Boolean> closestplayerignorefriends; private final Setting<List<String>> players; private final Setting<Keybind> hitEnemuy;
/*    */   public InfiniteAura() {
/* 24 */     super(AutoplayAddon.autoplay, "infinite-aura", "test");
/*    */     
/* 26 */     this.sgTargeting = this.settings.createGroup("Targeting");
/*    */     
/* 28 */     this.entities = this.sgTargeting.add((Setting)((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder())
/* 29 */         .name("entities"))
/* 30 */         .description("Entities to attack."))
/* 31 */         .onlyAttackable()
/* 32 */         .defaultValue(new class_1299[] { class_1299.field_6097
/* 33 */           }).build());
/*    */     
/* 35 */     this.targetmode = this.sgTargeting.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/* 36 */         .name("target-mode"))
/* 37 */         .description("how to choose a target player"))
/* 38 */         .defaultValue(TargetUtils.Mode.PlayerName))
/* 39 */         .build());
/*    */     
/* 41 */     this.closestplayerignorefriends = this.sgTargeting.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 42 */         .name("ignore-friends"))
/* 43 */         .description("Do you want to anchor your friends?"))
/* 44 */         .defaultValue(Boolean.valueOf(true)))
/* 45 */         .visible(() -> (this.targetmode.get() != TargetUtils.Mode.PlayerName)))
/* 46 */         .build());
/*    */     
/* 48 */     this.players = this.sgTargeting.add((Setting)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder())
/* 49 */         .name("targets"))
/* 50 */         .description("Players to target."))
/* 51 */         .defaultValue(List.of("PartyPixelParty", "marcooooow")))
/* 52 */         .visible(() -> (this.targetmode.get() == TargetUtils.Mode.PlayerName)))
/* 53 */         .build());
/*    */ 
/*    */     
/* 56 */     this.hitEnemuy = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/* 57 */         .name("attack"))
/* 58 */         .description("Estimates the entity you are looking at and attacks it."))
/* 59 */         .defaultValue(Keybind.none()))
/* 60 */         .action(() -> {
/*    */             class_1297 target = TargetUtils.getTarget(((Boolean)this.closestplayerignorefriends.get()).booleanValue(), (TargetUtils.Mode)this.targetmode.get(), (List)this.players.get(), (Set)this.entities.get());
/*    */             
/*    */             if (target == null) {
/*    */               ChatUtils.error("No target found.", new Object[0]);
/*    */               
/*    */               return;
/*    */             } 
/*    */             List<class_243> list = new ArrayList<>();
/*    */             list.add(target.method_19538().method_1031(0.0D, 0.1D, 0.0D));
/*    */             list.add(target.method_19538());
/*    */             list.add(ServerSideValues.serversidedposition);
/*    */             MulitPath path = new MulitPath(list);
/*    */             if (!path.canExecute().booleanValue()) {
/*    */               Disabler disabler = (Disabler)Modules.get().get(Disabler.class);
/*    */               if (!disabler.isActive()) {
/*    */                 ChatUtils.error("Not enough charge. Enable Disabler to build up more.", new Object[0]);
/*    */                 return;
/*    */               } 
/*    */               ChatUtils.error("Not enough charge.", new Object[0]);
/*    */               return;
/*    */             } 
/*    */             PacketUtils.packetQueue.clear();
/*    */             path.sendPackets(false);
/*    */             path.execute(0);
/*    */             path.execute(1, false, null, null);
/*    */             PacketUtils.packetQueue.add(class_2824.method_34206(target, false));
/*    */             path.execute(2);
/*    */             PacketUtils.sendAllPacketsInQueue();
/*    */             System.out.println("time in miliseconds: " + System.currentTimeMillis());
/* 90 */           }).build());
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\InfiniteAura.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */