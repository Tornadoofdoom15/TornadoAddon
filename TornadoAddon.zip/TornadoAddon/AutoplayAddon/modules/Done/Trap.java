/*     */ package AutoplayAddon.modules.Done;
/*     */ 
/*     */ import AutoplayAddon.AutoPlay.Movement.Paths.MulitPath;
/*     */ import AutoplayAddon.AutoPlay.Other.FastBox;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.TargetUtils;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.settings.StringListSetting;
/*     */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ 
/*     */ public class Trap extends Module {
/*     */   private final SettingGroup sgGeneral;
/*     */   private final SettingGroup sgTargeting;
/*     */   private final Setting<Set<class_1299<?>>> entities;
/*     */   private final Setting<TargetUtils.Mode> targetmode;
/*     */   private final Setting<Boolean> closestplayerignorefriends;
/*     */   
/*  32 */   public Trap() { super(AutoplayAddon.autoplay, "trap", "traps players");
/*     */ 
/*     */     
/*  35 */     this.sgGeneral = this.settings.getDefaultGroup();
/*     */     
/*  37 */     this.sgTargeting = this.settings.createGroup("Targeting");
/*     */     
/*  39 */     this.entities = this.sgTargeting.add((Setting)((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder())
/*  40 */         .name("entities"))
/*  41 */         .description("Entities to attack."))
/*  42 */         .onlyAttackable()
/*  43 */         .defaultValue(new class_1299[] { class_1299.field_6097
/*  44 */           }).build());
/*     */     
/*  46 */     this.targetmode = this.sgTargeting.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  47 */         .name("target-mode"))
/*  48 */         .description("how to choose a target player"))
/*  49 */         .defaultValue(TargetUtils.Mode.PlayerName))
/*  50 */         .build());
/*     */     
/*  52 */     this.closestplayerignorefriends = this.sgTargeting.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  53 */         .name("ignore-friends"))
/*  54 */         .description("Do you want to anchor your friends?"))
/*  55 */         .defaultValue(Boolean.valueOf(true)))
/*  56 */         .visible(() -> (this.targetmode.get() != TargetUtils.Mode.PlayerName)))
/*  57 */         .build());
/*     */     
/*  59 */     this.players = this.sgTargeting.add((Setting)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder())
/*  60 */         .name("targets"))
/*  61 */         .description("Players to target."))
/*  62 */         .defaultValue(List.of("PartyPixelParty", "marcooooow")))
/*  63 */         .visible(() -> (this.targetmode.get() == TargetUtils.Mode.PlayerName)))
/*  64 */         .build());
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.trapping = Boolean.valueOf(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     this.keybindtotrap = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/* 107 */         .name("anchor button"))
/* 108 */         .description("Cancels sending packets and sends you back to your original position."))
/* 109 */         .defaultValue(Keybind.none()))
/* 110 */         .action(() -> {
/*     */             class_1297 target = TargetUtils.getTarget(((Boolean)this.closestplayerignorefriends.get()).booleanValue(), (TargetUtils.Mode)this.targetmode.get(), (List)this.players.get(), (Set)this.entities.get());
/*     */             
/*     */             if (target == null) {
/*     */               ChatUtils.error("Failed to find a valid target.", new Object[0]);
/*     */               return;
/*     */             } 
/*     */             this.trapBlocks = getTrap(target);
/*     */             this.tpPos = target.method_19538();
/*     */             this.trapping = Boolean.valueOf(true);
/*     */             trap();
/* 121 */           }).build()); } private final Setting<List<String>> players; List<class_2338> trapBlocks; class_243 tpPos; Boolean trapping; private final Setting<Keybind> keybindtotrap; @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*     */     if (this.trapping.booleanValue())
/*     */       trap(); 
/*     */   } private List<class_2338> getTrap(class_1297 e) {
/* 126 */     FastBox fastBox = new FastBox(e);
/* 127 */     List<class_2338> collidedBlocks = fastBox.getOccupiedBlockPos();
/* 128 */     List<class_2338> trapBlocks = new ArrayList<>();
/*     */     
/* 130 */     int minY = Integer.MAX_VALUE;
/* 131 */     int maxY = Integer.MIN_VALUE;
/*     */     
/* 133 */     for (class_2338 pos : collidedBlocks) {
/* 134 */       minY = Math.min(minY, pos.method_10264());
/* 135 */       maxY = Math.max(maxY, pos.method_10264());
/*     */     } 
/*     */     
/* 138 */     int middleY = minY + (maxY - minY) / 2;
/*     */     
/* 140 */     for (class_2338 blockPos : collidedBlocks) {
/* 141 */       if (blockPos.method_10264() == middleY) {
/* 142 */         for (class_2350 dir : class_2350.values()) {
/* 143 */           if (dir != class_2350.field_11036 && dir != class_2350.field_11033) {
/* 144 */             class_2338 offsetPos = blockPos.method_10093(dir);
/* 145 */             if (!collidedBlocks.contains(offsetPos)) {
/* 146 */               trapBlocks.add(offsetPos);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/* 151 */       if (blockPos.method_10264() == maxY) {
/* 152 */         trapBlocks.add(blockPos.method_10084());
/*     */       }
/* 154 */       if (blockPos.method_10264() == minY) {
/* 155 */         trapBlocks.add(blockPos.method_10074());
/*     */       }
/*     */     } 
/*     */     
/* 159 */     return trapBlocks;
/*     */   }
/*     */   
/*     */   private void trap() {
/*     */     if (!ServerSideValues.canPlace())
/*     */       return; 
/*     */     MulitPath path = new MulitPath(List.of(this.tpPos, ServerSideValues.serversidedposition));
/*     */     path.sendPackets(false);
/*     */     path.execute(0);
/*     */     Iterator<class_2338> iterator = this.trapBlocks.iterator();
/*     */     while (iterator.hasNext()) {
/*     */       class_2338 pos = iterator.next();
/*     */       if (this.mc.field_1687.method_8320(pos).method_51367()) {
/*     */         iterator.remove();
/*     */         continue;
/*     */       } 
/*     */       if (ServerSideValues.canPlace()) {
/*     */         PacketUtils.packetQueue.add(new class_2885(class_1268.field_5808, new class_3965(pos.method_46558(), class_2350.field_11036, pos, false), 0));
/*     */         ServerSideValues.handleUse();
/*     */         iterator.remove();
/*     */         continue;
/*     */       } 
/*     */       this.trapping = Boolean.valueOf(true);
/*     */       path.execute(1);
/*     */       PacketUtils.sendAllPacketsInQueue();
/*     */       return;
/*     */     } 
/*     */     path.execute(1);
/*     */     PacketUtils.sendAllPacketsInQueue();
/*     */     this.trapping = Boolean.valueOf(false);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\Trap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */