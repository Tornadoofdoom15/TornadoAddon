/*     */ package AutoplayAddon.modules.Done;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import AutoplayAddon.Mixins.HandledScreenAccessor;
/*     */ import AutoplayAddon.Mixins.VillagerEntityAccessor;
/*     */ import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
/*     */ import it.unimi.dsi.fastutil.objects.Object2IntMap;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.events.entity.player.InteractEntityEvent;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.ItemListSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.player.FindItemResult;
/*     */ import meteordevelopment.meteorclient.utils.player.InvUtils;
/*     */ import meteordevelopment.meteorclient.utils.player.PlayerUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1728;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1914;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2863;
/*     */ 
/*     */ public class Villager_Aura extends Module {
/*  33 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*  34 */   private final SettingGroup sgReset = this.settings.createGroup("RESET");
/*  35 */   private final SettingGroup sgChat = this.settings.createGroup("INFO");
/*     */   
/*  37 */   private final Setting<List<class_1792>> buying = this.sgGeneral.add((Setting)((ItemListSetting.Builder)((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder())
/*  38 */       .name("buy"))
/*  39 */       .description("The items to buy."))
/*  40 */       .defaultValue(new class_1792[] { class_1802.field_8423, class_1802.field_8071
/*  41 */         }).filter(this::buyFilter)
/*  42 */       .onChanged(Item -> forget(true, true)))
/*  43 */       .build());
/*     */ 
/*     */   
/*  46 */   private final Setting<List<class_1792>> selling = this.sgGeneral.add((Setting)((ItemListSetting.Builder)((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder())
/*  47 */       .name("sell"))
/*  48 */       .description("The items to sell."))
/*  49 */       .filter(this::sellFilter)
/*  50 */       .onChanged(Item -> forget(true, true)))
/*  51 */       .build());
/*     */ 
/*     */   
/*  54 */   private final Setting<Boolean> close = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  55 */       .name("close"))
/*  56 */       .description("Closes the inventory of villagers when all your trades are done."))
/*  57 */       .defaultValue(Boolean.valueOf(true)))
/*  58 */       .build());
/*     */ 
/*     */   
/*  61 */   private final Setting<Boolean> click = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  62 */       .name("interact"))
/*  63 */       .description("Opens the inventory of villagers in range."))
/*  64 */       .defaultValue(Boolean.valueOf(true)))
/*  65 */       .build());
/*     */ 
/*     */   
/*  68 */   private final Setting<Integer> range = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  69 */       .name("range"))
/*  70 */       .description("The max distance to click villagers."))
/*  71 */       .defaultValue(Integer.valueOf(4)))
/*  72 */       .sliderRange(0, 5)
/*  73 */       .visible(() -> ((Boolean)this.click.get()).booleanValue()))
/*  74 */       .build());
/*     */ 
/*     */   
/*  77 */   private final Setting<Integer> emptySlots = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  78 */       .name("free slots"))
/*  79 */       .description("The number of empty inventory slots to keep."))
/*  80 */       .defaultValue(Integer.valueOf(4)))
/*  81 */       .sliderRange(0, 10)
/*  82 */       .build());
/*     */ 
/*     */   
/*  85 */   private final Setting<Integer> resetTime = this.sgReset.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  86 */       .name("timer"))
/*  87 */       .description("Forgets what villagers you traded with every x seconds. (0 to disable)"))
/*  88 */       .defaultValue(Integer.valueOf(60)))
/*  89 */       .sliderRange(0, 300)
/*  90 */       .build());
/*     */ 
/*     */   
/*  93 */   private final Setting<Boolean> resetRestock = this.sgReset.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  94 */       .name("on restock"))
/*  95 */       .description("Forgets what villagers you traded with when refilling your inventory for new trades."))
/*  96 */       .defaultValue(Boolean.valueOf(true)))
/*  97 */       .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   private final Setting<Boolean> info = this.sgChat.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 108 */       .name("info"))
/* 109 */       .description("Gives you info on what you need to restock."))
/* 110 */       .defaultValue(Boolean.valueOf(true)))
/* 111 */       .build());
/*     */ 
/*     */   
/* 114 */   private final Setting<Boolean> stats = this.sgChat.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 115 */       .name("stats"))
/* 116 */       .description("Displays some stats in chat when deactivating the module."))
/* 117 */       .defaultValue(Boolean.valueOf(true)))
/* 118 */       .build());
/*     */ 
/*     */   
/* 121 */   private final Setting<Boolean> debug = this.sgChat.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 122 */       .name("debug"))
/* 123 */       .description("don't mind me"))
/* 124 */       .defaultValue(Boolean.valueOf(false)))
/* 125 */       .visible(() -> true))
/* 126 */       .build()); int tradeCount; int itemsSold; int itemsBought; int emeraldNet;
/*     */   int emeraldCount;
/*     */   
/*     */   public Villager_Aura() {
/* 130 */     super(AutoplayAddon.autoplay, "Villager Aura", "Buy and sell items to nearby villagers.");
/*     */ 
/*     */     
/* 133 */     this.tradeCount = 0;
/* 134 */     this.itemsSold = 0;
/* 135 */     this.itemsBought = 0;
/* 136 */     this.emeraldNet = 0;
/* 137 */     this.emeraldCount = 0;
/* 138 */     this.invTotal = 0;
/* 139 */     this.lastAction = 0;
/* 140 */     this.timer = 0;
/*     */     
/* 142 */     this.villagerMap = (Object2IntMap<VillagerEntityAccessor>)new Object2IntArrayMap();
/*     */   }
/*     */   int invTotal; int lastAction; int timer; VillagerEntityAccessor lastVillager; Object2IntMap<VillagerEntityAccessor> villagerMap;
/*     */   
/*     */   public void onActivate() {
/* 147 */     getVillagers();
/* 148 */     updateInventory();
/* 149 */     this.lastVillager = null;
/* 150 */     this.villagerMap = (Object2IntMap<VillagerEntityAccessor>)new Object2IntArrayMap();
/* 151 */     this.emeraldCount = InvUtils.find(new class_1792[] { class_1802.field_8687 }).count();
/* 152 */     this.tradeCount = 0;
/* 153 */     this.itemsSold = 0;
/* 154 */     this.itemsBought = 0;
/* 155 */     this.emeraldNet = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeactivate() {
/* 160 */     if (!((Boolean)this.stats.get()).booleanValue())
/* 161 */       return;  info("Number of trades : " + this.tradeCount, new Object[0]);
/* 162 */     info("Items sold : " + this.itemsSold, new Object[0]);
/* 163 */     info("Items bought : " + this.itemsBought, new Object[0]);
/* 164 */     info("Emerald profit : " + this.emeraldNet, new Object[0]);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInteractEntity(InteractEntityEvent event) {
/* 169 */     if (event.entity instanceof net.minecraft.class_1646) {
/* 170 */       this.lastVillager = (VillagerEntityAccessor)event.entity;
/* 171 */       if (!this.villagerMap.containsKey(this.lastVillager)) this.villagerMap.put(this.lastVillager, 0);
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Post event) {
/* 178 */     this.timer++;
/*     */ 
/*     */     
/* 181 */     long time = this.mc.field_1687.method_8510() % 24000L;
/* 182 */     if (((Boolean)this.click.get()).booleanValue()) {
/*     */       
/* 184 */       if (this.timer % 200 == 0 || (this.timer % 40 == 0 && this.villagerMap.isEmpty())) {
/* 185 */         getVillagers();
/*     */       }
/*     */       
/* 188 */       if (time == 2000L || time == 4000L || time == 6000L) {
/* 189 */         if (((Boolean)this.debug.get()).booleanValue()) info("restocked, time : " + time, new Object[0]); 
/* 190 */         forget(true, true);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 195 */     if (((Integer)this.resetTime.get()).intValue() > 0 && this.timer % 20 * ((Integer)this.resetTime.get()).intValue() == 0) {
/* 196 */       forget(true, true);
/* 197 */       if (((Boolean)this.debug.get()).booleanValue()) info("reset time", new Object[0]); 
/*     */     } 
/* 199 */     if (((Boolean)this.resetRestock.get()).booleanValue() && !(this.mc.field_1755 instanceof net.minecraft.class_492)) {
/* 200 */       updateInventory();
/*     */     }
/*     */ 
/*     */     
/* 204 */     if (this.mc.field_1755 instanceof net.minecraft.class_492) {
/*     */       
/* 206 */       class_1728 handler = (class_1728)((HandledScreenAccessor)this.mc.field_1755).getHandler();
/* 207 */       if (invFull())
/* 208 */         return;  boolean success = trySell(handler);
/* 209 */       if (!success) success = tryBuy(handler); 
/* 210 */       if (this.lastAction < this.timer && ((Boolean)this.close.get()).booleanValue()) this.mc.field_1724.method_7346();
/*     */     
/*     */     } 
/*     */     
/* 214 */     if (!this.villagerMap.isEmpty() && !(this.mc.field_1755 instanceof net.minecraft.class_465) && ((Boolean)this.click.get()).booleanValue()) {
/* 215 */       if (invFull())
/* 216 */         return;  for (ObjectIterator<VillagerEntityAccessor> objectIterator = this.villagerMap.keySet().iterator(); objectIterator.hasNext(); ) { VillagerEntityAccessor villager = objectIterator.next();
/* 217 */         if (this.villagerMap.get(villager).intValue() > 0) {
/* 218 */           if (((Boolean)this.debug.get()).booleanValue()) info("villager status : " + this.villagerMap.get(villager), new Object[0]); 
/*     */           continue;
/*     */         } 
/* 221 */         if (((Integer)this.range.get()).intValue() > PlayerUtils.distanceTo((class_1297)villager)) {
/* 222 */           this.mc.field_1761.method_2905((class_1657)this.mc.field_1724, (class_1297)villager, class_1268.field_5808);
/* 223 */           this.lastVillager = villager;
/*     */           break;
/*     */         }  }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean trySell(class_1728 handler) {
/* 232 */     int index = 0;
/* 233 */     boolean ranOut = true;
/* 234 */     boolean allDisabled = true;
/* 235 */     boolean success = false;
/* 236 */     for (class_1914 offer : handler.method_17438()) {
/* 237 */       int uses = offer.method_8249();
/* 238 */       if (((List)this.selling.get()).contains(offer.method_19272().method_7909()) && !offer.method_8255()) {
/* 239 */         allDisabled = false;
/* 240 */         FindItemResult item = InvUtils.find(new class_1792[] { offer.method_19272().method_7909() });
/* 241 */         if (item.count() >= offer.method_19272().method_7947()) {
/* 242 */           clickTrade(handler, index);
/* 243 */           trade(handler);
/* 244 */           resetSlots(handler);
/* 245 */           this.lastAction = this.timer;
/* 246 */           this.tradeCount += offer.method_8249() - uses;
/* 247 */           this.itemsSold += item.count() - InvUtils.find(new class_1792[] { offer.method_19272().method_7909() }).count();
/* 248 */           this.emeraldNet += offer.method_8250().method_7947() * (offer.method_8249() - uses);
/* 249 */           ranOut = false;
/* 250 */           success = true;
/* 251 */           if (((Boolean)this.debug.get()).booleanValue()) info("sold something", new Object[0]);
/*     */           
/*     */           break;
/*     */         } 
/* 255 */         if (((Boolean)this.info.get()).booleanValue()) info("You need more " + offer.method_19272().method_7909().toString() + " !", new Object[0]);
/*     */       
/*     */       } 
/* 258 */       index++;
/*     */     } 
/* 260 */     if (ranOut) this.villagerMap.replace(this.lastVillager, 1); 
/* 261 */     if (allDisabled) this.villagerMap.replace(this.lastVillager, 2); 
/* 262 */     return success;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean tryBuy(class_1728 handler) {
/* 267 */     this.emeraldCount = InvUtils.find(new class_1792[] { class_1802.field_8687 }).count();
/* 268 */     int index = 0;
/* 269 */     boolean outOfEmeralds = false;
/* 270 */     boolean allDisabled = true;
/* 271 */     boolean success = false;
/* 272 */     for (class_1914 offer : handler.method_17438()) {
/* 273 */       int uses = offer.method_8249();
/* 274 */       if (((List)this.buying.get()).contains(offer.method_8250().method_7909()) && !offer.method_8255()) {
/* 275 */         allDisabled = false;
/* 276 */         if (this.emeraldCount >= offer.method_19272().method_7947()) {
/* 277 */           clickTrade(handler, index);
/* 278 */           trade(handler);
/* 279 */           resetSlots(handler);
/* 280 */           this.lastAction = this.timer;
/* 281 */           this.tradeCount += offer.method_8249() - uses;
/* 282 */           this.emeraldNet += InvUtils.find(new class_1792[] { class_1802.field_8687 }).count() - this.emeraldCount;
/* 283 */           this.itemsBought += offer.method_8250().method_7947() * (offer.method_8249() - uses);
/* 284 */           success = true;
/* 285 */           if (((Boolean)this.debug.get()).booleanValue()) info("bought something", new Object[0]); 
/*     */           break;
/*     */         } 
/* 288 */         if (((Boolean)this.info.get()).booleanValue()) info("You need more emeralds !", new Object[0]); 
/* 289 */         outOfEmeralds = true;
/*     */       } 
/*     */       
/* 292 */       index++;
/*     */     } 
/* 294 */     if (outOfEmeralds) this.villagerMap.replace(this.lastVillager, 1); 
/* 295 */     if (allDisabled) this.villagerMap.replace(this.lastVillager, 2); 
/* 296 */     return success;
/*     */   }
/*     */   
/*     */   public void clickTrade(class_1728 handler, int index) {
/* 300 */     handler.method_7650(index);
/* 301 */     handler.method_20215(index);
/* 302 */     this.mc.method_1562().method_52787((class_2596)new class_2863(index));
/*     */   }
/*     */   
/*     */   public void trade(class_1728 handler) {
/* 306 */     InvUtils.shiftClick().slotId(2);
/*     */   }
/*     */   
/*     */   public void resetSlots(class_1728 handler) {
/* 310 */     InvUtils.shiftClick().slotId(0);
/* 311 */     InvUtils.shiftClick().slotId(1);
/*     */   }
/*     */   
/*     */   public void getVillagers() {
/* 315 */     ArrayList<VillagerEntityAccessor> villagerList = new ArrayList<>();
/* 316 */     for (class_1297 e : this.mc.field_1687.method_18112()) {
/* 317 */       if (!(e instanceof net.minecraft.class_1646))
/* 318 */         continue;  VillagerEntityAccessor entity = (VillagerEntityAccessor)e;
/* 319 */       boolean isIn = false;
/* 320 */       for (ObjectIterator<VillagerEntityAccessor> objectIterator1 = this.villagerMap.keySet().iterator(); objectIterator1.hasNext(); ) { VillagerEntityAccessor villager = objectIterator1.next();
/* 321 */         if (((class_1297)villager).method_5628() == ((class_1297)entity).method_5628()) {
/* 322 */           isIn = true;
/*     */         } }
/*     */       
/* 325 */       if (!isIn) {
/* 326 */         this.villagerMap.put(entity, 0);
/*     */       }
/*     */     } 
/* 329 */     for (ObjectIterator<VillagerEntityAccessor> objectIterator = this.villagerMap.keySet().iterator(); objectIterator.hasNext(); ) { VillagerEntityAccessor villager = objectIterator.next(); villagerList.add(villager); }
/* 330 */      for (VillagerEntityAccessor villager : villagerList) {
/* 331 */       boolean isIn = false;
/* 332 */       for (class_1297 entity : this.mc.field_1687.method_18112()) {
/* 333 */         if (((class_1297)villager).method_5628() == entity.method_5628()) isIn = true; 
/*     */       } 
/* 335 */       if (!isIn) {
/* 336 */         this.villagerMap.remove(villager);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void forget(boolean disable, boolean restock) {
/* 342 */     for (ObjectIterator<VillagerEntityAccessor> objectIterator = this.villagerMap.keySet().iterator(); objectIterator.hasNext(); ) { VillagerEntityAccessor villager = objectIterator.next();
/* 343 */       if (this.villagerMap.get(villager).intValue() == 1 && restock) this.villagerMap.replace(villager, 0); 
/* 344 */       if (this.villagerMap.get(villager).intValue() == 2 && disable) this.villagerMap.replace(villager, 0);  }
/*     */   
/*     */   }
/*     */   
/*     */   public void updateInventory() {
/* 349 */     int newTotal = 0;
/* 350 */     for (class_1792 item : this.selling.get()) {
/* 351 */       newTotal += InvUtils.find(new class_1792[] { item }).count();
/*     */     } 
/* 353 */     newTotal += InvUtils.find(new class_1792[] { class_1802.field_8687 }).count();
/* 354 */     if (((Boolean)this.debug.get()).booleanValue()) info("" + newTotal, new Object[0]);
/*     */     
/* 356 */     if (newTotal > this.invTotal) {
/* 357 */       if (((Boolean)this.debug.get()).booleanValue()) info("reset restock", new Object[0]); 
/* 358 */       forget(true, false);
/*     */     } 
/* 360 */     this.invTotal = newTotal;
/*     */   }
/*     */   
/*     */   public boolean invFull() {
/* 364 */     int airCount = 0;
/* 365 */     for (int i = 0; i < 36; i++) {
/* 366 */       if (this.mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8162) {
/* 367 */         airCount++;
/*     */       }
/*     */     } 
/* 370 */     return (airCount <= ((Integer)this.emptySlots.get()).intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean buyFilter(class_1792 item) {
/* 375 */     return (item == class_1802.field_8229 || item == class_1802.field_8741 || item == class_1802.field_8279 || item == class_1802.field_8423 || item == class_1802.field_8766 || item == class_1802.field_17534 || item == class_1802.field_8071 || item == class_1802.field_8597 || item == class_1802.field_8308 || item == class_1802.field_8261 || item == class_1802.field_8544 || item == class_1802.field_8666 || item == class_1802.field_8373 || item == class_1802.field_17346 || item == class_1802.field_8509 || item == class_1802.field_8378 || item == class_1802.field_8536 || item == class_1802.field_8598 || item == class_1802.field_16539 || item == class_1802.field_8280 || item == class_1802.field_8557 || item == class_1802.field_8251 || item == class_1802.field_8448 || item == class_1802.field_8660 || item == class_1802.field_8396 || item == class_1802.field_8523 || item == class_1802.field_8743 || item == class_1802.field_8285 || item == class_1802.field_8348 || item == class_1802.field_8058 || item == class_1802.field_8805 || item == class_1802.field_16315 || item == class_1802.field_8255 || item == class_1802.field_8062 || item == class_1802.field_8387 || item == class_1802.field_8431 || item == class_1802.field_8776 || item == class_1802.field_8475 || item == class_1802.field_8403 || item == class_1802.field_8609 || item == class_1802.field_8699 || item == class_1802.field_8556 || item == class_1802.field_8377 || item == class_1802.field_8527 || item == class_1802.field_8250 || item == class_1802.field_8868 || item == class_1802.field_19044 || item == class_1802.field_19045 || item == class_1802.field_19046 || item == class_1802.field_19047 || item == class_1802.field_19048 || item == class_1802.field_19049 || item == class_1802.field_19050 || item == class_1802.field_19051 || item == class_1802.field_19052 || item == class_1802.field_19053 || item == class_1802.field_19054 || item == class_1802.field_19055 || item == class_1802.field_19056 || item == class_1802.field_19057 || item == class_1802.field_19058 || item == class_1802.field_19059 || item == class_1802.field_8850 || item == class_1802.field_8683 || item == class_1802.field_8384 || item == class_1802.field_8078 || item == class_1802.field_8142 || item == class_1802.field_8253 || item == class_1802.field_8580 || item == class_1802.field_8875 || item == class_1802.field_8654 || item == class_1802.field_8290 || item == class_1802.field_8098 || item == class_1802.field_8115 || item == class_1802.field_8294 || item == class_1802.field_8664 || item == class_1802.field_8482 || item == class_1802.field_8611 || item == class_1802.field_8892 || item == class_1802.field_8258 || item == class_1802.field_8059 || item == class_1802.field_8349 || item == class_1802.field_8286 || item == class_1802.field_8863 || item == class_1802.field_8679 || item == class_1802.field_8417 || item == class_1802.field_8754 || item == class_1802.field_8146 || item == class_1802.field_8390 || item == class_1802.field_8262 || item == class_1802.field_8893 || item == class_1802.field_8464 || item == class_1802.field_8368 || item == class_1802.field_8789 || item == class_1802.field_8112 || item == class_1802.field_8370 || item == class_1802.field_8570 || item == class_1802.field_8577 || item == class_1802.field_8267 || item == class_1802.field_18138 || item == class_1802.field_8175 || item == class_1802.field_8725 || item == class_1802.field_8759 || item == class_1802.field_8801 || item == class_1802.field_8634 || item == class_1802.field_8287 || item == class_1802.field_8895 || item == class_1802.field_8204 || item == class_1802.field_8143 || item == class_1802.field_8539 || item == class_1802.field_8824 || item == class_1802.field_8671 || item == class_1802.field_8379 || item == class_1802.field_8049 || item == class_1802.field_8778 || item == class_1802.field_8329 || item == class_1802.field_8617 || item == class_1802.field_8855 || item == class_1802.field_8629 || item == class_1802.field_8405 || item == class_1802.field_8128 || item == class_1802.field_8124 || item == class_1802.field_8295 || item == class_1802.field_8586 || item == class_1802.field_8572 || item == class_1802.field_8498 || item == class_1802.field_8573 || item == class_1802.field_8159 || item == class_1802.field_8891 || item == class_1802.field_18674 || item == class_1802.field_23831 || item == class_1802.field_8107 || item == class_1802.field_8145 || item == class_1802.field_8102 || item == class_1802.field_8399 || item == class_1802.field_8087 || item == class_1802.field_8475 || item == class_1802.field_8371 || item == class_1802.field_8556 || item == class_1802.field_8802 || item == class_1802.field_8621 || item == class_1802.field_8525 || item == class_1802.field_8156 || item == class_1802.field_8043 || item == class_1802.field_8783 || item == class_1802.field_8717 || item == class_1802.field_8385 || item == class_1802.field_8672 || item == class_1802.field_8853 || item == class_1802.field_8304 || item == class_1802.field_8133 || item == class_1802.field_8821 || item == class_1802.field_8715 || item == class_1802.field_8455 || item == class_1802.field_8467 || item == class_1802.field_8798 || item == class_1802.field_8353 || item == class_1802.field_8181 || item == class_1802.field_8177 || item == class_1802.field_8139 || item == class_1802.field_8318 || item == class_1802.field_8640 || item == class_1802.field_8889 || item == class_1802.field_8649 || item == class_1802.field_8277 || item == class_1802.field_8885 || item == class_1802.field_8172 || item == class_1802.field_8257 || item == class_1802.field_8562 || item == class_1802.field_8484 || item == class_1802.field_8394 || item == class_1802.field_8244 || item == class_1802.field_8870 || item == class_1802.field_8096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean sellFilter(class_1792 item) {
/* 578 */     return (item == class_1802.field_8861 || item == class_1802.field_8186 || item == class_1802.field_8179 || item == class_1802.field_8567 || item == class_1802.field_17518 || item == class_1802.field_17522 || item == class_1802.field_8726 || item == class_1802.field_8389 || item == class_1802.field_8504 || item == class_1802.field_8713 || item == class_1802.field_8748 || item == class_1802.field_8046 || item == class_1802.field_17533 || item == class_1802.field_16998 || item == class_1802.field_8276 || item == class_1802.field_8429 || item == class_1802.field_8209 || item == class_1802.field_8846 || item == class_1802.field_8323 || item == class_1802.field_8533 || item == class_1802.field_8486 || item == class_1802.field_8094 || item == class_1802.field_8442 || item == class_1802.field_8138 || item == class_1802.field_8407 || item == class_1802.field_8529 || item == class_1802.field_8794 || item == class_1802.field_8674 || item == class_1802.field_8620 || item == class_1802.field_8187 || item == class_1802.field_8477 || item == class_1802.field_8145 || item == class_1802.field_19044 || item == class_1802.field_19059 || item == class_1802.field_19051 || item == class_1802.field_19056 || item == class_1802.field_8446 || item == class_1802.field_8851 || item == class_1802.field_8226 || item == class_1802.field_8273 || item == class_1802.field_8131 || item == class_1802.field_8192 || item == class_1802.field_8492 || item == class_1802.field_8264 || item == class_1802.field_8298 || item == class_1802.field_8296 || item == class_1802.field_8669 || item == class_1802.field_8330 || item == class_1802.field_8345 || item == class_1802.field_8632 || item == class_1802.field_8408 || item == class_1802.field_8099 || item == class_1802.field_8745 || item == class_1802.field_8245 || item == class_1802.field_8511 || item == class_1802.field_8695 || item == class_1802.field_8073 || item == class_1802.field_8469 || item == class_1802.field_8790 || item == class_1802.field_8141 || item == class_1802.field_8251 || item == class_1802.field_8600 || item == class_1802.field_8276 || item == class_1802.field_8153 || item == class_1802.field_8366 || item == class_1802.field_8696 || item == class_1802.field_8110 || item == class_1802.field_20401 || item == class_1802.field_20394 || item == class_1802.field_20407 || item == class_1802.field_20403 || item == class_1802.field_20397 || item == class_1802.field_20411 || item == class_1802.field_20391 || item == class_1802.field_8155);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\Villager_Aura.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */