/*    */ package AutoplayAddon.modules.Done;
/*    */ 
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2848;
/*    */ 
/*    */ public class BetterAntiHunger extends Module {
/*    */   public BetterAntiHunger() {
/* 12 */     super(AutoplayAddon.autoplay, "betterantihunger", "any anticheat disabler real dosent work XD");
/*    */     
/* 14 */     this.sgGeneral = this.settings.getDefaultGroup();
/*    */   } private final SettingGroup sgGeneral;
/*    */   @EventHandler(priority = 202)
/*    */   public void onSendPacket(PacketEvent.Send event) {
/* 18 */     if (event.packet instanceof class_2848) {
/* 19 */       class_2848 packet = (class_2848)event.packet;
/* 20 */       if (packet.method_12365() == class_2848.class_2849.field_12981 || packet.method_12365() == class_2848.class_2849.field_12985) {
/* 21 */         event.setCancelled(true);
/* 22 */         event.cancel();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\BetterAntiHunger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */