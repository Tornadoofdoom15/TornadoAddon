/*     */ package AutoplayAddon.modules.Done;
/*     */ 
/*     */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*     */ import AutoplayAddon.AutoPlay.Other.AnchorUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.RandomTp;
/*     */ import AutoplayAddon.AutoPlay.Other.TargetUtils;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.settings.StringListSetting;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2828;
/*     */ 
/*     */ public class InfAnchor
/*     */   extends Module {
/*     */   private final SettingGroup sgGeneral;
/*     */   private final Setting<Boolean> follow;
/*     */   
/*     */   public InfAnchor() {
/*  38 */     super(AutoplayAddon.autoplay, "inf-anchor", "inf anchor");
/*     */ 
/*     */     
/*  41 */     this.sgGeneral = this.settings.getDefaultGroup();
/*     */     
/*  43 */     this.follow = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  44 */         .name("follow"))
/*  45 */         .description("Teleport randomly around your target."))
/*  46 */         .defaultValue(Boolean.valueOf(true)))
/*  47 */         .build());
/*     */ 
/*     */     
/*  50 */     this.followmode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  51 */         .name("follow-mode"))
/*  52 */         .description("The formation mode, either line or circle."))
/*  53 */         .defaultValue(FollowerMode.RandomTP))
/*  54 */         .visible(() -> ((Boolean)this.follow.get()).booleanValue()))
/*  55 */         .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     this.distance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  63 */         .name("random-TP-distance-from-player"))
/*  64 */         .description("How much distance in each random teleport?"))
/*  65 */         .defaultValue(Integer.valueOf(25)))
/*  66 */         .min(0)
/*  67 */         .sliderMax(300)
/*  68 */         .visible(() -> (((Boolean)this.follow.get()).booleanValue() && this.followmode.get() == FollowerMode.RandomTP)))
/*  69 */         .build());
/*     */     
/*  71 */     this.yheight = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  72 */         .name("y-level-height"))
/*  73 */         .description("test"))
/*  74 */         .defaultValue(Integer.valueOf(400)))
/*  75 */         .min(-120)
/*  76 */         .sliderMax(36000)
/*  77 */         .visible(() -> (((Boolean)this.follow.get()).booleanValue() && this.followmode.get() == FollowerMode.Y_Level)))
/*  78 */         .build());
/*     */ 
/*     */     
/*  81 */     this.sgTargeting = this.settings.createGroup("Targeting");
/*     */     
/*  83 */     this.entities = this.sgTargeting.add((Setting)((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder())
/*  84 */         .name("entities"))
/*  85 */         .description("Entities to attack."))
/*  86 */         .onlyAttackable()
/*  87 */         .defaultValue(new class_1299[] { class_1299.field_6097
/*  88 */           }).build());
/*     */     
/*  90 */     this.targetmode = this.sgTargeting.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  91 */         .name("target-mode"))
/*  92 */         .description("how to choose a target player"))
/*  93 */         .defaultValue(TargetUtils.Mode.PlayerName))
/*  94 */         .build());
/*     */     
/*  96 */     this.closestplayerignorefriends = this.sgTargeting.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  97 */         .name("ignore-friends"))
/*  98 */         .description("Do you want to anchor your friends?"))
/*  99 */         .defaultValue(Boolean.valueOf(true)))
/* 100 */         .visible(() -> (this.targetmode.get() != TargetUtils.Mode.PlayerName)))
/* 101 */         .build());
/*     */     
/* 103 */     this.players = this.sgTargeting.add((Setting)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder())
/* 104 */         .name("targets"))
/* 105 */         .description("Players to target."))
/* 106 */         .defaultValue(List.of("PartyPixelParty", "marcooooow")))
/* 107 */         .visible(() -> (this.targetmode.get() == TargetUtils.Mode.PlayerName)))
/* 108 */         .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     this.keybindtoanchor = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/* 150 */         .name("anchor button"))
/* 151 */         .description("Cancels sending packets and sends you back to your original position."))
/* 152 */         .defaultValue(Keybind.none()))
/* 153 */         .action(() -> {
/*     */             class_243 newpos;
/*     */             
/*     */             class_1297 target = TargetUtils.getTarget(((Boolean)this.closestplayerignorefriends.get()).booleanValue(), (TargetUtils.Mode)this.targetmode.get(), (List)this.players.get(), (Set)this.entities.get());
/*     */             if (target == null) {
/*     */               ChatUtils.error("Failed to find a valid target.", new Object[0]);
/*     */               return;
/*     */             } 
/*     */             class_2338 finalBlockPos = AnchorUtils.getAnchorPos(target);
/*     */             class_243 targetpos = target.method_19538();
/*     */             if (((Boolean)this.follow.get()).booleanValue() && this.followmode.get() == FollowerMode.Y_Level) {
/*     */               newpos = new class_243(targetpos.field_1352, ((Integer)this.yheight.get()).intValue(), targetpos.field_1350);
/*     */             } else if (((Boolean)this.follow.get()).booleanValue() && this.followmode.get() == FollowerMode.RandomTP) {
/*     */               newpos = RandomTp.findValidTpPos(targetpos, ((Integer)this.distance.get()).intValue());
/*     */             } else {
/*     */               newpos = ServerSideValues.serversidedposition;
/*     */             } 
/*     */             AnchorUtils.blow(finalBlockPos, newpos);
/* 171 */           }).build());
/*     */   }
/*     */   
/*     */   private final Setting<FollowerMode> followmode;
/*     */   private final Setting<Integer> distance;
/*     */   public final Setting<Integer> yheight;
/*     */   private final SettingGroup sgTargeting;
/*     */   private final Setting<Set<class_1299<?>>> entities;
/*     */   private final Setting<TargetUtils.Mode> targetmode;
/*     */   private final Setting<Boolean> closestplayerignorefriends;
/*     */   private final Setting<List<String>> players;
/*     */   private final Setting<Keybind> keybindtoanchor;
/*     */   
/*     */   public enum FollowerMode {
/*     */     RandomTP, Y_Level;
/*     */   }
/*     */   
/*     */   @EventHandler(priority = 201)
/*     */   private void onSendPacket(PacketEvent.Send event) {
/*     */     class_1297 target = TargetUtils.getTarget(((Boolean)this.closestplayerignorefriends.get()).booleanValue(), (TargetUtils.Mode)this.targetmode.get(), (List)this.players.get(), (Set)this.entities.get());
/*     */     if (((Boolean)this.follow.get()).booleanValue() && target != null) {
/*     */       class_2596 class_2596 = event.packet;
/*     */       if (class_2596 instanceof class_2828) {
/*     */         class_2828 packet = (class_2828)class_2596;
/*     */         event.cancel();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean cancelRandomTp() {
/*     */     if (((Boolean)this.follow.get()).booleanValue() && TargetUtils.getTarget(((Boolean)this.closestplayerignorefriends.get()).booleanValue(), (TargetUtils.Mode)this.targetmode.get(), (List)this.players.get(), (Set)this.entities.get()) != null)
/*     */       return true; 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private void teleport() {
/*     */     if (((Boolean)this.follow.get()).booleanValue()) {
/*     */       class_1297 target = TargetUtils.getTarget(((Boolean)this.closestplayerignorefriends.get()).booleanValue(), (TargetUtils.Mode)this.targetmode.get(), (List)this.players.get(), (Set)this.entities.get());
/*     */       if (target != null) {
/*     */         class_243 tpPos, targetpos = target.method_19538();
/*     */         if (this.followmode.get() == FollowerMode.Y_Level) {
/*     */           tpPos = new class_243(targetpos.field_1352, ((Integer)this.yheight.get()).intValue(), targetpos.field_1350);
/*     */         } else {
/*     */           tpPos = RandomTp.findValidTpPos(targetpos, ((Integer)this.distance.get()).intValue());
/*     */         } 
/*     */         if (tpPos != null) {
/*     */           if (tpPos.field_1352 == ServerSideValues.serversidedposition.field_1352 && tpPos.field_1351 == ServerSideValues.serversidedposition.field_1351 && tpPos.field_1350 == ServerSideValues.serversidedposition.field_1350)
/*     */             return; 
/*     */           Movement.setPos(tpPos, true, null, null);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*     */     if (((Boolean)this.follow.get()).booleanValue())
/*     */       teleport(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Done\InfAnchor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */