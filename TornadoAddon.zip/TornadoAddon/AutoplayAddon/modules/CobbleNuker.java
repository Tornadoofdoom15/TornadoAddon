/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.IntSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2246;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2382;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_2828;
/*    */ import net.minecraft.class_2846;
/*    */ import net.minecraft.class_3532;
/*    */ 
/*    */ public class CobbleNuker extends Module {
/* 24 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/* 25 */   public static final double MAX_INTERACTION_DISTANCE = class_3532.method_33723(6.0D) - 0.5D;
/*    */   
/* 27 */   public final Setting<Integer> blockrange = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/* 28 */       .name("Amount of logs to mine"))
/* 29 */       .description("blockrange"))
/* 30 */       .defaultValue(Integer.valueOf(5)))
/* 31 */       .min(0)
/* 32 */       .sliderMax(100)
/* 33 */       .build());
/*    */ 
/*    */   
/* 36 */   private final class_2350 direction = class_2350.field_11036;
/*    */ 
/*    */   
/*    */   public CobbleNuker() {
/* 40 */     super(AutoplayAddon.autoplay, "CobbleNuker", "Attempts to instantly mine blocks.");
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler(priority = -200)
/*    */   private void onTick(TickEvent.Pre event) {
/* 46 */     PacketUtils.sendPacket((class_2596)new class_2828.class_5911(true));
/* 47 */     class_2680 cobblestoneState = class_2246.field_10445.method_9564();
/* 48 */     class_2338 blockPos = this.mc.field_1724.method_24515();
/* 49 */     for (int x = -((Integer)this.blockrange.get()).intValue(); x <= ((Integer)this.blockrange.get()).intValue(); x++) {
/* 50 */       for (int y = 0; y <= ((Integer)this.blockrange.get()).intValue(); y++) {
/* 51 */         for (int z = -((Integer)this.blockrange.get()).intValue(); z <= ((Integer)this.blockrange.get()).intValue(); z++) {
/* 52 */           class_2338 currentBlockPos = new class_2338(blockPos.method_10263() + x, blockPos.method_10264() + y, blockPos.method_10260() + z);
/* 53 */           if (!ServerSideValues.canSendPackets(2L, System.nanoTime()).booleanValue())
/* 54 */             return;  if (this.mc.field_1724.method_33571().method_1022(class_243.method_24953((class_2382)currentBlockPos)) <= MAX_INTERACTION_DISTANCE && 
/* 55 */             this.mc.field_1687.method_8320(currentBlockPos) == cobblestoneState) {
/* 56 */             PacketUtils.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12968, currentBlockPos, this.direction));
/* 57 */             PacketUtils.sendPacket((class_2596)new class_2846(class_2846.class_2847.field_12973, currentBlockPos, this.direction));
/* 58 */             this.mc.field_1687.method_8501(currentBlockPos, class_2246.field_10124.method_9564());
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\CobbleNuker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */