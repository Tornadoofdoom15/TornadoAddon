/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PacketMode
/*    */ {
/* 25 */   None,
/* 26 */   All,
/* 27 */   Whitelist,
/* 28 */   Blacklist;
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\PacketLogger$PacketMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */