/*     */ package AutoplayAddon.modules;
/*     */ 
/*     */ import AutoplayAddon.AutoPlay.Locator.AirGapFinder;
/*     */ import AutoplayAddon.AutoPlay.Mining.MineUtils;
/*     */ import AutoplayAddon.AutoPlay.Movement.Paths.MulitPath;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.AutoPlay.Other.Render;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2846;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ public class InfiniteMine
/*     */   extends Module
/*     */ {
/*     */   BreakingBlock block;
/*     */   
/*     */   public InfiniteMine() {
/*  29 */     super(AutoplayAddon.autoplay, "infinite-mine", "Attempts to instantly mine blocks.");
/*     */     
/*  31 */     this.block = null;
/*     */   }
/*     */   @EventHandler
/*     */   private void onStartBreakingBlock(StartBreakingBlockEvent event) {
/*  35 */     event.cancel();
/*  36 */     if (this.block != null && this.block.pos == event.blockPos)
/*  37 */       return;  this.block = new BreakingBlock(event.blockPos, event.direction);
/*  38 */     MulitPath path = new MulitPath(List.of(AirGapFinder.findAirGapNearBlock(event.blockPos, 5.0D), ServerSideValues.serversidedposition));
/*  39 */     if (!path.canExecute().booleanValue())
/*  40 */       return;  PacketUtils.packetQueue.clear();
/*  41 */     path.sendPackets(false);
/*  42 */     path.execute(0);
/*  43 */     if (this.block.startBreaking()) this.block = null; 
/*  44 */     path.execute(1);
/*  45 */     PacketUtils.sendAllPacketsInQueue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*  72 */     if (this.block != null && 
/*  73 */       this.block.canMine()) {
/*  74 */       MulitPath path = new MulitPath(List.of(AirGapFinder.findAirGapNearBlock(this.block.pos, 5.0D), ServerSideValues.serversidedposition));
/*  75 */       if (!path.canExecute().booleanValue())
/*  76 */         return;  PacketUtils.packetQueue.clear();
/*  77 */       path.sendPackets(false);
/*  78 */       path.execute(0);
/*  79 */       this.block.Mine();
/*  80 */       path.execute(1);
/*  81 */       PacketUtils.sendAllPacketsInQueue();
/*  82 */       this.block = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/*  90 */     if (this.block != null) this.block.render(event); 
/*     */   }
/*     */   
/*     */   class BreakingBlock { public final class_2338 pos;
/*     */     public final class_2680 state;
/*     */     public final int startTick;
/*     */     public final class_2350 direction;
/*     */     
/*     */     public BreakingBlock(class_2338 pos, class_2350 direction) {
/*  99 */       this.pos = pos;
/* 100 */       this.state = InfiniteMine.this.mc.field_1687.method_8320(pos);
/* 101 */       this.startTick = ServerSideValues.ticks;
/* 102 */       this.direction = direction;
/*     */     }
/*     */     public boolean startBreaking() {
/* 105 */       InfiniteMine.this.info("start breaking", new Object[0]);
/* 106 */       float f1 = MineUtils.calcBlockBreakingDelta(this.state, this.pos);
/* 107 */       PacketUtils.packetQueue.add(new class_2846(class_2846.class_2847.field_12968, this.pos, this.direction));
/* 108 */       if (f1 >= 1.0F) return true; 
/* 109 */       if (f1 >= 0.7F) {
/* 110 */         PacketUtils.packetQueue.add(new class_2846(class_2846.class_2847.field_12973, this.pos, this.direction));
/* 111 */         return true;
/*     */       } 
/* 113 */       InfiniteMine.this.info("we cant insta break the block", new Object[0]);
/* 114 */       return false;
/*     */     }
/*     */     
/*     */     public boolean canMine() {
/* 118 */       int l = ServerSideValues.ticks - this.startTick;
/* 119 */       float f = MineUtils.calcBlockBreakingDelta(this.state, this.pos) * (l + 1);
/* 120 */       return (f >= 0.7F);
/*     */     }
/*     */     public void Mine() {
/* 123 */       InfiniteMine.this.info("mining", new Object[0]);
/* 124 */       PacketUtils.packetQueue.add(new class_2846(class_2846.class_2847.field_12973, this.pos, this.direction));
/*     */     }
/*     */     
/*     */     public void render(Render3DEvent event) {
/* 128 */       int l = ServerSideValues.ticks - this.startTick;
/* 129 */       float fast = MineUtils.calcBlockBreakingDelta(this.state, this.pos) * (l + 1);
/* 130 */       Render.renderBlock(event, this.pos, (fast / 0.7F));
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InfiniteMine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */