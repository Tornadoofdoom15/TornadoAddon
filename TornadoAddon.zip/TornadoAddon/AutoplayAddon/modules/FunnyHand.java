/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.Mixins.PlayerMoveC2SPacketMixin;
/*     */ import java.util.Random;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1306;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2739;
/*     */ import net.minecraft.class_2803;
/*     */ import net.minecraft.class_2828;
/*     */ import net.minecraft.class_2848;
/*     */ import net.minecraft.class_2879;
/*     */ import net.minecraft.class_8791;
/*     */ 
/*     */ public class FunnyHand extends Module {
/*  24 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*     */   
/*  26 */   public final Setting<Integer> sneakdelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  27 */       .name("sneak-delay"))
/*  28 */       .description("blockrange"))
/*  29 */       .defaultValue(Integer.valueOf(7)))
/*  30 */       .min(0)
/*  31 */       .sliderMax(100)
/*  32 */       .build());
/*     */   
/*  34 */   public final Setting<Integer> elytraspamdelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  35 */       .name("elytra-spam-delay"))
/*  36 */       .description(""))
/*  37 */       .defaultValue(Integer.valueOf(7)))
/*  38 */       .min(0)
/*  39 */       .sliderMax(100)
/*  40 */       .build());
/*     */   
/*  42 */   public final Setting<Integer> handalternateswingdelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  43 */       .name("hand-swing-switch-delay"))
/*  44 */       .description(""))
/*  45 */       .defaultValue(Integer.valueOf(7)))
/*  46 */       .min(0)
/*  47 */       .sliderMax(100)
/*  48 */       .build());
/*     */   
/*  50 */   public final Setting<Integer> clientoptionswitchhanddelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  51 */       .name("client-option-switch-hand-delay"))
/*  52 */       .description(""))
/*  53 */       .defaultValue(Integer.valueOf(7)))
/*  54 */       .min(0)
/*  55 */       .sliderMax(100)
/*  56 */       .build());
/*     */   
/*  58 */   public final Setting<Integer> skinblinkerdelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  59 */       .name("skin-blinker-delay"))
/*  60 */       .description(""))
/*  61 */       .defaultValue(Integer.valueOf(7)))
/*  62 */       .min(0)
/*  63 */       .sliderMax(100)
/*  64 */       .build());
/*     */   
/*  66 */   public final Setting<Integer> randomrotatedelay = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  67 */       .name("random-rotate-delay"))
/*  68 */       .description("blockrange"))
/*  69 */       .defaultValue(Integer.valueOf(7)))
/*  70 */       .min(0)
/*  71 */       .sliderMax(100)
/*  72 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  76 */   private final Setting<Boolean> skinBlinker = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  77 */       .name("Skin Blinker"))
/*  78 */       .description("Clients will copy the servers sneaking status"))
/*  79 */       .defaultValue(Boolean.valueOf(false)))
/*  80 */       .build());
/*     */ 
/*     */   
/*  83 */   private final Setting<Boolean> randomrotate = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  84 */       .name("random-rotate"))
/*  85 */       .description("Clients will copy the servers sneaking status"))
/*  86 */       .defaultValue(Boolean.valueOf(false)))
/*  87 */       .build());
/*     */ 
/*     */   
/*  90 */   private final Setting<Boolean> sneak = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  91 */       .name("sneak-spam"))
/*  92 */       .description("Clients will copy the servers sneaking status"))
/*  93 */       .defaultValue(Boolean.valueOf(false)))
/*  94 */       .build());
/*     */   
/*  96 */   private final Setting<Boolean> elytraspam = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  97 */       .name("elytra-spam"))
/*  98 */       .description("Clients will copy the servers sneaking status"))
/*  99 */       .defaultValue(Boolean.valueOf(false)))
/* 100 */       .build());
/*     */ 
/*     */   
/* 103 */   private final Setting<Boolean> handalternateswing = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 104 */       .name("hand-swing-switch"))
/* 105 */       .description("Clients will copy the servers sneaking status"))
/* 106 */       .defaultValue(Boolean.valueOf(false)))
/* 107 */       .build());
/*     */ 
/*     */   
/* 110 */   private final Setting<Boolean> clientoptionswitchhand = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 111 */       .name("client-option-switch-hand"))
/* 112 */       .description("Clients will copy the servers sneaking status"))
/* 113 */       .defaultValue(Boolean.valueOf(true)))
/* 114 */       .build()); private int randomrotateticks; private int swinghandswitchticks; private int clientoptionswitchticks; private int elytraspamticks; private int sneakticks;
/*     */   private int skinblinkerticks;
/* 116 */   private final Setting<Boolean> clientoptionswitchhandswing = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/* 117 */       .name("client-option-switch-hand-swing"))
/* 118 */       .description("Clients will copy the servers sneaking status"))
/* 119 */       .defaultValue(Boolean.valueOf(true)))
/* 120 */       .build()); private boolean oldMainArmLeft; private boolean notsneaking; int modelpart; class_1306 lastarm;
/*     */   int lastmodelpart;
/*     */   
/*     */   public FunnyHand() {
/* 124 */     super(AutoplayAddon.autoplay, "funny-hand", "funny handy rotaty elytry sneaky thingy wingy blinky little caesars orgy of zelda switchy");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     this.randomrotateticks = 0;
/* 161 */     this.swinghandswitchticks = 0;
/* 162 */     this.clientoptionswitchticks = 0;
/* 163 */     this.elytraspamticks = 0;
/* 164 */     this.sneakticks = 0;
/* 165 */     this.skinblinkerticks = 0;
/*     */     
/* 167 */     this.oldMainArmLeft = true;
/* 168 */     this.notsneaking = true;
/* 169 */     this.modelpart = -1337;
/*     */     
/* 171 */     this.lastarm = class_1306.field_6183;
/* 172 */     this.lastmodelpart = -1337;
/*     */     MeteorClient.EVENT_BUS.subscribe(new Listener());
/*     */   } @EventHandler
/*     */   public void onTick(TickEvent.Pre event) {
/* 176 */     this.swinghandswitchticks++;
/* 177 */     this.skinblinkerticks++;
/* 178 */     this.clientoptionswitchticks++;
/* 179 */     this.elytraspamticks++;
/* 180 */     this.randomrotateticks++;
/* 181 */     this.sneakticks++;
/*     */     
/* 183 */     if (((Boolean)this.sneak.get()).booleanValue() && 
/* 184 */       this.sneakticks >= ((Integer)this.sneakdelay.get()).intValue()) {
/* 185 */       if (this.notsneaking) {
/* 186 */         PacketUtils.sendPacket((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12979));
/* 187 */         this.notsneaking = false;
/*     */       } else {
/* 189 */         PacketUtils.sendPacket((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12984));
/* 190 */         this.notsneaking = true;
/*     */       } 
/* 192 */       this.sneakticks = 0;
/*     */     } 
/*     */ 
/*     */     
/* 196 */     if (((Boolean)this.elytraspam.get()).booleanValue() && 
/* 197 */       this.elytraspamticks >= ((Integer)this.elytraspamdelay.get()).intValue()) {
/* 198 */       PacketUtils.sendPacket((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12982));
/* 199 */       this.elytraspamticks = 0;
/*     */     } 
/*     */ 
/*     */     
/* 203 */     if ((((Boolean)this.clientoptionswitchhand.get()).booleanValue() || ((Boolean)this.skinBlinker.get()).booleanValue()) && this.modelpart != -1337) {
/* 204 */       int newmodelpart; class_1306 newarm; Boolean packet = Boolean.valueOf(false);
/* 205 */       Boolean doclientoptionswitchhandswing = Boolean.valueOf(false);
/*     */ 
/*     */       
/* 208 */       if (((Boolean)this.skinBlinker.get()).booleanValue()) {
/* 209 */         if (((Integer)this.skinblinkerdelay.get()).intValue() <= this.skinblinkerticks) {
/* 210 */           this.skinblinkerticks = 0;
/* 211 */           packet = Boolean.valueOf(true);
/* 212 */           newmodelpart = (new Random()).nextInt(128);
/* 213 */           this.lastmodelpart = newmodelpart;
/*     */         } else {
/* 215 */           newmodelpart = this.lastmodelpart;
/*     */         } 
/*     */       } else {
/* 218 */         newmodelpart = this.modelpart;
/*     */       } 
/* 220 */       if (((Boolean)this.clientoptionswitchhand.get()).booleanValue()) {
/* 221 */         if (((Integer)this.clientoptionswitchhanddelay.get()).intValue() <= this.clientoptionswitchticks) {
/* 222 */           this.clientoptionswitchticks = 0;
/* 223 */           if (this.lastarm == class_1306.field_6183) {
/* 224 */             newarm = class_1306.field_6182;
/* 225 */             this.lastarm = class_1306.field_6182;
/*     */           } else {
/* 227 */             newarm = class_1306.field_6183;
/* 228 */             this.lastarm = class_1306.field_6183;
/*     */           } 
/* 230 */           packet = Boolean.valueOf(true);
/* 231 */           if (((Boolean)this.clientoptionswitchhandswing.get()).booleanValue()) {
/* 232 */             doclientoptionswitchhandswing = Boolean.valueOf(true);
/*     */           }
/*     */         } else {
/* 235 */           newarm = this.lastarm;
/*     */         } 
/*     */       } else {
/* 238 */         newarm = (class_1306)this.mc.field_1690.method_42552().method_41753();
/*     */       } 
/* 240 */       if (packet.booleanValue()) {
/* 241 */         int renderdistance = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/* 242 */         String language = this.mc.field_1690.field_1883;
/* 243 */         PacketUtils.sendPacket((class_2596)new class_2803(new class_8791(language, renderdistance, (class_1659)this.mc.field_1690.method_42539().method_41753(), ((Boolean)this.mc.field_1690.method_42427().method_41753()).booleanValue(), newmodelpart, newarm, this.mc.method_33883(), ((Boolean)this.mc.field_1690.method_42441().method_41753()).booleanValue())));
/* 244 */         if (doclientoptionswitchhandswing.booleanValue()) {
/* 245 */           PacketUtils.sendPacket((class_2596)new class_2879(class_1268.field_5808));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 250 */     if (((Boolean)this.randomrotate.get()).booleanValue() && (
/* 251 */       (Integer)this.randomrotatedelay.get()).intValue() <= this.randomrotateticks) {
/* 252 */       this.randomrotateticks = 0;
/* 253 */       Random random = new Random();
/* 254 */       float pitch = -90.0F + random.nextFloat() * 180.0F;
/* 255 */       float yaw = -180.0F + random.nextFloat() * 360.0F;
/* 256 */       PacketUtils.sendPacket((class_2596)new class_2828.class_2831(yaw, pitch, this.mc.field_1724.method_24828()));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 261 */     if (((Boolean)this.handalternateswing.get()).booleanValue() && this.swinghandswitchticks >= ((Integer)this.handalternateswingdelay.get()).intValue()) {
/* 262 */       if (this.oldMainArmLeft) {
/* 263 */         PacketUtils.sendPacket((class_2596)new class_2879(class_1268.field_5810));
/* 264 */         this.oldMainArmLeft = false;
/*     */       } else {
/* 266 */         PacketUtils.sendPacket((class_2596)new class_2879(class_1268.field_5808));
/* 267 */         this.oldMainArmLeft = true;
/*     */       } 
/* 269 */       this.swinghandswitchticks = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   private class Listener {
/*     */     @EventHandler
/*     */     private void onSendPacket(PacketEvent.Send event) {
/*     */       if (event.packet instanceof class_2803) {
/*     */         class_2803 packet = (class_2803)event.packet;
/*     */         FunnyHand.this.modelpart = packet.comp_1963().comp_1955();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onSendPacket(PacketEvent.Receive event) {
/*     */     if (((Boolean)this.randomrotate.get()).booleanValue() && event.packet instanceof class_2828) {
/*     */       class_2828 packet = (class_2828)event.packet;
/*     */       if (packet instanceof class_2828.class_2831 || packet instanceof class_2828.class_2830) {
/*     */         PlayerMoveC2SPacketMixin accessor = (PlayerMoveC2SPacketMixin)event.packet;
/*     */         Random random = new Random();
/*     */         float pitch = -90.0F + random.nextFloat() * 180.0F;
/*     */         float yaw = -180.0F + random.nextFloat() * 360.0F;
/*     */         accessor.setPitch(pitch);
/*     */         accessor.setYaw(yaw);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onRecievePacket(PacketEvent.Receive event) {
/*     */     if (event.packet instanceof class_2739) {
/*     */       class_2739 packet = (class_2739)event.packet;
/*     */       if (this.mc.field_1724.method_5628() == packet.comp_1127())
/*     */         event.cancel(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\FunnyHand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */