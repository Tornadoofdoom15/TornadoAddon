/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.AutoPlay.Other.RandomTp;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.IntSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2708;
/*    */ import net.minecraft.class_2793;
/*    */ import net.minecraft.class_2828;
/*    */ 
/*    */ public class ScardyCat extends Module {
/*    */   private final SettingGroup sgGeneral;
/*    */   
/*    */   public ScardyCat() {
/* 25 */     super(AutoplayAddon.autoplay, "scardey-cat", "i changedc this to what it says it does");
/*    */ 
/*    */     
/* 28 */     this.sgGeneral = this.settings.getDefaultGroup();
/*    */     
/* 30 */     this.distance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/* 31 */         .name("distance-from-player"))
/* 32 */         .description("How much distance in each teleport?"))
/* 33 */         .defaultValue(Integer.valueOf(20)))
/* 34 */         .min(0)
/* 35 */         .sliderMax(300)
/* 36 */         .build());
/*    */   }
/*    */   private final Setting<Integer> distance;
/*    */   
/*    */   public void onActivate() {
/* 41 */     randomtp();
/*    */   }
/*    */   
/*    */   @EventHandler(priority = 200)
/*    */   private static void onRecievePacket(PacketEvent.Receive event) {
/* 46 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2708) { class_2708 packet = (class_2708)class_2596;
/* 47 */       PacketUtils.sendPacket((class_2596)new class_2793(packet.method_11737()));
/* 48 */       event.cancel(); }
/*    */   
/*    */   }
/*    */   
/*    */   @EventHandler(priority = 200)
/*    */   private static void onSendPacket(PacketEvent.Send event) {
/* 54 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2828) { class_2828 packet = (class_2828)class_2596;
/* 55 */       event.cancel(); }
/*    */   
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onTick(TickEvent.Pre event) {
/* 61 */     randomtp();
/*    */   }
/*    */   
/*    */   private void randomtp() {
/* 65 */     class_243 tppos = RandomTp.findValidTpPos(this.mc.field_1724.method_19538(), ((Integer)this.distance.get()).intValue());
/* 66 */     if (tppos == null) {
/* 67 */       ChatUtils.error("Failed to find a position to teleport to!", new Object[0]);
/*    */       return;
/*    */     } 
/* 70 */     Movement.setPos(tppos, false, null, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\ScardyCat.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */