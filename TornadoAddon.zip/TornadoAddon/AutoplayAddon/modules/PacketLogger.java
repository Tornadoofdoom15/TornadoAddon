/*     */ package AutoplayAddon.modules;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Set;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.PacketListSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.network.PacketUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2596;
/*     */ 
/*     */ public class PacketLogger extends Module {
/*     */   private final SettingGroup sgGeneral;
/*     */   private final Setting<Set<Class<? extends class_2596<?>>>> recievedpackets;
/*     */   
/*     */   public PacketLogger() {
/*  19 */     super(AutoplayAddon.autoplay, "packet-logger", "cock and ball torture");
/*     */ 
/*     */     
/*  22 */     this.sgGeneral = this.settings.getDefaultGroup();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  31 */     this.recievedpackets = this.sgGeneral.add((Setting)((PacketListSetting.Builder)((PacketListSetting.Builder)(new PacketListSetting.Builder())
/*  32 */         .name("S2C-packets"))
/*  33 */         .description("Server-to-client packets to cancel."))
/*  34 */         .filter(aClass -> PacketUtils.getS2CPackets().contains(aClass))
/*  35 */         .build());
/*     */ 
/*     */     
/*  38 */     this.sentpackets = this.sgGeneral.add((Setting)((PacketListSetting.Builder)((PacketListSetting.Builder)(new PacketListSetting.Builder())
/*  39 */         .name("C2S-packets"))
/*  40 */         .description("Client-to-server packets to cancel."))
/*  41 */         .filter(aClass -> PacketUtils.getC2SPackets().contains(aClass))
/*  42 */         .build());
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.sentmode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  47 */         .name("sent-print-mode"))
/*  48 */         .description("The formation mode, either line or circle."))
/*  49 */         .defaultValue(PacketMode.All))
/*  50 */         .build());
/*     */ 
/*     */     
/*  53 */     this.recievedmode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  54 */         .name("recieved-print-mode"))
/*  55 */         .description("The formation mode, either line or circle."))
/*  56 */         .defaultValue(PacketMode.All))
/*  57 */         .build());
/*     */   } private final Setting<Set<Class<? extends class_2596<?>>>> sentpackets; private final Setting<PacketMode> sentmode; private final Setting<PacketMode> recievedmode; public enum PacketMode {
/*     */     None, All, Whitelist, Blacklist; } @EventHandler
/*     */   private void onReceivePacket(PacketEvent.Receive event) {
/*  61 */     class_2596<?> packet = event.packet;
/*  62 */     switch ((PacketMode)this.recievedmode.get()) {
/*     */ 
/*     */       
/*     */       case All:
/*  66 */         logPacketFields(packet, "Received");
/*     */         break;
/*     */       case Whitelist:
/*  69 */         if (((Set)this.recievedpackets.get()).contains(packet.getClass())) {
/*  70 */           logPacketFields(packet, "Received");
/*     */         }
/*     */         break;
/*     */       case Blacklist:
/*  74 */         if (!((Set)this.recievedpackets.get()).contains(packet.getClass())) {
/*  75 */           logPacketFields(packet, "Received");
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onSendPacket(PacketEvent.Send event) {
/*  83 */     class_2596<?> packet = event.packet;
/*     */     
/*  85 */     switch ((PacketMode)this.sentmode.get()) {
/*     */ 
/*     */       
/*     */       case All:
/*  89 */         logPacketFields(packet, "Sent");
/*     */         break;
/*     */       case Whitelist:
/*  92 */         if (((Set)this.sentpackets.get()).contains(packet.getClass())) {
/*  93 */           logPacketFields(packet, "Sent");
/*     */         }
/*     */         break;
/*     */       case Blacklist:
/*  97 */         if (!((Set)this.sentpackets.get()).contains(packet.getClass()))
/*  98 */           logPacketFields(packet, "Sent"); 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logPacketFields(class_2596<?> packet, String action) {
/* 104 */     StringBuilder logMessage = new StringBuilder(action + " packet: " + action + " ");
/* 105 */     Set<Integer> visited = new HashSet<>();
/* 106 */     recursivelyLogFields(packet, logMessage, packet.getClass(), visited, false);
/* 107 */     ChatUtils.info(logMessage.toString(), new Object[0]);
/*     */   }
/*     */   
/*     */   private void recursivelyLogFields(Object obj, StringBuilder logMessage, Class<?> clazz, Set<Integer> visited, boolean addComma) {
/* 111 */     if (obj == null || visited.contains(Integer.valueOf(System.identityHashCode(obj)))) {
/*     */       return;
/*     */     }
/* 114 */     visited.add(Integer.valueOf(System.identityHashCode(obj)));
/*     */ 
/*     */     
/* 117 */     while (clazz != null && clazz != Object.class) {
/* 118 */       Field[] fields = clazz.getDeclaredFields();
/* 119 */       for (Field field : fields) {
/* 120 */         field.setAccessible(true);
/*     */         try {
/* 122 */           Object value = field.get(obj);
/* 123 */           if (addComma) {
/* 124 */             logMessage.append(", ");
/*     */           } else {
/* 126 */             addComma = true;
/*     */           } 
/*     */           
/* 129 */           logMessage.append(field.getName()).append(": ");
/* 130 */           if (isComplexObject(value)) {
/* 131 */             if (overridesToString(value)) {
/* 132 */               logMessage.append(value.toString());
/*     */             } else {
/* 134 */               logMessage.append("{");
/* 135 */               recursivelyLogFields(value, logMessage, value.getClass(), visited, false);
/* 136 */               logMessage.append("}");
/*     */             } 
/*     */           } else {
/* 139 */             logMessage.append(value);
/*     */           } 
/* 141 */         } catch (IllegalAccessException e) {
/* 142 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/* 145 */       clazz = clazz.getSuperclass();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isComplexObject(Object obj) {
/* 152 */     return ((obj != null && !(obj instanceof String) && !(obj instanceof Number) && !(obj instanceof Boolean) && !(obj instanceof Character) && 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 157 */       !obj.getClass().isEnum()) || obj instanceof net.minecraft.class_1914);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean overridesToString(Object obj) {
/*     */     try {
/* 163 */       return !obj.getClass().getMethod("toString", new Class[0]).getDeclaringClass().equals(Object.class);
/* 164 */     } catch (NoSuchMethodException e) {
/* 165 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\PacketLogger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */