/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.Random;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.settings.StringSetting;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ 
/*     */ public class Follower extends Module {
/*  20 */   private double lastAngle = 0.0D; private final Setting<String> stringtype;
/*     */   private final Setting<Mode> mode;
/*  22 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup(); private final Setting<Integer> distance;
/*     */   public Follower() {
/*  24 */     super(AutoplayAddon.autoplay, "follower", "Example");
/*     */     
/*  26 */     this.stringtype = this.sgGeneral.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder())
/*  27 */         .name("player-name"))
/*  28 */         .description("Player to follow."))
/*  29 */         .defaultValue(""))
/*  30 */         .build());
/*     */ 
/*     */     
/*  33 */     this.mode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  34 */         .name("mode"))
/*  35 */         .description("The follow mode."))
/*  36 */         .defaultValue(Mode.HorizontalCircle))
/*  37 */         .build());
/*     */ 
/*     */     
/*  40 */     this.distance = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  41 */         .name("distance-from-player"))
/*  42 */         .description("How much distance in each teleport?"))
/*  43 */         .defaultValue(Integer.valueOf(20)))
/*  44 */         .min(0)
/*  45 */         .sliderMax(300)
/*  46 */         .build());
/*     */     
/*  48 */     this.spinsppeed = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  49 */         .name("speed"))
/*  50 */         .description("How much distance in each teleport?"))
/*  51 */         .defaultValue(Integer.valueOf(20)))
/*  52 */         .min(1)
/*  53 */         .sliderMax(300)
/*  54 */         .build());
/*     */   }
/*     */   private final Setting<Integer> spinsppeed;
/*  57 */   public enum Mode { Follow,
/*  58 */     StareAt,
/*  59 */     UpandDown,
/*  60 */     VerticalCircle,
/*  61 */     HorizontalCircle,
/*  62 */     RandomSphere,
/*  63 */     BlowJob; }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*  69 */     String targetName = (String)this.stringtype.get();
/*  70 */     if (targetName.isEmpty())
/*  71 */       return;  for (class_1297 entity : this.mc.field_1687.method_18112()) {
/*  72 */       if (entity instanceof class_1657) { class_1657 targetPlayer = (class_1657)entity;
/*  73 */         if (targetName.equals(targetPlayer.method_7334().getName())) {
/*  74 */           handlePlayerMovement(targetPlayer);
/*     */           break;
/*     */         }  }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handlePlayerMovement(class_1657 targetPlayer) {
/*  82 */     class_243 desiredPos, centerPos = roundToDecimal(targetPlayer.method_19538(), 3);
/*     */ 
/*     */     
/*  85 */     if (this.mode.get() == Mode.StareAt) {
/*  86 */       desiredPos = getDesiredStareAtPosition(targetPlayer, centerPos);
/*  87 */     } else if (this.mode.get() == Mode.Follow) {
/*  88 */       desiredPos = centerPos;
/*     */     } else {
/*  90 */       desiredPos = getDesiredPositionBasedOnMode(centerPos);
/*     */     } 
/*     */     
/*  93 */     if (desiredPos != null) {
/*  94 */       class_243 newpos = new class_243(desiredPos.field_1352, Math.max(desiredPos.field_1351, -115.0D), desiredPos.field_1350);
/*  95 */       Movement.setPos(newpos, true, null, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private class_243 getDesiredStareAtPosition(class_1657 targetPlayer, class_243 centerPos) {
/* 100 */     class_243 lookDirection = targetPlayer.method_5720();
/* 101 */     for (int i = ((Integer)this.distance.get()).intValue(); i >= 0; i--) {
/* 102 */       class_243 tempPos = centerPos.method_1019(lookDirection.method_1021(i));
/* 103 */       if (isBoxEmpty(tempPos).booleanValue()) return tempPos; 
/*     */     } 
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   private class_243 getDesiredPositionBasedOnMode(class_243 centerPos) {
/* 109 */     double incrementInRadians = ((Integer)this.spinsppeed.get()).intValue() * 0.00175D;
/* 110 */     this.lastAngle = (this.lastAngle + incrementInRadians) % 6.283185307179586D;
/*     */     
/* 112 */     class_243 tempPos = getPositionBasedOnAngleAndMode(centerPos, this.lastAngle);
/* 113 */     if (isBoxEmpty(tempPos).booleanValue()) {
/* 114 */       return tempPos;
/*     */     }
/*     */ 
/*     */     
/* 118 */     double initialAngle = this.lastAngle;
/* 119 */     double angle = initialAngle;
/* 120 */     int maxIterations = 36;
/* 121 */     int iterationCount = 0;
/*     */     
/* 123 */     while (iterationCount < maxIterations) {
/* 124 */       tempPos = getPositionBasedOnAngleAndMode(centerPos, angle);
/* 125 */       if (isBoxEmpty(tempPos).booleanValue()) {
/*     */         
/* 127 */         this.lastAngle = angle;
/* 128 */         return tempPos;
/*     */       } 
/*     */ 
/*     */       
/* 132 */       angle = (angle + 0.08726646259971647D) % 6.283185307179586D;
/* 133 */       iterationCount++;
/*     */     } 
/*     */     
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class_243 getPositionBasedOnAngleAndMode(class_243 centerPos, double angle) {
/* 142 */     if (this.mode.get() == Mode.RandomSphere) {
/* 143 */       Random random = new Random();
/* 144 */       double phi = 6.283185307179586D * random.nextDouble();
/* 145 */       double theta = Math.acos(2.0D * random.nextDouble() - 1.0D);
/* 146 */       double radius = ((Integer)this.distance.get()).intValue();
/* 147 */       double d1 = radius * Math.sin(theta) * Math.cos(phi);
/* 148 */       double dy = radius * Math.sin(theta) * Math.sin(phi);
/* 149 */       double d2 = radius * Math.cos(theta);
/* 150 */       return new class_243(centerPos.field_1352 + d1, centerPos.field_1351 + dy, centerPos.field_1350 + d2);
/*     */     } 
/*     */     
/* 153 */     double dx = Math.cos(angle) * ((Integer)this.distance.get()).intValue();
/* 154 */     double dz = Math.sin(angle) * ((Integer)this.distance.get()).intValue();
/*     */     
/* 156 */     if (this.mode.get() == Mode.HorizontalCircle)
/* 157 */       return new class_243(centerPos.field_1352 + dx, centerPos.field_1351, centerPos.field_1350 + dz); 
/* 158 */     if (this.mode.get() == Mode.VerticalCircle)
/* 159 */       return new class_243(centerPos.field_1352, centerPos.field_1351 + dx, centerPos.field_1350 + dz); 
/* 160 */     if (this.mode.get() == Mode.UpandDown) {
/* 161 */       return new class_243(centerPos.field_1352, centerPos.field_1351 + dx, centerPos.field_1350);
/*     */     }
/*     */ 
/*     */     
/* 165 */     return centerPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Boolean isBoxEmpty(class_243 pos) {
/* 175 */     class_238 box = new class_238(pos.field_1352 - (this.mc.field_1724.method_17681() / 2.0F), pos.field_1351, pos.field_1350 - (this.mc.field_1724.method_17681() / 2.0F), pos.field_1352 + (this.mc.field_1724.method_17681() / 2.0F), pos.field_1351 + this.mc.field_1724.method_17682(), pos.field_1350 + (this.mc.field_1724.method_17681() / 2.0F));
/*     */     
/* 177 */     return Boolean.valueOf(this.mc.field_1687.method_18026(box));
/*     */   }
/*     */   
/*     */   private class_243 roundToDecimal(class_243 vector, int decimalPlaces) {
/* 181 */     double roundedX = roundToDecimal(vector.field_1352, decimalPlaces);
/* 182 */     double roundedY = roundToDecimal(vector.field_1351, decimalPlaces);
/* 183 */     double roundedZ = roundToDecimal(vector.field_1350, decimalPlaces);
/* 184 */     return new class_243(roundedX, roundedY, roundedZ);
/*     */   }
/*     */   
/*     */   private double roundToDecimal(double value, int decimalPlaces) {
/* 188 */     BigDecimal bd = new BigDecimal(Double.toString(value));
/* 189 */     bd = bd.setScale(decimalPlaces, RoundingMode.HALF_UP);
/* 190 */     return bd.doubleValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Follower.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */