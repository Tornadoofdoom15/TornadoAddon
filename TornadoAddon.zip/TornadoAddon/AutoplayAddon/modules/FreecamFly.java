/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*     */ import AutoplayAddon.AutoPlay.Other.FastBox;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.systems.modules.Modules;
/*     */ import meteordevelopment.meteorclient.systems.modules.render.Freecam;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2708;
/*     */ import net.minecraft.class_2793;
/*     */ import net.minecraft.class_2828;
/*     */ import net.minecraft.class_4184;
/*     */ 
/*     */ public class FreecamFly extends Module {
/*     */   class_243 clientsidedposition;
/*     */   private final SettingGroup sgGeneral;
/*     */   
/*     */   public FreecamFly() {
/*  28 */     super(AutoplayAddon.autoplay, "freecam-fly", "Example");
/*     */     
/*  30 */     this.clientsidedposition = null;
/*  31 */     this.sgGeneral = this.settings.getDefaultGroup();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  37 */     this.followermode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  38 */         .name("server-pos-mode"))
/*  39 */         .description("The formation mode, either line or circle."))
/*  40 */         .defaultValue(FollowerMode.FollowCamera))
/*  41 */         .build());
/*     */     
/*  43 */     this.yheight = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  44 */         .name("y-level-height"))
/*  45 */         .description("test"))
/*  46 */         .defaultValue(Integer.valueOf(400)))
/*  47 */         .min(-120)
/*  48 */         .sliderMax(36000)
/*  49 */         .visible(() -> (this.followermode.get() == FollowerMode.Y_Level)))
/*  50 */         .build());
/*     */   }
/*     */   private final Setting<FollowerMode> followermode; public final Setting<Integer> yheight;
/*     */   public enum FollowerMode {
/*     */     FollowCamera, Y_Level; }
/*     */   public void onActivate() {
/*  56 */     Freecam freecam = (Freecam)Modules.get().get(Freecam.class);
/*  57 */     this.clientsidedposition = null;
/*  58 */     if (!freecam.isActive()) {
/*  59 */       freecam.toggle();
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority = 200)
/*     */   private static void onRecievePacket(PacketEvent.Receive event) {
/*  65 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2708) { class_2708 packet = (class_2708)class_2596;
/*  66 */       PacketUtils.sendPacket((class_2596)new class_2793(packet.method_11737()));
/*  67 */       Freecam freecam = (Freecam)Modules.get().get(Freecam.class);
/*  68 */       freecam.pos.set(packet.method_11734(), freecam.pos.y, packet.method_11738());
/*  69 */       event.cancel(); }
/*     */   
/*     */   }
/*     */   
/*     */   @EventHandler(priority = 203)
/*     */   private static void onSendPacket(PacketEvent.Send event) {
/*  75 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2828) { class_2828 packet = (class_2828)class_2596;
/*  76 */       event.cancel(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeactivate() {
/*  82 */     class_4184 camera = this.mc.field_1773.method_19418();
/*  83 */     class_243 cameraPos = camera.method_19326();
/*  84 */     class_243 playerPos = new class_243(cameraPos.field_1352, cameraPos.field_1351 - this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()), cameraPos.field_1350);
/*  85 */     Movement.setPos(playerPos, true, Float.valueOf(camera.method_19329()), Float.valueOf(camera.method_19330()));
/*  86 */     Module freecam = Modules.get().get(Freecam.class);
/*  87 */     if (freecam.isActive()) freecam.toggle(); 
/*     */   }
/*     */   
/*     */   @EventHandler(priority = 203)
/*     */   private void onTick(TickEvent.Pre event) {
/*     */     class_243 tpPos;
/*  93 */     Freecam freecam = (Freecam)Modules.get().get(Freecam.class);
/*  94 */     if (!freecam.isActive()) freecam.toggle();
/*     */ 
/*     */     
/*  97 */     if (this.followermode.get() == FollowerMode.Y_Level) {
/*  98 */       tpPos = new class_243(freecam.pos.x, ((Integer)this.yheight.get()).intValue(), freecam.pos.z);
/*     */     } else {
/* 100 */       tpPos = new class_243(freecam.pos.x, freecam.pos.y - this.mc.field_1724.method_18381(this.mc.field_1724.method_18376()), freecam.pos.z);
/*     */     } 
/*     */     
/* 103 */     if (ServerSideValues.serversidedposition.field_1352 == tpPos.field_1352 && ServerSideValues.serversidedposition.field_1351 == tpPos.field_1351 && ServerSideValues.serversidedposition.field_1350 == tpPos.field_1350)
/*     */       return; 
/* 105 */     if (this.followermode.get() == FollowerMode.FollowCamera) {
/* 106 */       if (this.clientsidedposition == null) { this.mc.field_1724.method_5814(tpPos.field_1352, 10000.0D, tpPos.field_1350); }
/* 107 */       else { this.mc.field_1724.method_5814(this.clientsidedposition.field_1352, this.clientsidedposition.field_1351, this.clientsidedposition.field_1350); }
/* 108 */        if (this.followermode.get() == FollowerMode.FollowCamera) {
/* 109 */         FastBox fatsbox = new FastBox(tpPos);
/* 110 */         if (!fatsbox.isCollidingWithBlocks()) {
/* 111 */           this.clientsidedposition = null;
/*     */         } else {
/* 113 */           this.clientsidedposition = ServerSideValues.serversidedposition;
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 118 */       this.mc.field_1724.method_33574(tpPos);
/*     */     } 
/* 120 */     Movement.setPos(tpPos, false, null, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\FreecamFly.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */