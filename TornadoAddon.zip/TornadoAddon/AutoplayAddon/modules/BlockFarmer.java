/*     */ package AutoplayAddon.modules;
/*     */ import AutoplayAddon.AutoplayAddon;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BlockListSetting;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.player.InvUtils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2846;
/*     */ import net.minecraft.class_2885;
/*     */ 
/*     */ public class BlockFarmer extends Module {
/*  30 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*  31 */   private final Setting<Boolean> what = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  32 */       .name("break-block"))
/*  33 */       .description("Renders a block overlay where you will be teleported."))
/*  34 */       .defaultValue(Boolean.valueOf(true)))
/*  35 */       .build());
/*     */   
/*  37 */   private final Setting<List<class_2248>> block = this.sgGeneral.add((Setting)((BlockListSetting.Builder)((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder())
/*  38 */       .name("target-Block"))
/*  39 */       .description("The block you want to break."))
/*     */       
/*  41 */       .defaultValue(List.of(class_2246.field_10443)))
/*  42 */       .build());
/*     */ 
/*     */   
/*  45 */   private final Setting<Boolean> autoswitch = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  46 */       .name("auto-switch"))
/*  47 */       .description("Automatically puts the block in your offhand."))
/*  48 */       .defaultValue(Boolean.valueOf(true)))
/*  49 */       .build());
/*     */   
/*  51 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*     */   
/*  53 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  54 */       .name("shape-mode"))
/*  55 */       .description("How the shapes are rendered."))
/*  56 */       .defaultValue(ShapeMode.Both))
/*  57 */       .build());
/*     */ 
/*     */   
/*  60 */   private final Setting<SettingColor> sideColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  61 */       .name("side-color"))
/*  62 */       .description("The color of the sides of the blocks being rendered."))
/*  63 */       .defaultValue(new SettingColor(204, 0, 0, 10))
/*  64 */       .build());
/*     */ 
/*     */   
/*  67 */   private final Setting<SettingColor> lineColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  68 */       .name("line-color"))
/*  69 */       .description("The color of the lines of the blocks being rendered."))
/*  70 */       .defaultValue(new SettingColor(204, 0, 0, 255))
/*  71 */       .build());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private class_2338 blockPos = new class_2338(0, -1, 0);
/*  78 */   private class_2350 direction = class_2350.field_11036;
/*     */   
/*     */   public BlockFarmer() {
/*  81 */     super(AutoplayAddon.autoplay, "block-farmer", "Attempts to instantly mine blocks.");
/*     */   }
/*     */ 
/*     */   
/*     */   public void onActivate() {
/*  86 */     this.blockPos = null;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onStartBreakingBlock(StartBreakingBlockEvent event) {
/*  91 */     ChatUtils.info("Start breaking block event", new Object[0]);
/*  92 */     this.direction = event.direction;
/*  93 */     this.blockPos = event.blockPos;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*  98 */     if (this.blockPos == null)
/*  99 */       return;  class_1799 offhandStack = this.mc.field_1724.method_6079();
/* 100 */     if (((Boolean)this.autoswitch.get()).booleanValue() && offhandStack.method_7960()) {
/* 101 */       int slot = findTargetBlock();
/* 102 */       if (slot != -1) {
/* 103 */         InvUtils.move().from(slot).to(45);
/*     */       }
/*     */     } 
/*     */     
/* 107 */     while (ServerSideValues.canPlace()) {
/* 108 */       if (((Boolean)this.what.get()).booleanValue()) {
/* 109 */         this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12973, this.blockPos, this.direction));
/*     */       }
/* 111 */       this.mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5810, new class_3965(this.blockPos.method_46558(), this.direction, this.blockPos, false), 0));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int findTargetBlock() {
/* 117 */     for (class_2248 targetBlock : this.block.get()) {
/* 118 */       class_1792 targetItem = targetBlock.method_8389();
/* 119 */       for (int i = 0; i < this.mc.field_1724.method_31548().method_5439(); i++) {
/* 120 */         class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
/* 121 */         if (stack.method_7909() == targetItem) {
/* 122 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 126 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 133 */     if (this.blockPos == null)
/* 134 */       return;  event.renderer.box(this.blockPos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\BlockFarmer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */