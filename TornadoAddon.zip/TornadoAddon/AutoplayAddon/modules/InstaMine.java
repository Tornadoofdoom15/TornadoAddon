/*    */ package AutoplayAddon.modules;
/*    */ import meteordevelopment.meteorclient.events.entity.player.StartBreakingBlockEvent;
/*    */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*    */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*    */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*    */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*    */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2846;
/*    */ 
/*    */ public class InstaMine extends Module {
/* 17 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/* 18 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*    */   
/* 20 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/* 21 */       .name("shape-mode"))
/* 22 */       .description("How the shapes are rendered."))
/* 23 */       .defaultValue(ShapeMode.Both))
/* 24 */       .build());
/*    */ 
/*    */   
/* 27 */   private final Setting<SettingColor> sideColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/* 28 */       .name("side-color"))
/* 29 */       .description("The color of the sides of the blocks being rendered."))
/* 30 */       .defaultValue(new SettingColor(204, 0, 0, 10))
/* 31 */       .build());
/*    */ 
/*    */   
/* 34 */   private final Setting<SettingColor> lineColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/* 35 */       .name("line-color"))
/* 36 */       .description("The color of the lines of the blocks being rendered."))
/* 37 */       .defaultValue(new SettingColor(204, 0, 0, 255))
/* 38 */       .build());
/*    */ 
/*    */   
/* 41 */   private class_2338 blockPos = new class_2338(0, -1, 0);
/* 42 */   private class_2350 direction = class_2350.field_11036;
/*    */   
/*    */   public InstaMine() {
/* 45 */     super(AutoplayAddon.autoplay, "insta-mine1", "Attempts to instantly mine blocks.");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onActivate() {
/* 50 */     this.blockPos = null;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   private void onStartBreakingBlock(StartBreakingBlockEvent event) {
/* 55 */     ChatUtils.info("Start breaking block event", new Object[0]);
/* 56 */     this.direction = event.direction;
/* 57 */     this.blockPos = event.blockPos;
/* 58 */     event.cancel();
/* 59 */     this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12968, this.blockPos, this.direction));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   private void onRender(Render3DEvent event) {
/* 67 */     if (this.blockPos == null)
/* 68 */       return;  event.renderer.box(this.blockPos, (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\InstaMine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */