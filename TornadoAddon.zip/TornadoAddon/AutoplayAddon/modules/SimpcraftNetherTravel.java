/*    */ package AutoplayAddon.modules;
/*    */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import AutoplayAddon.Tracker.ServerSideValues;
/*    */ import meteordevelopment.meteorclient.events.packets.PacketEvent;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.BlockPosSetting;
/*    */ import meteordevelopment.meteorclient.settings.IntSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.systems.modules.Modules;
/*    */ import meteordevelopment.meteorclient.systems.modules.movement.Flight;
/*    */ import meteordevelopment.meteorclient.systems.waypoints.Waypoint;
/*    */ import meteordevelopment.meteorclient.systems.waypoints.Waypoints;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2828;
/*    */ 
/*    */ public class SimpcraftNetherTravel extends Module {
/*    */   private final SettingGroup sgGeneral;
/*    */   
/*    */   public SimpcraftNetherTravel() {
/* 26 */     super(AutoplayAddon.autoplay, "SimpcraftNetherTravel", "Attempts to instantly mine blocks.");
/*    */     
/* 28 */     this.sgGeneral = this.settings.getDefaultGroup();
/*    */     
/* 30 */     this.pos = this.sgGeneral.add((Setting)((BlockPosSetting.Builder)((BlockPosSetting.Builder)((BlockPosSetting.Builder)(new BlockPosSetting.Builder())
/* 31 */         .name("Destination"))
/* 32 */         .description("The location of the waypoint."))
/* 33 */         .defaultValue(class_2338.field_10980))
/* 34 */         .build());
/*    */     
/* 36 */     this.blocks = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/* 37 */         .name("Distance between tps"))
/* 38 */         .description("How much distance in each teleport?"))
/* 39 */         .defaultValue(Integer.valueOf(120)))
/* 40 */         .min(0)
/* 41 */         .sliderMax(300)
/* 42 */         .build());
/*    */   }
/*    */   public final Setting<class_2338> pos; private final Setting<Integer> blocks;
/*    */   
/*    */   @EventHandler
/*    */   public void onTick(TickEvent.Post event) {
/* 48 */     for (Waypoint waypoint : Waypoints.get()) {
/* 49 */       waypoint.getPos();
/*    */     }
/*    */ 
/*    */     
/* 53 */     class_243 tickpos = ServerSideValues.tickpos;
/* 54 */     if (tickpos.field_1351 < 128.0D) {
/* 55 */       simpletp(tickpos, new class_243(tickpos.field_1352, 128.5D, tickpos.field_1350));
/*    */     }
/* 57 */     class_243 newpos = ServerSideValues.serversidedposition;
/* 58 */     class_243 temp1 = (new class_243(((class_2338)this.pos.get()).method_10263() - newpos.field_1352, 0.0D, ((class_2338)this.pos.get()).method_10260() - newpos.field_1350)).method_1029().method_1021(((Integer)this.blocks.get()).intValue());
/* 59 */     double xpos = newpos.field_1352 + temp1.field_1352;
/* 60 */     double zpos = newpos.field_1350 + temp1.field_1350;
/* 61 */     class_243 temp2 = new class_243(xpos, 128.5D, zpos);
/* 62 */     simpletp(newpos, temp2);
/*    */     
/* 64 */     class_2338 destination = (class_2338)this.pos.get();
/* 65 */     class_243 currentPos = ServerSideValues.serversidedposition;
/* 66 */     double distance = Math.sqrt(Math.pow(destination.method_10263() - currentPos.field_1352, 2.0D) + Math.pow(destination.method_10260() - currentPos.field_1350, 2.0D));
/*    */     
/* 68 */     if (distance <= 5.0D) {
/*    */       
/* 70 */       this.pos.set(new class_2338(0, 0, 0));
/* 71 */       ChatUtils.info("You have arrived at your destination!", new Object[0]);
/* 72 */       Module flight = Modules.get().get(Flight.class);
/* 73 */       if (!flight.isActive()) {
/* 74 */         flight.toggle();
/*    */       }
/* 76 */       toggle();
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler(priority = 201)
/*    */   private void onSendPacket(PacketEvent.Send event) {
/* 82 */     if (event.packet instanceof class_2828.class_2829 || event.packet instanceof class_2828.class_2830 || event.packet instanceof class_2828.class_2831 || event.packet instanceof class_2828.class_5911)
/* 83 */       event.cancel(); 
/*    */   }
/*    */   
/*    */   private void simpletp(class_243 currentpos, class_243 pos) {
/* 87 */     double distance = currentpos.method_1022(pos);
/* 88 */     int packetsRequired = (int)Math.ceil(Math.abs(distance / 10.0D)) - 1;
/* 89 */     PacketUtils.packetQueue.clear();
/* 90 */     for (int packetNumber = 0; packetNumber < packetsRequired; packetNumber++) {
/* 91 */       class_2828.class_5911 class_5911 = new class_2828.class_5911(true);
/* 92 */       PacketUtils.packetQueue.add(class_5911);
/*    */     } 
/* 94 */     class_2828.class_2829 class_2829 = new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, true);
/* 95 */     PacketUtils.packetQueue.add(class_2829);
/* 96 */     PacketUtils.sendAllPacketsInQueue();
/* 97 */     ServerSideValues.serversidedposition = pos;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\SimpcraftNetherTravel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */