/*    */ package AutoplayAddon.modules;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import AutoplayAddon.AutoPlay.Other.FastBox;
/*    */ import AutoplayAddon.AutoplayAddon;
/*    */ import meteordevelopment.meteorclient.settings.KeybindSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.utils.misc.Keybind;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2374;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_4184;
/*    */ 
/*    */ public class Door extends Module {
/*    */   private final SettingGroup sgGeneral;
/*    */   
/*    */   public Door() {
/* 20 */     super(AutoplayAddon.autoplay, "door", "Example");
/*    */ 
/*    */     
/* 23 */     this.sgGeneral = this.settings.getDefaultGroup();
/* 24 */     this.Door = this.sgGeneral.add((Setting)((KeybindSetting.Builder)((KeybindSetting.Builder)((KeybindSetting.Builder)(new KeybindSetting.Builder())
/* 25 */         .name("keybind-to-door"))
/* 26 */         .description("doors when you press this button"))
/* 27 */         .defaultValue(Keybind.none()))
/* 28 */         .action(() -> {
/*    */             class_4184 camera = this.mc.field_1773.method_19418();
/*    */             
/*    */             if (camera == null || this.mc.field_1724 == null || this.mc.field_1687 == null) {
/*    */               return;
/*    */             }
/*    */             
/*    */             class_243 cameraPos = camera.method_19326();
/*    */             
/*    */             boolean hasCollided = false;
/*    */             
/*    */             double playerHeight = this.mc.field_1724.method_18381(this.mc.field_1724.method_18376());
/*    */             class_243 direction = class_243.method_1030(camera.method_19329(), camera.method_19330()).method_1029();
/*    */             int MAX_STEPS = 200;
/*    */             double INCREMENT_DISTANCE = 1.0D;
/*    */             for (int i = 0; i < 200; i++) {
/*    */               class_243 increment = direction.method_1021(1.0D * i);
/*    */               class_243 currentPos = cameraPos.method_1019(increment);
/*    */               FastBox fastbox = new FastBox(currentPos.method_1023(0.0D, playerHeight, 0.0D));
/*    */               if (this.mc.field_1687.method_8320(class_2338.method_49638((class_2374)currentPos)).method_51367()) {
/*    */                 hasCollided = true;
/*    */               }
/*    */               if (hasCollided && !fastbox.isCollidingWithBlocks()) {
/*    */                 Movement.setPos(fastbox.position, true, Float.valueOf(this.mc.field_1724.method_36455()), Float.valueOf(this.mc.field_1724.method_36454()));
/*    */                 return;
/*    */               } 
/*    */             } 
/* 55 */           }).build());
/*    */   }
/*    */   
/*    */   private final Setting<Keybind> Door;
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\modules\Door.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */