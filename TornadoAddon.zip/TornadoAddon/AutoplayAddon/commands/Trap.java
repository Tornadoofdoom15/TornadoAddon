/*     */ package AutoplayAddon.commands;
/*     */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*     */ import AutoplayAddon.AutoPlay.Other.FastBox;
/*     */ import AutoplayAddon.AutoPlay.Other.PacketUtils;
/*     */ import AutoplayAddon.Tracker.ServerSideValues;
/*     */ import com.mojang.brigadier.arguments.ArgumentType;
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import meteordevelopment.meteorclient.MeteorClient;
/*     */ import meteordevelopment.meteorclient.commands.arguments.PlayerArgumentType;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_2172;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2885;
/*     */ import net.minecraft.class_3965;
/*     */ 
/*     */ public class Trap extends Command {
/*     */   List<class_2338> trapBlocks;
/*     */   class_243 startingPos;
/*     */   
/*     */   public Trap() {
/*  34 */     super("trap", "ban", new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.trapping = Boolean.valueOf(false);
/*     */     MeteorClient.EVENT_BUS.subscribe(this);
/*     */   } class_1657 e; Boolean trapping; public void build(LiteralArgumentBuilder<class_2172> builder) {
/*  43 */     builder.then(argument("player", (ArgumentType)PlayerArgumentType.create()).executes(context -> {
/*     */             this.startingPos = ServerSideValues.serversidedposition;
/*     */             this.e = PlayerArgumentType.get(context);
/*     */             this.trapBlocks = getTrap((class_1297)this.e);
/*     */             ChatUtils.info("Trapping " + this.e.method_5477().getString() + " with " + this.trapBlocks.size() + " blocks " + System.currentTimeMillis(), new Object[0]);
/*     */             attemptTrap(this.e);
/*     */             return 1;
/*     */           }));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Pre event) {
/*  55 */     if (this.trapping.booleanValue()) attemptTrap(this.e); 
/*     */   }
/*     */   
/*     */   private void attemptTrap(class_1657 e) {
/*  59 */     Movement.setPos(e.method_19538(), false, null, null);
/*  60 */     ChatUtils.info("we need to place " + this.trapBlocks.size() + " blocks ", new Object[0]);
/*     */     
/*  62 */     List<class_2338> toRemove = new ArrayList<>();
/*  63 */     for (class_2338 pos : this.trapBlocks) {
/*  64 */       if (MeteorClient.mc.field_1687.method_8320(pos).method_51367()) {
/*  65 */         toRemove.add(pos);
/*     */         continue;
/*     */       } 
/*  68 */       if (ServerSideValues.canPlace()) {
/*  69 */         MeteorClient.mc.field_1687.method_8501(pos, class_2246.field_10526.method_9564());
/*  70 */         PacketUtils.sendPacket((class_2596)new class_2885(class_1268.field_5808, new class_3965(pos.method_46558(), class_2350.field_11036, pos, false), 0));
/*  71 */         ServerSideValues.handleUse();
/*  72 */         toRemove.add(pos); continue;
/*     */       } 
/*  74 */       this.trapping = Boolean.valueOf(true);
/*     */       
/*     */       return;
/*     */     } 
/*  78 */     this.trapBlocks.removeAll(toRemove);
/*  79 */     this.trapping = Boolean.valueOf(false);
/*  80 */     Movement.setPos(this.startingPos, false, null, null);
/*  81 */     ChatUtils.info("Finished trapping " + System.currentTimeMillis(), new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<class_2338> getTrap(class_1297 e) {
/*  86 */     FastBox fastBox = new FastBox(e);
/*  87 */     List<class_2338> collidedBlocks = fastBox.getOccupiedBlockPos();
/*  88 */     List<class_2338> trapBlocks = new ArrayList<>();
/*     */     
/*  90 */     int minY = Integer.MAX_VALUE;
/*  91 */     int maxY = Integer.MIN_VALUE;
/*     */     
/*  93 */     for (class_2338 pos : collidedBlocks) {
/*  94 */       minY = Math.min(minY, pos.method_10264());
/*  95 */       maxY = Math.max(maxY, pos.method_10264());
/*     */     } 
/*     */     
/*  98 */     int middleY = minY + (maxY - minY) / 2;
/*     */     
/* 100 */     for (class_2338 blockPos : collidedBlocks) {
/* 101 */       if (blockPos.method_10264() == middleY) {
/* 102 */         for (class_2350 dir : class_2350.values()) {
/* 103 */           if (dir != class_2350.field_11036 && dir != class_2350.field_11033) {
/* 104 */             class_2338 offsetPos = blockPos.method_10093(dir);
/* 105 */             if (!collidedBlocks.contains(offsetPos)) {
/* 106 */               trapBlocks.add(offsetPos);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/* 111 */       if (blockPos.method_10264() == maxY) {
/* 112 */         trapBlocks.add(blockPos.method_10084());
/*     */       }
/* 114 */       if (blockPos.method_10264() == minY) {
/* 115 */         trapBlocks.add(blockPos.method_10074());
/*     */       }
/*     */     } 
/*     */     
/* 119 */     return trapBlocks;
/*     */   }
/*     */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Trap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */