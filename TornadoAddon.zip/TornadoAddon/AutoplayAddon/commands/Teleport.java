/*    */ package AutoplayAddon.commands;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import AutoplayAddon.AutoPlay.Other.ClientPosArgumentType;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_243;
/*    */ 
/*    */ public class Teleport
/*    */   extends Command {
/*    */   public Teleport() {
/* 17 */     super("teleport", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[] { "go", "gt", "goto", "teleportto" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 22 */     builder.then(argument("pos", (ArgumentType)ClientPosArgumentType.pos()).executes(ctx -> {
/*    */             class_243 pos = ClientPosArgumentType.getPos(ctx, "pos");
/*    */             ChatUtils.info("Teleporting to " + pos.toString(), new Object[0]);
/*    */             Movement.setPos(pos, true, null, null);
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Teleport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */