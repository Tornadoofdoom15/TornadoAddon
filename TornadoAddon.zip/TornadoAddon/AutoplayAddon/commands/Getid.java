/*    */ package AutoplayAddon.commands;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.arguments.PlayerArgumentType;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2793;
/*    */ import net.minecraft.class_2828;
/*    */ 
/*    */ public class Getid extends Command {
/*    */   public Getid() {
/* 17 */     super("getid", "ban", new String[0]);
/*    */   }
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 21 */     builder.then(argument("player", (ArgumentType)PlayerArgumentType.create()).executes(context -> {
/*    */             int blocks = 190;
/*    */             int packetsRequired = (int)Math.ceil((blocks / 10)) - 1;
/*    */             for (int packetNumber = 0; packetNumber < packetsRequired - 1; packetNumber++)
/*    */               MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true)); 
/*    */             MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(MeteorClient.mc.field_1724.method_23317(), MeteorClient.mc.field_1724.method_23318() + blocks, MeteorClient.mc.field_1724.method_23321(), true));
/*    */             MeteorClient.mc.field_1724.method_5814(MeteorClient.mc.field_1724.method_23317(), MeteorClient.mc.field_1724.method_23318() + blocks, MeteorClient.mc.field_1724.method_23321());
/*    */             MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2793(0));
/*    */             class_1657 e = PlayerArgumentType.get(context);
/*    */             ChatUtils.info("player id is " + e.method_5628() + " width " + MeteorClient.mc.field_1724.method_17681() + " height " + MeteorClient.mc.field_1724.method_17682(), new Object[0]);
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Getid.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */