package AutoplayAddon.commands;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_746;

@FunctionalInterface
interface PlayerConsumer {
  void accept(class_746 paramclass_746) throws CommandSyntaxException;
}


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Mine$PlayerConsumer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */