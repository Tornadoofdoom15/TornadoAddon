/*    */ package AutoplayAddon.commands;
/*    */ 
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import net.minecraft.class_2172;
/*    */ 
/*    */ public class Stop
/*    */   extends Command {
/*    */   public Stop() {
/* 12 */     super("stop", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 17 */     builder.executes(context -> 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Stop.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */