/*    */ package AutoplayAddon.commands;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.arguments.IntegerArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2793;
/*    */ 
/*    */ public class AcceptTp extends Command {
/*    */   public AcceptTp() {
/* 15 */     super("accepttp", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 20 */     builder.then(argument("teleportid", (ArgumentType)IntegerArgumentType.integer()).executes(context -> {
/*    */             Integer id = (Integer)context.getArgument("teleportid", Integer.class);
/*    */             class_2793 packet = new class_2793(id.intValue());
/*    */             MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)packet);
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\AcceptTp.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */