/*    */ package AutoplayAddon.commands;
/*    */ import AutoplayAddon.AutoPlay.Actions.CraftUtil;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2287;
/*    */ import net.minecraft.class_746;
/*    */ 
/*    */ public class Craft extends Command {
/*    */   public Craft() {
/* 18 */     super("craft", "Crafts Item", new String[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 25 */     builder.then(argument("item", (ArgumentType)class_2287.method_9776(REGISTRY_ACCESS)).executes(context -> printItemName(())));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int printItemName(PlayerConsumer consumer) throws CommandSyntaxException {
/* 37 */     consumer.accept(MeteorClient.mc.field_1724);
/* 38 */     return 1;
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   private static interface PlayerConsumer {
/*    */     void accept(class_746 param1class_746) throws CommandSyntaxException;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Craft.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */