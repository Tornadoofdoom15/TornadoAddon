/*    */ package AutoplayAddon.commands;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import net.minecraft.class_2172;
/*    */ 
/*    */ public class locate extends Command {
/*    */   public locate() {
/*  9 */     super("locate", "Teleports you to the position of your camara, nig", new String[0]);
/*    */   }
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 13 */     builder.executes(context -> 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\locate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */