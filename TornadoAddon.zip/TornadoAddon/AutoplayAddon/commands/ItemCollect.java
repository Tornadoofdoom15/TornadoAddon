/*    */ package AutoplayAddon.commands;
/*    */ 
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2287;
/*    */ import net.minecraft.class_746;
/*    */ 
/*    */ public class ItemCollect
/*    */   extends Command {
/*    */   public ItemCollect() {
/* 22 */     super("itemcollect", "Collects Item", new String[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 29 */     builder.then(argument("item", (ArgumentType)class_2287.method_9776(REGISTRY_ACCESS)).executes(context -> printItemName(())));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int printItemName(PlayerConsumer consumer) throws CommandSyntaxException {
/* 39 */     consumer.accept(MeteorClient.mc.field_1724);
/* 40 */     return 1;
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   private static interface PlayerConsumer {
/*    */     void accept(class_746 param1class_746) throws CommandSyntaxException;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\ItemCollect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */