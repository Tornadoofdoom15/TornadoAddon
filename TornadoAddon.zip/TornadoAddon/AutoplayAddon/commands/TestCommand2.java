/*    */ package AutoplayAddon.commands;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2828;
/*    */ 
/*    */ public class TestCommand2 extends Command {
/*    */   public TestCommand2() {
/* 13 */     super("TestCommand2", "what da heck", new String[0]);
/*    */   }
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 17 */     builder.executes(context -> {
/*    */           class_243 orinPosition = MeteorClient.mc.field_1724.method_19538();
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true));
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true));
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true));
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true));
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true));
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_5911(true));
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(orinPosition.field_1352, orinPosition.field_1351 + 50.0D, orinPosition.field_1350, true));
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(orinPosition.field_1352, orinPosition.field_1351 + 100.0D, orinPosition.field_1350, true));
/*    */           return 0;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\TestCommand2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */