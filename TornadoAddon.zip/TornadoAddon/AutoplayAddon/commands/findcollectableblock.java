/*    */ package AutoplayAddon.commands;
/*    */ 
/*    */ import AutoplayAddon.AutoPlay.Locator.CanPickUpTest;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2248;
/*    */ import net.minecraft.class_2287;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_746;
/*    */ 
/*    */ public class findcollectableblock extends Command {
/*    */   public findcollectableblock() {
/* 23 */     super("findcollectableblock", "Mines a Block", new String[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 30 */     builder.then(argument("item", (ArgumentType)class_2287.method_9776(REGISTRY_ACCESS)).executes(context -> printItemName(())));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int printItemName(PlayerConsumer consumer) throws CommandSyntaxException {
/* 50 */     consumer.accept(MeteorClient.mc.field_1724);
/* 51 */     return 1;
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   private static interface PlayerConsumer {
/*    */     void accept(class_746 param1class_746) throws CommandSyntaxException;
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\findcollectableblock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */