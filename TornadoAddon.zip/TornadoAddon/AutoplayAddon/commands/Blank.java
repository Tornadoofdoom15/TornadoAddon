/*    */ package AutoplayAddon.commands;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_2172;
/*    */ 
/*    */ public class Blank extends Command {
/*    */   public Blank() {
/* 12 */     super("blankmsg", "Teleports you to the position of your camara, nig", new String[0]);
/*    */   }
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 16 */     builder.executes(context -> {
/*    */           ChatUtils.info("sending blank mess1age " + MeteorClient.mc.field_1724.method_17682(), new Object[0]);
/*    */           return 1;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Blank.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */