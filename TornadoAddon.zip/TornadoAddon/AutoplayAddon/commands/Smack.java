/*    */ package AutoplayAddon.commands;
/*    */ 
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.arguments.IntegerArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import java.lang.reflect.Field;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2824;
/*    */ 
/*    */ public class Smack extends Command {
/*    */   public Smack() {
/* 19 */     super("smack2", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 24 */     builder.then(argument("entityid", (ArgumentType)IntegerArgumentType.integer()).executes(context -> {
/*    */             Integer id = (Integer)context.getArgument("entityid", Integer.class);
/*    */             ChatUtils.info("attempting to smack " + id, new Object[0]);
/*    */             class_2824 packet1 = class_2824.method_34206((class_1297)MeteorClient.mc.field_1724, false);
/*    */             try {
/*    */               Field entityIdField = class_2824.class.getDeclaredField("entityId");
/*    */               entityIdField.setAccessible(true);
/*    */               entityIdField.set(packet1, id);
/* 32 */             } catch (NoSuchFieldException|IllegalAccessException e) {
/*    */               e.printStackTrace();
/*    */             } 
/*    */             MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)packet1);
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Smack.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */