/*    */ package AutoplayAddon.commands;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.arguments.IntegerArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import java.lang.reflect.Field;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2824;
/*    */ 
/*    */ public class Interact extends Command {
/*    */   public Interact() {
/* 18 */     super("interact", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 23 */     builder.then(argument("entityid", (ArgumentType)IntegerArgumentType.integer()).executes(context -> {
/*    */             Integer id = (Integer)context.getArgument("entityid", Integer.class);
/*    */             class_2824 packet1 = class_2824.method_34207((class_1297)MeteorClient.mc.field_1724, false, class_1268.field_5808);
/*    */             try {
/*    */               Field entityIdField = class_2824.class.getDeclaredField("entityId");
/*    */               entityIdField.setAccessible(true);
/*    */               entityIdField.set(packet1, id);
/* 30 */             } catch (NoSuchFieldException|IllegalAccessException e) {
/*    */               e.printStackTrace();
/*    */             } 
/*    */             MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)packet1);
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\Interact.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */