/*    */ package AutoplayAddon.commands;
/*    */ 
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import net.minecraft.class_2172;
/*    */ 
/*    */ public class enablegravity
/*    */   extends Command
/*    */ {
/*    */   public enablegravity() {
/* 12 */     super("enablegravity", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[] { "tpbypass", "tpb", "tp" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 17 */     if (MeteorClient.mc.field_1724 != null)
/* 18 */       MeteorClient.mc.field_1724.method_5875(false); 
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\enablegravity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */