/*    */ package AutoplayAddon.commands;
/*    */ 
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ import net.minecraft.class_2172;
/*    */ 
/*    */ public class GetClosestVehicleId
/*    */   extends Command
/*    */ {
/* 18 */   private final List<class_1299<?>> vehicleTypes = Arrays.asList((class_1299<?>[])new class_1299[] { class_1299.field_6121, class_1299.field_6096 });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GetClosestVehicleId() {
/* 25 */     super("getClosestVehicleId", "Gets the closest vehicle entity id.", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 30 */     builder.executes(context -> {
/*    */           class_1297 closestVehicle = null;
/*    */           double closestDistance = Double.MAX_VALUE;
/*    */           for (class_1297 entity : MeteorClient.mc.field_1687.method_18112()) {
/*    */             if (this.vehicleTypes.contains(entity.method_5864())) {
/*    */               double distance = MeteorClient.mc.field_1724.method_5739(entity);
/*    */               if (distance < closestDistance) {
/*    */                 closestDistance = distance;
/*    */                 closestVehicle = entity;
/*    */               } 
/*    */             } 
/*    */           } 
/*    */           if (closestVehicle != null) {
/*    */             ChatUtils.info("Closest vehicle entity id is: " + closestVehicle.method_5628(), new Object[0]);
/*    */           } else {
/*    */             ChatUtils.info("No vehicles found nearby.", new Object[0]);
/*    */           } 
/*    */           return 1;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\GetClosestVehicleId.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */