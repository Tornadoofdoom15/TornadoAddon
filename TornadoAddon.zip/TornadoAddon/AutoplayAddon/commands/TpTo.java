/*    */ package AutoplayAddon.commands;
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import com.mojang.brigadier.arguments.ArgumentType;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import meteordevelopment.meteorclient.commands.arguments.PlayerArgumentType;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_2172;
/*    */ 
/*    */ public class TpTo extends Command {
/*    */   public TpTo() {
/* 14 */     super("tpto", "ban", new String[0]);
/*    */   }
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 18 */     builder.then(argument("player", (ArgumentType)PlayerArgumentType.create()).executes(context -> {
/*    */             class_1657 e = PlayerArgumentType.get(context);
/*    */             Movement.setPos(e.method_19538(), true, Float.valueOf(e.method_36455()), Float.valueOf(e.method_36454()));
/*    */             return 1;
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\TpTo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */