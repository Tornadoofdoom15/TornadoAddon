/*    */ package AutoplayAddon.commands;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2848;
/*    */ 
/*    */ public class StopSleeping extends Command {
/*    */   public StopSleeping() {
/* 14 */     super("stopsleep", "Sends a packet to the server with new position. Allows to teleport small distances.", new String[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 19 */     builder.executes(context -> {
/*    */           MeteorClient.mc.field_1724.field_3944.method_52787((class_2596)new class_2848((class_1297)MeteorClient.mc.field_1724, class_2848.class_2849.field_12986));
/*    */           return 1;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\StopSleeping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */