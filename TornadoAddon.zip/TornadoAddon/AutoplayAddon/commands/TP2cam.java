/*    */ package AutoplayAddon.commands;
/*    */ import AutoplayAddon.AutoPlay.Movement.Movement;
/*    */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*    */ import com.mojang.brigadier.context.CommandContext;
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import meteordevelopment.meteorclient.MeteorClient;
/*    */ import meteordevelopment.meteorclient.commands.Command;
/*    */ import net.minecraft.class_2172;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_4184;
/*    */ 
/*    */ public class TP2cam extends Command {
/*    */   public TP2cam() {
/* 14 */     super("tp2cam", "Teleports you to the position of your camara, nig", new String[0]);
/*    */   }
/*    */   
/*    */   public void build(LiteralArgumentBuilder<class_2172> builder) {
/* 18 */     builder.executes(context -> {
/*    */           class_4184 camera = MeteorClient.mc.field_1773.method_19418();
/*    */           class_243 cameraPos = camera.method_19326();
/*    */           class_243 playerPos = new class_243(cameraPos.field_1352, cameraPos.field_1351 - MeteorClient.mc.field_1724.method_18381(MeteorClient.mc.field_1724.method_18376()), cameraPos.field_1350);
/*    */           Movement.setPos(playerPos, true, Float.valueOf(camera.method_19329()), Float.valueOf(camera.method_19330()));
/*    */           return 1;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\tehar\Downloads\autoplay-addon-0.7indev.jar!\AutoplayAddon\commands\TP2cam.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */